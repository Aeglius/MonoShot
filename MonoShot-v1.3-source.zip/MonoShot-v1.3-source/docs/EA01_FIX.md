﻿# MonoShot v1.3 — EA-01 fix / 安全分析边界修复

日期：2026-10-18。文件/程序集/Manifest 版本：1.3.0.0。目标仍为 .NET Framework 4.8 / C# 5 / x64，保留当前工作台、主题、动画、截图与导出功能。

## 原因与实际改动

EA-01 指出，只读沙箱和“不要调用工具”的提示词不足以约束图像分析的能力。v1.3 在既有 CLI 接入中加入独立的能力策略，未更换认证接口、读取或迁移用户凭证。

| 文件 | 改动 |
| --- | --- |
| `src/AnalysisPolicy.cs` | 验证 CLI 版本；集中生成工具/上下文限制；检查账户说明文件；解析并校验 JSON 事件 |
| `src/Bridge.cs` | 分析使用独立任务工作目录；预检版本；分别观察 stdout/stderr；发现受限/未知事件停止并拒绝结果；有界排空管道；清理答案与空工作目录 |
| `src/AnalysisCoordinator.cs`、`src/Strings.cs` | 分析版本不支持、上下文风险、受限轨迹有独立中英文提示，不混用登录错误 |
| `src/AssemblyInfo.cs`、`src/app.manifest`、构建与打包脚本 | 独立 v1.3 版本、EXE、缓存和发布路径；旧 v1.2 发布物保留 |
| `tests/FakeCodex.cs`、`tests/TestRunner.cs` | 未验证版本、工具事件、未知/无效 JSON、缺少完成事件、忽略配置、账户说明文件与清理回归 |
| `tests/security/` | 独立开发诊断工具，使用生产策略生成参数、生产解析器验证真实 CLI 轨迹及本地模拟服务请求 |

JSON 使用 .NET Framework 自带的 DataContractJsonSerializer，新增 System.Runtime.Serialization、System.Xml 引用。没有第三方 NuGet、新 UI 框架、随包 DLL 或常驻安全代理。诊断脚本需要开发环境中的 Python 3，Portable 运行不需要 Python。

## 强制边界与兼容性

1. 分析仅接受原生 `codex-cli 0.160.1`。未知版本在发送图像前拒绝，不回退旧启动参数。增加版本须重新检查实际工具列表及攻击探针，不按版本号大小推定兼容。
2. 显式关闭 shell、额外本地图像工具、浏览器/计算机控制、web search、Apps、插件、MCP 配置、委派、代码执行宿主等入口，并忽略用户配置和执行规则。保留 `read-only + never` 作为另一层防护。
3. 禁止项目说明、技能目录和环境上下文进入模型输入。实测发现账户级 AGENTS 不受项目文档字节限制约束，因此在它存在时拒绝分析，不读取、修改或删除其内容。检查两种名称：`data/codex/AGENTS.md`、`data/codex/AGENTS.override.md`。
4. CLI 账户目录仍是原有 `data/codex`，但它不再作为分析工作目录。登录仍使用 `login --device-auth`、原有启动说明超时和取消逻辑，不应用分析版本/账户说明限制。
5. 每次分析有唯一工作目录；不额外创建全尺寸 Bitmap 或重复解码图像。原有图像快照、任务标识、图像版本、取消与页面状态机制保留。
6. 轨迹必须有 thread/turn 开始及完成，仅接受文字、推理和已识别错误项。出现工具项、未知/无效事件、未完成轨迹或忽略配置的警告时拒绝答案。观察器异常在工作任务中传播，避免从 DataReceived 回调抛出未处理异常。轨迹不新增持久日志。
7. 本地取消/截止时间结束子进程并拒绝迟到结果；不能保证中止已经开始的远端计算。

## 已执行的验证

### 完整离线回归

`build.ps1 -Test`：**208 项通过**。包含原有图像格式导出、区域选择、页面共享状态、动画、主题/语言、登录说明/网络错误/无说明超时/取消、销毁后回调及新增安全拒绝场景。使用真实 WinForms 消息循环、合成图片与模拟 CLI；不读取真实账号，不改动用户剪贴板。构建无警告。

### 真实 CLI + 本地模拟模型

Windows x64，CLI **0.160.1**，模型标识 `gpt-6.1-sol`；服务响应来自本机隔离测试服务，不使用真实模型、账号、费用或截图。参数来自生产 AnalysisPolicy，返回轨迹交给生产解析器。

**14 场景通过**：正常回答，以及 shell_command、exec_command、view_image、apply_patch、web_search、MCP 读取、spawn_agent、read_file、list_dir、grep_files、functions.exec、node_repl、request_permissions 的合成调用尝试。两个账户说明文件拒绝检查另行通过。

- 本轮请求的 advertised tool 列表为空；未把“未向模型展示工具”误称为删除了 CLI 的所有内部处理器。
- 命令、读文件、MCP 等未支持调用被拒绝；补丁使用有效 custom_tool_call 载荷，明确被只读沙箱及批准设置拒绝，未把“错误载荷解析失败”算作有效权限测试。
- 文件哨兵、工作目录 AGENTS 和技能描述未出现在发送请求中；合成文件内容未改变，命令/MCP 执行标记未创建。
- 未知/缺失轨迹与受限工具事件由独立模拟 CLI 验证拒绝；答案中的工具名称作为普通文字不会误报。
- 机器可读汇总：[EA01_SECURITY_TESTS.json](EA01_SECURITY_TESTS.json)。仅保存合成测试的布尔结论、工具名称和策略 SHA256，不包含账号、请求正文或个人路径。

初次探针暴露了文档旧配置键被忽略、账户说明/技能目录自动加载的行为，已在最终策略中处理；初次失败不计入上述通过结果。

## 构建体积与本轮资源观察

| 指标 | 实际值 / 说明 |
| --- | --- |
| v1.2 UI Motion EXE | 144,896 bytes，保留的旧发布物 |
| v1.3 EXE | 153,088 bytes，增加 8,192 bytes（8 KiB） |
| 随包依赖 DLL | 0；仅增加框架自带程序集引用 |
| 回归 runner Working Set | 72 MiB，包括测试、渲染、WinForms 与安全解析器；不是独立应用基线 |
| 120 次图像/页面循环 | GDI delta 0，USER delta 0，Private Bytes delta +6,804 KiB；单轮变化不能直接判定泄漏 |
| 空闲 CPU | 500 ms 观察窗内 0.0 ms CPU，不代表所有环境的固定占用 |
| 首个窗体构造/显示 | runner 内 214 ms，不是冷启动或系统首次可交互耗时 |

未重新执行独立进程冷启动、5/30 分钟空闲、完整 GC heap 或云端分析资源基准；不把旧审计测量改称 v1.3 数据。压缩包实际大小和 SHA256 由本次发布文件给出，不套用历史约 49 KB / 低于 10 MB 的数字。

## 边界与仍需确认的项目

这是**受信任、已验证 CLI 的能力限制**，不是给任意可执行文件套上操作系统级的任意文件读取隔离。CLI 自身仍需读认证/程序资源及连接所选模型服务；软件供应链、机器管理员策略与服务端须受信任。全局模型或系统策略发生变化时仍需复测。其他模型元数据可能暴露无文件/网络能力的提问工具；不得据此宣称所有模型的工具列表都为空。

JSON 轨迹验证是第二道检测，不能撤回已经发生的外部操作；主要防护在调用前禁用能力与只读/不批准策略。补丁处理器仍存在于 CLI 内部，已验证它拒绝写入；未宣称删除此处理器。

真实浏览器授权、真实云端图像回答、远端计算停止、其他 CLI 版本、管理员定制配置、混合 DPI/多屏实体输入及其他模型目录变化未在本轮验证。此前审计 EA-02 至 EA-06 仍开放；特别是异常终止留下临时图像和超长无换行管道分配问题，没有因本轮修复自动消失。

## 复测与发布

```powershell
.\build.ps1 -Test
.\tests\security\run-security.ps1 -Cli '.\tools\codex.exe'
.\package.ps1 -Destination releases/v1.3 -SkipBuild
```

原生 CLI 由开发者自行准备，版本必须匹配。安全脚本仅连接其临时本地测试服务，使用独立 CODEX_HOME 和合成文件；输出位于项目 `.cache/security-v1.3-*`。不要把该诊断数据或使用过的账户目录复制到 Portable 包。打包白名单包含源码与独立诊断源文件，Portable 只有六个发布文件。已有发布目录不覆盖。

### English

v1.3 addresses EA-01 through a tested, versioned capability policy for native CLI 0.160.1, isolated task working directories, explicit context exclusions and validated JSON traces. Unknown versions/settings/events fail closed. Account instruction files cause a refusal without reading or altering their contents; the original device-code authentication and portable account remain unchanged.

208 offline checks and 14 real-CLI/loopback-model scenarios passed. Tests use synthetic data and production argument/trace code. No real account, paid model or external provider request was used. The tested model advertised no tools; a valid patch call was rejected by read-only/approval policy. This is not OS-level isolation from an untrusted executable or administrator policy. Real sign-in/cloud service behavior and other CLI/model versions remain unverified. EA-02 through EA-06 remain open.

Framework-native JSON parsing adds two framework references, with no NuGet or bundled DLL. A separate v1.3 Portable/source release preserves previous releases and portable settings compatibility. See the bilingual README for upgrade instructions.

## References

- [OpenAI configuration reference](https://learn.chatgpt.com/docs/config-file/config-reference): capability switches, web-search settings and context configuration. Actual installed CLI behavior was verified rather than assumed from current documentation.
- [OpenAI agent approvals and security](https://learn.chatgpt.com/docs/agent-approvals-security): read-only sandbox and approval policy are distinct from disabling tools.
