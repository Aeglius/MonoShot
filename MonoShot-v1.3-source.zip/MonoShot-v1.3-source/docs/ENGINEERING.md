﻿# MonoShot v1.3 engineering review

## v1.3 / EA-01 / 2026-10-18

Current implementation and measured verification: [EA01_FIX.md](EA01_FIX.md). Framework 4.8/C# 5/x64 and the existing authentication flow remain. AnalysisPolicy owns the versioned tool/context restrictions; Bridge validates stdout JSON and uses a separate task working directory. Framework-native JSON parsing adds System.Runtime.Serialization and System.Xml references, with no bundled DLL or NuGet.

The sections below are historical v1.2 measurements and implementation notes; they are not new v1.3 performance results.

## UI Motion refinement / file version 1.2.0.3

The duplicate capture-toolbar AI action was removed. Top navigation now selects image-first or adjacent-AI mode, with Settings remaining at the right. The explicit Full view action inside the panel and the existing Ctrl+2 shortcut retain the independent analysis page. WorkspaceState.NavigationPage derives the navigation selection without conflating a visual panel with the actual page or task.

CapturePage now owns normalized sidebar progress on the existing MotionHub. Its clipped viewport and gutter animate; a fixed-width SideHost prevents text-box and result reflow on every frame. The preview simply redraws the same current image at its new fit geometry; no full-size animation cache is allocated. Page layout tables and the clip panel use double buffering. Repeated requests reverse from the current progress instead of resetting to an endpoint. Unchanged integer sizes skip layout work.

MainForm separates requested mode from mounted host: opening mounts once, closing disables input while retaining visible controls, and a guarded UI post detaches only when the close transition finishes. Reopening invalidates that pending detach. Page changes settle hidden motion. Business task correctness never depends on an animation callback; analysis, cancellation, prompt/result state and explicit login dispatch remain unchanged. A supplied MotionHub constructor is available internally for deterministic UI-motion tests, with normal ownership/disposal unchanged.

Deterministic full-window tests advance a controlled clock and cover intermediate geometry, fixed editor width, reverse/reopen, late frames, page switches, unrelated zoom notifications, reduced motion and disposal during animation. Normal production uses the existing Stopwatch-based clock and system animation preference. Exact frame rate and subjective motion quality on other hardware are not claimed.

## Shell Demo review and implementation / 2026-10-17 / file version 1.2.0.2

Review confirmed Framework 4.8, C# 5, x64, the same four framework references and no NuGet dependencies. The prior title/header consumed two large rows, preview only fitted the image without an explicit zoom state or filename, and analysis lived on its own page. Existing shared state, cached GDI+ surfaces, coordinator/dispatch, authentication fixes and elapsed-time motion were suitable for reuse. No authentication or request protocol changes were needed.

P1/P2 inform the information hierarchy: compact brand/caption controls; separate navigation with Settings at the right; grouped import/capture versus copy/export actions; filename and resolution above the large preview; zoom controls below; optional adjacent analysis. Developer/contributor and login information remain in Settings. Dark surfaces use neutral grays with a darker canvas; existing Light/System/accent preferences remain compatible.

The implementation is incremental: WindowChrome.cs adds CustomTitleBar/CaptionButton; MainForm owns shell messages and moves the same AnalysisPage between pageHost and CapturePage.SideHost. AnalysisPage switches local layout between columns and a stacked, scrollable sidebar. It neither constructs another editor tree nor duplicates the current bitmap. WorkspaceState adds filename, fit/manual zoom and panel-open view state; ImageCanvas calculates real display scale and owns only a pan transform. Import remembers Path.GetFileName, never a public local path. Export still uses original pixels.

### Native shell contract

Managed FormBorderStyle.None disables managed caption insets, while CreateParams explicitly keeps WS_THICKFRAME, WS_SYSMENU, WS_MINIMIZEBOX and WS_MAXIMIZEBOX. This is complemented by WM_NCCALCSIZE, WM_NCHITTEST, WM_GETMINMAXINFO, signed screen coordinates, native system commands and the system menu; it is not a visual-only borderless form.

The title is painted directly on the form so no child title container swallows HTCAPTION. Minimize/close are real focusable WinForms buttons with GDI+ drawing; the maximize child returns HTTRANSPARENT so the form can expose HTMAXBUTTON. Its NC mouse handling captures/releases a press and synchronizes custom hover feedback. Window state selects maximize/restore glyphs. Activation and theme/language notifications update these controls with the existing scheduler and cached brushes/pens.

Resize hit tests cover all eight border/corner regions and disable while maximized. WM_GETMINMAXINFO uses monitor-relative work-area/minimum-size geometry. Maximized WM_NCCALCSIZE also clips the client to the work area selected by the proposed window rectangle, including a cross-monitor move. Native resize shadows may extend beyond that visible client. Verification exposed WinForms adding the native resize-frame inset again on restoration; the system-command path restores the prior client size while retaining the native position, preventing cumulative growth. Tests cover ten maximize/restore cycles and minimize/restore from a maximized state.

### Verification boundaries and design choices

No new threads, dependencies, full-size preview caches or animation timers were added. Sidebar width changes are immediate to prioritize resize/editor stability over motion. Window controls share MotionHub. Previously reported login dispatch/teardown regressions remain in the full regression suite.

Actual native command/message tests passed on the current desktop, but physical title dragging, edge-resize cursors, Alt+F4/Alt+Space, taskbar interactions, auto-hide taskbars, mixed-DPI monitors and Windows 11 Snap Layouts require user/device validation. HTMAXBUTTON integration does not prove the actual Snap flyout; the minimum 940 logical-pixel width also limits narrow zones. No claim is made about remote login/cloud access from offline tests.

Reference behavior: [Microsoft custom frame guidance](https://learn.microsoft.com/en-us/windows/win32/dwm/customframe), [Snap layout integration](https://learn.microsoft.com/en-us/windows/apps/desktop/modernize/ui/apply-snap-layout-menu).

## Review before the v1.2 changes

The actual project targets .NET Framework 4.8/x64 and C# 5, with System, System.Core, System.Drawing and System.Windows.Forms only. No NuGet packages were present. The portable csc build, manifest/configuration and explicit source/release allowlists remain.

Reusable code: Pictures import/geometry/export; CaptureOverlay selection; Store legacy text settings and native CLI discovery; Bridge device-code authentication, bounded child processes, UTF-8 stdin and response cleanup; cached GDI+ controls; UiTheme and the shared Stopwatch/Timer MotionHub.

Required adjustments: the current bitmap was owned by a preview control, most application state lived in MainForm, settings were a separate dialog, strings/presets lived in handlers, and there was no explicit task-image version contract. The previous analysis also read prompt text after asynchronous PNG encoding, so the intended prompt needed freezing before the first await.

Implementation order: introduce shared state/localization; add the three persistent pages and navigation; move CLI lifecycle into a small coordinator while reusing Bridge; connect the existing image workflows; verify state/cancellation/focus/layout/resources and package with updated allowlists. No service/credential migration or framework change was required.

## Implemented architecture

- WorkspaceState owns the current Bitmap, image source/version, page, prompt/preset, result provenance, job phase, cancellation reference, appearance/language, connection drafts/status and notification flags. Mutations assert the UI thread. Preview controls borrow the image and unsubscribe on disposal.
- WorkspaceJob freezes a task ID, image version/dimensions, prompt and language. The coordinator also captures CLI/model values before its first await. A necessary short-lived snapshot supports background PNG encoding while the current image can change.
- AnalysisCoordinator owns the task lifetime and cancellation-source disposal, reusing Bridge unchanged. Background completions and login lines explicitly dispatch through the main-window handle, with disposal-aware completion of queued posts. Cancellation discards late output; failures retain the previous valid result. Local cancellation cannot establish whether remote computation has stopped.
- CapturePage, AnalysisPage and PreferencesPage are constructed once. They exchange state notifications and semantic action events, never manipulate each other's controls. MainForm retains existing capture, clipboard, file-dialog, hotkey and application-close orchestration.
- Design/Palette centralize skin tokens. Strings/PromptCatalog centralize bilingual resources and stable preset IDs. WorkspaceNavigation and ThemeChoice reuse native-backed controls; page switching changes visibility without recreating content.
- MainForm handles system-preference notifications through the UI thread and releases subscriptions on disposal. The legacy configuration filenames remain compatible; preset.txt is optional. Authentication instructions stay separate from result export and ordinary appearance/configuration files.

## Findings fixed during verification

Initial hidden pages retained their default control size when switching under a suspended layout. Resuming parent layout explicitly fixes first-display bounds. Small windows now reduce thumbnail height to protect prompt space.

A test-process crash exposed Progress<T>'s thread-pool fallback when no UI synchronization context existed. Login/analysis now use explicit, guarded UI dispatch rather than ambient-context assumptions. Pending dispatch tasks complete when the owner is disposed. The test harness also runs a real WinForms message loop while opening/closing test forms; it does not rely solely on DoEvents. The null-context login and forced-disposal cases remain regression checks. Unhandled test exceptions produce a nonzero failure report rather than a Windows crash dialog.

Builds stage a new executable before publishing it. If the previous executable is in use, it is renamed into the project cache; the user's running session is not forcibly terminated. Clean packages still exclude all runtime/test data.

See VERIFICATION.md for executed checks, measured sizes/resources and explicit manual boundaries. See DESIGN.md for PSD replacement points.

## Login fix / 2026-10-17

The authentication protocol remains `login --device-auth`. The login action now validates and saves the current editable connection before starting. Shared state immediately exposes waiting feedback and marks instructions ready only after an official-shaped HTTPS URL and a device-code-shaped string arrive. A linked cancellation source bounds initial instructions to 30 seconds; readiness disables only this startup deadline, preserving the existing ten-minute overall process deadline and independent user cancellation.

Redirected stdout/stderr EOF signals are given a bounded drain after process exit. A shared output gate prevents callbacks after teardown before captured cancellation sources are disposed. Error classification checks request/network failure before generic authentication words in an error URL. Failure UI retains only localized guidance; ephemeral output still clears at the end and never becomes an analysis result or persisted error log. Offline fixtures test silence, a banner without a code, network/unsupported errors, readiness, cancellation, page navigation and closure. This does not establish real network access or complete browser authorization.

## Prior v1.1 review

## Baseline, before edits

The previous release had a single C# source file and a PowerShell/csc build; no solution or project file. Runtime configuration explicitly declared .NET Framework 4.8; the compiler targeted x64. References were System, System.Core, System.Drawing and System.Windows.Forms. There were no NuGet packages. The compiler previously did not stamp TargetFrameworkAttribute; v1.1 makes the existing declared target explicit in project and assembly metadata.

Store handled portable text settings and CLI discovery. Pictures handled image import, crop geometry and export. Bridge launched the optional Codex CLI. MainForm contained capture, prompt, authentication and UI state. CaptureOverlay owned region selection; SettingsForm edited CLI and model settings. MonoButton and Canvas provided GDI+ drawing. There was no animation timer, theme service or third-party networking library.

Confirmed issues: scattered styling; round paths allocated on every paint; full-overlay invalidation on mouse move; duplicate full-screen bitmap; UI-thread file/image encoding and stdin writes; unbounded wait after child termination; capture continuation could reopen a closed form; raw exception text written to disk; developer identity and local paths in public documents; temporary authentication text could be copied or saved as an analysis result.

## Implementation order

1. Preserve existing setting names, Framework 4.8/x64 and authentication commands. Split existing responsibilities into a few source files, with no new abstraction layers or dependencies.
2. Centralize tokens, palette, fonts, geometry and motion timings. Use one active-only WinForms timer and Stopwatch-based interpolation. Respect client-area/reduced-animation settings; handle interruption and reversal from current values.
3. Cache drawing geometry and disposable paint resources; animate control state and theme separately. Keep native button/text-box accessibility and native non-client window behavior.
4. Fix image ownership, capture cancellation/close races, bounded child cancellation and exception handling. Keep authentication output ephemeral and out of result export/logging.
5. Add isolated regression/resource/render checks and allowlisted release/source packaging. Scan public artifacts for personal configuration and sensitive files.

## Compatibility and scope

Existing language.txt, cli.txt, model.txt and data/codex remain unchanged. New appearance and draft prompt files are optional, forward-compatible additions. Device-code login, separate Codex home, UTF-8 stdin, read-only exec and ephemeral sessions remain. Credentials are never inspected or migrated by the app. Native clipboard, dialogs, title bar, resizing and keyboard semantics remain.

Mixed-DPI virtual-desktop capture and protected/HDR content still depend on Windows/GDI. Simulated CLI tests do not establish real cloud account access. No update service, runtime download or third-party framework is introduced.

## Implemented fixes

Drawing geometry, brushes and pens are owned/disposed by their controls; selection invalidation is localized. The full desktop bitmap transfers directly to preview for full capture; region capture creates only its selected result. A single snapshot is intentionally retained for asynchronous encoding/analysis so a subsequent capture cannot dispose an image still in use. File import, encode/export, process launch, stdin and native process waits are off the UI thread.

Capture has a repeat guard and a lifetime cancellation token. Closing cancels pending work, closes an existing overlay and waits for cleanup without reopening the form. CLI operations have bounded deadlines/cancellation; a kill-on-close job contains child processes where supported, with a bounded process-tree fallback. Errors use safe categories; no raw CLI exception log is persisted. Device codes remain ephemeral UI instructions and never become exportable analysis results.

Settings and image export commit through same-directory MoveFileEx with replacement/write-through flags. This avoids ReplaceFile ACL-merge requirements encountered in restricted environments. Existing setting filenames remain intact. Paths and credentials are excluded from public artifacts; Aeglius is the public developer identity.

The sidebar uses an animated clipping host around a stable-width native editor layout. This fixes both narrow-window clipping and repeated layout work during expansion. Its initial bounds are synchronized explicitly because dock layout can finish before a Resize handler is attached; tests assert this before any resize. Shared system fonts bound cache growth; the application disposes them once after the message loop. See `VERIFICATION.md` for measured results and explicit test limits.
