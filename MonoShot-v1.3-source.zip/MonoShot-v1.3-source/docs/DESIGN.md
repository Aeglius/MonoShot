# MonoShot v1.3 — Skin and layout guide

This demo establishes replaceable visuals around stable native functionality. It retains black/white/gray surfaces, system fonts, native window behavior and restrained feedback, with a custom GDI+ title bar. It does not load PSD files.

## Replacement map

| PSD design area | Primary implementation point | Preserved contract |
| --- | --- | --- |
| Palette, selected/hover/pressed/disabled/focus | Design.cs / Palette | UI state and keyboard behavior |
| Custom title bar and caption icons | WindowChrome.cs / CaptionButton | Native system commands, keyboard and accessible controls |
| Window frame geometry | Design title/caption/resize tokens + Native.cs | Resize hit codes, monitor work-area bounds, system menus |
| Font, corner radius, dimensions and spacing | Design.cs | DPI-aware logical units |
| Navigation tabs and indicator | WorkspaceNavigation.cs / MonoButton | Page selection, focus and shared motion |
| Toolbars | WorkspacePage.Toolbar / Button | Semantic WorkspaceAction events |
| Large preview / thumbnail | Controls.cs / ImageCanvas | Borrowed image, original aspect ratio |
| Zoom bar and image header | CapturePage + WorkspaceState.View | Actual percentage, original filename and pixel dimensions |
| Adjacent analysis panel | CapturePage.SideHost / AnalysisPage.SetSidebar | Same native editors, task and shared bitmap |
| Prompt and result fields | InputSurface + AnalysisPage | Native text editing, selection and shared state |
| Settings | PreferencesPage / ThemeChoice | Existing setting names and CLI flow |
| Layout proportions | Design.AnalysisInputPercent / SettingsLabelPercent and Pages.cs | Page instances remain alive |
| Language and prompt presets | Strings.cs / PromptCatalog | Stable IDs and custom-text preservation |

When PSD is supplied, identify its logical canvas size, component boundaries, minimum size, states, font mapping and export assets. Prefer GDI+ shapes and system fonts for simple controls. Export only necessary artwork; do not bake text or entire interactive pages into images. Map PSD logical dimensions to tokens, then adjust the few local layout builders when structure requires it. Business and authentication code should remain independent of this replacement.

## Tokens and scaling

Colors, five shared fonts, round radius, spacing, page margins, header/navigation/status sizes, toolbar/button widths, thumbnail heights, field heights, layout ratios and motion durations live in Design.cs. Light/Dark and Ink/Blue/Green palettes include Selected, Hover, Pressed, Disabled and Focus feedback. High contrast uses system colors.

Dimensions are logical 96-DPI units. WinForms PerMonitorV2 is explicitly enabled in app.config and the existing native manifest/API fallback is retained. Paths are rebuilt on bounds/DPI change, not every paint. The title is custom-drawn; native styles and non-client messages provide window behavior. Combo boxes and scrollbars keep Windows chrome, which can differ from custom surfaces on older systems.

TitleBarHeight, CaptionButtonWidth, CaptionIconSize, ResizeBorder, NavigationHeight/ItemWidth, SidePanelWidth/SidebarMinimumHeight, PreviewPadding and ZoomBarHeight are centralized in Design. Palette adds Chrome, CloseHover/ClosePressed/CloseText so the close-button feedback also follows theme transitions and high contrast. Both languages share logical layouts; the Settings entry stays on the right.

P1 maps to CapturePage's grouped toolbar, filename/resolution row, large aspect-preserving canvas and bottom zoom controls. P2 maps to the same capture layout with its existing AnalysisPage reparented into SideHost. The analysis root uses stacked surfaces in side mode, returning to two columns on its full page. It is the same prompt/result/editor/thumbnail instances throughout. At short heights its root scrolls rather than losing the result field. P3 is replaced by vector caption glyphs, not copied as a raster asset.

At the minimum window size, the AI thumbnail reduces its height to preserve prompt editing space. Settings scroll vertically to keep all controls and the complete credits reachable. Layout uses flexible columns for both languages.

System mode reads the Windows app-theme preference and responds to user-preference notifications on the UI thread. It falls back to light/system-color behavior when that preference cannot be read. Actual theme changes while running and mixed-DPI movement remain manual validation items.

## Motion and interaction

MotionHub remains the only animation timer. Stopwatch elapsed time drives Linear, EaseOutCubic and EaseInOutCubic; a 16 ms interval is a scheduling hint, not a 60 FPS guarantee. Owner/channel uniqueness supports reversal and repeated triggers. Tracks stop when complete or disposed. Reduced animation and high contrast settle transitions immediately; readable toast hold time remains a real delay.

Navigation uses a 150 ms indicator and invalidates the union of its previous/current bounds. Resizing snaps the indicator to the current tab and cancels its old track. The top AI navigation item is the only AI entry; Capture chooses the image-first mode, while Full view inside the panel retains the independent analysis page. Ctrl+1/2/3 compatibility remains. Navigation reflects the active image/AI mode as well as full-page state.

CapturePage owns one analysis-panel channel on MotionHub, using Design.PanelMs (210 ms), PanelMinMs (80 ms) and EaseOutCubic. Its progress animates the sidebar viewport/gutter while SideHost stays at the final panel width. Native editor bounds do not reflow per frame. The preview is drawn directly at its current fit scale, without a cached transition bitmap. Reversal starts from the displayed progress and scales duration by distance. On closing, the host releases input immediately, remains mounted through the transition, then detaches on the UI dispatcher. A page change settles hidden motion; reduced motion settles immediately. Neither workflow changes task lifetime or image ownership. Layout containers use double buffering and skip unchanged integer-width frames.

Caption controls reuse 125 ms hover / 90 ms pressed tracks of the same MotionHub. No extra timer, blur or static repaint loop is added. Buttons and native text fields retain existing hover/press/focus feedback.

Tab, Enter and Space remain native. Ctrl+1/2/3 selects a page; Left/Right/Home/End on navigation tabs selects/focuses another tab. Pages retain their controls and last focused editor/selection. Unchanged prompt/result text is not reassigned during refresh.

## 中文摘要

PSD 接入以 Design.cs 的集中参数和少量自绘组件为主要入口；页面布局仅在结构需要时局部调整。保留原生文本编辑、键盘、无障碍、图像所有权及任务生命周期。不要将整个页面切成大图片，也不要为皮肤改动认证或业务流程。

当前 Demo 已提供选中态、任务导航提示、三页面与统一语言资源；正式 PSD 到位后再确定最终视觉与必要素材。
