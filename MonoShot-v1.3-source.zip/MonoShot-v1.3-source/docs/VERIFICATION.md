﻿# MonoShot v1.3 — Verification

## v1.3 / EA-01 / 2026-10-18

Current v1.3 result: **208 offline checks + 14 real-CLI/loopback scenarios passed**. EXE 153,088 bytes (+8 KiB); final full runner: 72 MiB working set, GDI/USER deltas 0/0, private-memory delta +6,804 KiB over 120 cycles, 0.0 ms idle CPU in 500 ms and first-form construction/show 214 ms. These are runner observations, not standalone-app/cold-start benchmarks. No real account/cloud request used.

Current implementation and measured verification: [EA01_FIX.md](EA01_FIX.md). Framework 4.8/C# 5/x64 and the existing authentication flow remain. AnalysisPolicy owns the versioned tool/context restrictions; Bridge validates stdout JSON and uses a separate task working directory. Framework-native JSON parsing adds System.Runtime.Serialization and System.Xml references, with no bundled DLL or NuGet.

The sections below are historical v1.2 measurements and implementation notes; they are not new v1.3 performance results.

## Executed checks

`build.ps1 -Test` compiled the application and offline fixtures with C# 5 / Framework 4.8 / x64, with no compiler warnings. **196 checks passed** for UI Motion (file version 1.2.0.3). Tests use isolated portable data and a real WinForms message loop. They do not read a real account, submit a cloud request or change the user's clipboard. The earlier Shell Demo passed 181 checks and the login fix passed 143; their observations remain historical below.

## UI Motion verification / 2026-10-17

Fifteen additional full-window checks use a controlled MotionHub clock to verify the single AI entry, selection state, real intermediate geometry, fixed content/editor width, retained closing content, continuous reversal, exact settlement after a long frame, Full view, unrelated zoom notifications, page-switch cleanup, shared image/prompt identity, reduced-motion open/close and disposal during motion. The actual opening intermediate frame and settled dark/light layouts were rendered and visually inspected. Existing shell, screenshot/export, task, login and close/cancellation checks remain in the full run.

The current EXE is 144,896 bytes, an increase of 2 KiB over Shell Demo. No dependency, full-size bitmap cache or timer was added. This full runner measured GDI/USER deltas of 0/0 across 120 capture/preview/page cycles, private-memory delta +9332 KiB, 72 MiB runner working set, zero idle CPU milliseconds over 500 ms and first-form construction/show at 170 ms. These runner observations include tests and renders, are not a standalone-app memory benchmark, and do not establish a stable frame rate. The earlier matched empty-window samples below belong to Shell Demo and have not been relabeled as new measurements.

The runtime uses the normal monotonic clock; tests control time rather than claiming that a 16 ms WinForms Timer produces 60 FPS. Physical motion quality on different displays, live cloud login, mixed-DPI monitors and Windows 11 Snap remain the manual boundaries listed below.

## Shell Demo verification / 2026-10-17

| Scope | Actually executed | Boundary |
| --- | --- | --- |
| Native frame | Window-style inspection, WM_NCHITTEST route, signed screen-coordinate packing | Physical drag/resize cursors and cross-monitor movement are manual |
| Resize geometry | All eight edges/corners at synthetic 100/150/200% geometry; disabled resize while maximized | These geometry tests are not actual DPI-monitor tests |
| Work area | Synthetic negative-origin/side-taskbar geometry; actual maximized client inside the current monitor work area | Auto-hide and other taskbar arrangements need device checks |
| Window commands | Actual maximize/restore, ten repeated cycles without size growth, native title double-click, minimize, restore from minimized maximized state, system Close | Physical Alt+F4/taskbar invocation remains manual; native command destinations were exercised |
| System menu / Snap | Implemented native menu route, caption hit test and maximize HTMAXBUTTON/child delegation | Alt+Space/right-click menu UX, Win+arrow/Win+Z and Windows 11 flyout were not physically exercised |
| Preview | Filename, aspect ratio, fit percentage/resize, 100% mapping, zoom limits, event-level mouse pan, same bitmap identity | Physical Ctrl+wheel/drag should be checked on target devices |
| AI sidebar | Same editor instance, prompt/selection retention across page/side mode, close/reopen, 50 open/close cycles, minimum-size scrollable layout | No cloud/model call used |
| Background task | Close side panel, replace current image, complete elsewhere, reopen with original task-image result provenance | Remote service cancellation not established |
| UI | Existing 18 Light/Dark/System bilingual page renders plus P1/P2 dark and minimum-size English sidebar renders; visually inspected | Real system personalization changes and mixed-DPI movement remain manual |
| Existing regressions | Capture/import/export fixtures, state/keyboard handlers, cancellation/closure and all prior login timeout/dispatch/teardown checks | Actual clipboard and live browser authorization were untouched |

Tests exposed and fixed native caption printing, toolbar preferred-width wrapping, maximized resize-border overflow, cumulative restore-size growth and clipped side-panel buttons. The actual displayed client, not the native resize shadow rectangle, is the work-area boundary. Shell-only diagnostics are available as `build.ps1 -ShellOnly`; they deliberately do not produce the full-test packaging marker.

No additional assemblies, runtime, NuGet dependencies, animation timer or persistent worker thread were introduced. This earlier Shell Demo used immediate sidebar changes; UI Motion supersedes them with the clipped transition described above. Caption feedback shares MotionHub.

### Resource comparison

Both samples use the same separate STA reflection helper, an empty offscreen preview window, 800 ms settlement and a 500 ms idle CPU sample. The helper does not load an image, use an account or force GC. These are local observations including the helper/CLR, not a cold-start benchmark, guaranteed memory budget or claim of a sub-10-MiB application.

| Observation | Previous login fix | Shell Demo |
| --- | ---: | ---: |
| EXE bytes | 122,368 | 142,848 |
| Empty-window working set | 44,032,000 B (41.99 MiB) | 44,331,008 B (42.28 MiB) |
| Empty-window private memory | 30,449,664 B (29.04 MiB) | 30,580,736 B (29.16 MiB) |
| Idle CPU over 500 ms | 0 ms | 0 ms |
| GDI objects | 100 | 100 |
| USER objects | 91 | 107 |

The EXE adds 20 KiB; the measured working-set difference is about 292 KiB and private-memory difference is 128 KiB. More native controls explain the USER object increase; no additional full-size image cache exists. Archive lengths/checksums are generated during packaging. The older portable ZIP was 64,854 bytes.

The final full runner measured first-form construction/show at 200 ms, 71 MiB runner working set, zero idle CPU milliseconds over 500 ms, and GDI/USER deltas of 0/0 across 120 capture/preview/page cycles (private-memory delta +6972 KiB). Test renders and fixtures contribute to this footprint. The sidebar's separate 50-cycle check retained image/editor identities and bounded GDI usage.

### Known limits

The 940 x 660 logical minimum supports current bilingual toolbars but cannot fit every narrow Snap zone. The maximize hit code follows [Microsoft's Snap guidance](https://learn.microsoft.com/en-us/windows/apps/desktop/modernize/ui/apply-snap-layout-menu), but actual Windows 11 Snap Layouts behavior is not confirmed in this environment. Native combo boxes and scrollbars remain OS-dependent. No final PSD, PSD parser or code signature is included.

## Login fix verification / 2026-10-17

Added offline checks for immediate waiting UI; official-shaped link plus synthetic code received on separate stdout/stderr streams; silent and banner-only startup timeout; successful authorization after the shorter startup window; navigation during sign-in; network failure containing an authentication URL; unsupported arguments; retained bilingual safe failure guidance; invalid/edited connection paths; repeated cancellation; close during sign-in; clearing ephemeral codes; and final output without a newline at process exit. The new timeout tests use an 800 ms initial window to exercise the same lifecycle without waiting 30 seconds per case; production uses 30 seconds and retains the original ten-minute total window.

The login-ready and timeout states were rendered and visually inspected at the current desktop DPI. These fixtures never contact a service. They establish display and lifecycle behavior, not the root cause of a particular user's network failure or real account availability. A CLI that buffers all output until it exits cannot be made to flush by the app; the initial deadline prevents indefinite waiting without instructions.

That login-fix executable was 122,368 bytes, an increase of 4,608 bytes (4.5 KiB) from the earlier v1.2-skindemo executable. No assemblies or NuGet dependencies were added. That run measured zero idle CPU milliseconds over 500 ms, 70 MiB working set for the test runner, and 119 ms for the first form construction/show. After warmup, 120 capture/preview/page cycles measured GDI delta -135, USER delta 0 and private-memory delta +6144 KiB. The negative GDI delta includes resource reclamation from earlier test forms and is not a standalone leak measurement. These runner observations are historical.

| Area | Executed coverage |
| --- | --- |
| Build contract | Framework 4.8 metadata, x64, baseline assembly allowlist, assembly version 1.2.0.0 and UI version v1.2-skindemo |
| Images | Negative/reversed/clipped geometry; PNG alpha, JPEG white transparency, BMP; dimensions, atomic overwrite and released import handle |
| Capture | Synthetic region mouse-event pipeline and crop size, Escape cancellation, repeated overlay disposal; close during capture delay |
| Settings | Legacy keys, atomic updates and optional defaults; bilingual string inventory and stable unique preset IDs |
| Motion | Easing, elapsed time, reversal, unique channels, reduced motion, readable toast hold, disposal and idle timer shutdown |
| Layout | 18 renders across three pages, two languages and Light/Dark/System; large and minimum windows; appearance controls; scrolled credits render |
| State | One image borrowed by both previews; retained prompt/selection/result; 60 rapid page changes without task/image loss |
| Task identity | Frozen image pixels/version/dimensions and prompt; original task image remains identified after replacement |
| Background work | Duplicate submit blocked, completion while Settings is visible, cancellation rejects output from a fixture ignoring its token, timeout/network recovery and prior-result retention |
| Authentication boundary | Offline device-login process, result preservation, instruction cleanup; null ambient synchronization context explicitly exercised |
| Threads and closure | Worker mutation rejected before notification, explicit UI dispatch, cancel/cleanup on close, completion after forced disposal |
| Keyboard/layout | Unit-level Ctrl+2 and arrow handlers, focus/indicator settlement, resize alignment and visible-page Tab traversal |
| CLI | Quoting, isolated environment, UTF-8 transport, noisy stderr, error categories, deadline, cancellation and child-process cleanup |

These are in-process event/render and offline process tests. They do not represent physical mouse/keyboard input or a real cloud account. The synthetic overlay is not a protected-desktop/HDR/multi-monitor capture test. System mode is constructed and rendered, but changing actual Windows personalization settings was not automated.

## Crash reported during development

A reported MonoShot.Tests.exe crash was reproduced as an unhandled InvalidOperationException in a login progress callback: Progress<T> fell back to the thread pool when no UI context was present. A second attempt relying on a captured WinForms context exposed stale dispatch handles between test windows. The final implementation uses explicit owner-window dispatch, disposal-aware pending-post completion and no ambient Progress<T> fallback. The test harness keeps a real message loop alive while forms open/close.

The null-context sign-in, cancel/close and late-disposal tests now pass. Unhandled test exceptions are still failures with nonzero exit status and safe type/method diagnostics; they are not converted into success. No raw credential or CLI output is logged.

## Resource and size observations

Measurements are local observations, not universal limits. No forced GC is used.

| Observation | v1.1 baseline | v1.2-skindemo |
| --- | ---: | ---: |
| Executable bytes | 89,600 | 117,760 |
| Empty hidden standalone app working set | 30.0 MiB | 30.6 MiB |
| Empty hidden standalone app private memory | 23.4 MiB | 23.7 MiB |
| Standalone idle CPU over 500 ms | 0 ms | 0 ms |

Standalone samples used fresh isolated portable folders, waited for input-idle plus 800 ms, and then sampled 500 ms of idle CPU. They did not load an image or log in. Actual memory depends strongly on image dimensions and running operations. The release includes no bundled runtime or third-party UI library.

The v1.1 clean ZIP was 49,642 bytes and its six files totalled 103,706 logical bytes. Current archive lengths and checksums are generated at packaging time; logical file lengths do not measure filesystem cluster allocation. The new executable adds 28,160 bytes (27.5 KiB).

After warmup, 120 combined overlay/preview/page cycles measured GDI delta **0**, USER delta **0**, and private-memory change **+8888 KiB**. The first main-form construction/show in the runner took **110 ms**; the runner working set after renders/resource checks was **70 MiB**, with **0 ms** idle CPU over 500 ms. The runner contains all tests and renders; its working set is not the standalone application footprint or a cold-start benchmark.

## Release procedure

Packaging verifies the last successful test input/binary/configuration hashes, stages explicit portable/source allowlists, rejects directory links/unexpected files and scans public text. Private account data, screenshots, drafts, temporary files and test renders are excluded. Separate source and portable folders/ZIPs and SHA-256 checksums are produced without overwriting earlier releases.

Validate extracted archives with check-public.ps1; rebuild the extracted source in an isolated cache folder. Preserve v1.1 releases for comparison. A running previous development executable can be preserved in the project cache during a build; restart it to use the new version.

## Manual verification still required

- Physical region selection, full virtual-desktop capture and Ctrl+Alt+A hotkey interactions on the user's actual monitor arrangement.
- Clipboard image/file-list copy and paste, busy clipboard contention and native editing with real applications. Automated tests deliberately leave current clipboard data untouched.
- 125%, 150% and 200% DPI; movement between mixed-DPI/negative-origin monitors; display reconnection and session-lock transitions. Current renders use the available desktop DPI.
- Switching Windows app theme while System mode is active, high contrast and reduced-motion settings on target machines. No OS settings were changed for tests.
- Physical keyboard/Tab/IME/accessibility-reader behavior. Unit-level handlers and native focus traversal were executed, not a full assistive-technology certification.
- Real browser device-code login, service/network behavior, model availability and cloud analysis. The authentication protocol and CLI request flags were preserved.
- HDR/protected content and secure desktops, subject to Windows/GDI limitations.

No PSD was supplied or parsed. This is the structural skin demo; native combo/scrollbar chrome remains OS-dependent. The executable is unsigned.

## 中文摘要

本轮 UI Motion 的 196 项离线回归通过。测试程序崩溃的原有修复继续保留：登录和任务回调显式投递到主窗口，销毁后回调有保护；测试使用真实消息循环。回归仍覆盖空同步上下文、关闭取消、迟到结果与销毁后完成。

三页与侧栏共用图像，保留 Prompt/选择位置/结果；关闭侧栏不会取消分析。实际原生消息验证了最大化、还原、双击、最小化与系统关闭，八方向命中测试及负坐标采用几何验证。120 次遮罩/预览/切页循环的 GDI、USER 增量均为 0。相同空窗口辅助进程的工作集约从 41.99 MiB 到 42.28 MiB，测试进程约 71 MiB，两者不可混用。历史低于 10 MiB 的数据不作为本次承诺。

真实账号、系统剪贴板、实机高 DPI 多屏、物理输入及 HDR/受保护画面未自动实测，以上清单明确列出。PSD 接入仍是后续的视觉替换与局部布局工作。
