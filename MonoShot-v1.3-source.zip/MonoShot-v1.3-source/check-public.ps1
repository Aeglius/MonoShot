﻿param(
    [Parameter(Mandatory=$true)][string]$Root,
    [ValidateSet('source','portable')][string]$Kind = 'source'
)
$ErrorActionPreference = 'Stop'
$scanRoot = [IO.Path]::GetFullPath($Root)
if (!(Test-Path -LiteralPath $scanRoot -PathType Container)) { throw 'Public scan requires an existing folder.' }
$rootFiles = @('.editorconfig','.gitattributes','.gitignore','MonoShot.sln','MonoShot.csproj',
    'build.ps1','package.ps1','check-public.ps1','readme.md','LICENSE','THIRD-PARTY-NOTICES.md',
    'CHANGELOG.md','CONTRIBUTING.md','SECURITY.md')
$docs = @('docs/ENGINEERING.md','docs/DESIGN.md','docs/VERIFICATION.md','docs/EA01_FIX.md','docs/EA01_SECURITY_TESTS.json')
$sourceFiles = @('AssemblyInfo.cs','AnalysisPolicy.cs','Bridge.cs','CaptureOverlay.cs','Controls.cs','Design.cs','MainForm.cs',
    'Motion.cs','Native.cs','Pictures.cs','Program.cs','Store.cs','Strings.cs','WorkspaceState.cs','AnalysisCoordinator.cs','WorkspaceNavigation.cs','Pages.cs','WindowChrome.cs','MonoShot.ico','app.config','app.manifest')
$allowed = @('MonoShot.exe','MonoShot.exe.config','readme.md','LICENSE','THIRD-PARTY-NOTICES.md','CHANGELOG.md')
if ($Kind -eq 'source') { $allowed = $rootFiles + $docs + @($sourceFiles | ForEach-Object { 'src/' + $_ }) + @('tests/FakeCodex.cs','tests/TestRunner.cs','tests/WorkspaceTests.cs','tests/ShellTests.cs','tests/security/PolicyArguments.cs','tests/security/run-security.ps1','tests/security/verify-policy.py') }
$patterns = [ordered]@{
    'absolute local path' = '(?i)\b[A-Z]:[\\/]|\\\\[A-Za-z0-9_.-]+\\|/(?:home|Users)/[^\s/]+/'
    'personal developer identity' = '(?i)\b' + ('Mr' + '\.' + 'Yuan') + '\b'
    'local network address' = '(?i)\b(?:10(?:\.\d{1,3}){3}|192\.168(?:\.\d{1,3}){2}|172\.(?:1[6-9]|2\d|3[01])(?:\.\d{1,3}){2}|127(?:\.\d{1,3}){3})\b|https?://(?:localhost|\[::1\])\b'
    'credential-shaped value' = '(?i)\bsk-[A-Za-z0-9_-]{20,}|\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|-----BEGIN (?:[A-Z]+ )?PRIVATE KEY-----|(?:api[_-]?key|access[_-]?token|refresh[_-]?token|client[_-]?secret)\s*[=:]\s*["'']?[A-Za-z0-9_/-]{16,}'
}
$publicHosts = @('learn.chatgpt.com','developers.openai.com','platform.openai.com','auth.openai.com','chatgpt.com','learn.microsoft.com','schemas.microsoft.com')
$failures = New-Object 'System.Collections.Generic.List[string]'
$seen = New-Object 'System.Collections.Generic.List[string]'
foreach ($item in Get-ChildItem -LiteralPath $scanRoot -Recurse -Force) {
    $relative = $item.FullName.Substring($scanRoot.TrimEnd('\','/').Length + 1).Replace('\','/')
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { $failures.Add("link: $relative"); continue }
    if ($item.PSIsContainer) {
        if ($Kind -eq 'portable' -or $relative -notin @('src','tests','tests/security','docs')) { $failures.Add("unexpected folder: $relative") }
        continue
    }
    $seen.Add($relative)
    if ($relative -notin $allowed) { $failures.Add("unexpected file: $relative"); continue }
    if ([IO.Path]::GetExtension($relative) -in @('.exe','.ico')) { continue }
    $content = [IO.File]::ReadAllText($item.FullName)
    # The independent model fixture intentionally binds only the fixed loopback address.
    # This exception is limited to that source file; private/LAN addresses still fail the scan.
    $privacyContent = $content
    $loopbackTestAddress = [Net.IPAddress]::Loopback.ToString()
    if ($relative -eq 'tests/security/verify-policy.py') { $privacyContent = $content.Replace($loopbackTestAddress, 'LOOPBACK_TEST_ADDRESS') }
    foreach ($rule in $patterns.GetEnumerator()) {
        if ($privacyContent -match $rule.Value) { $failures.Add($rule.Key + ': ' + $relative) }
    }
    foreach ($url in [regex]::Matches($content, 'https?://[^\s"''<>)]+' , 'IgnoreCase')) {
        if ($relative -eq 'tests/security/verify-policy.py' -and $url.Value -eq ('http' + '://' + $loopbackTestAddress + ':')) { continue }
        $address = $null
        if (![Uri]::TryCreate($url.Value, [UriKind]::Absolute, [ref]$address) -or
            ($address.Host -notin $publicHosts -and !($address.Host -eq 'github.com' -and $address.AbsolutePath -match '^/openai/codex(?:/|$)'))) {
            $failures.Add('non-public URL: ' + $relative)
        }
    }
}
foreach ($expected in $allowed) { if ($expected -notin $seen) { $failures.Add("missing file: $expected") } }
if ($failures.Count) {
    # Print only rule names and relative filenames, never the sensitive matching text.
    $failures | ForEach-Object { Write-Output ('FAIL: ' + $_) }
    throw 'Public artifact scan failed. Review the listed files before publication.'
}
Write-Output ("PASS: public $Kind allowlist and privacy scan ($($seen.Count) files).")
