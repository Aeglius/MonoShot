﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Versioning;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace MonoShot.Tests
{
    internal static partial class TestRunner
    {
        private static readonly List<string> Report = new List<string>();
        private static string root, fixture;
        [STAThread]
        private static int Main(string[] arguments)
        {
            bool shellOnly = arguments.Length == 3 && arguments[2] == "--shell-only";
            if (arguments.Length != 2 && !shellOnly) { Console.Error.WriteLine("Use build.ps1 -Test to run the isolated regression checks."); return 2; }
            root = Path.GetFullPath(arguments[0]); fixture = Path.GetFullPath(arguments[1]);
            AppDomain.CurrentDomain.UnhandledException += (sender, e) => {
                Exception failure = e.ExceptionObject as Exception;
                Report.Add("RESULT: FAIL / unhandled background exception / " + (failure == null ? "unknown" : failure.GetType().Name));
                if (failure != null) { StackFrame[] trace = new StackTrace(failure).GetFrames(); if (trace != null) Report.Add("METHODS: " + String.Join(" > ", trace.Take(8).Select(frame => frame.GetMethod().DeclaringType.Name + "." + frame.GetMethod().Name))); }
                WriteReport(); Environment.Exit(1);
            };
            try
            {
                Store.Initialize(root); Native.InitializeDpi(); Application.SetUnhandledExceptionMode(UnhandledExceptionMode.ThrowException); Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
                int exitCode = 1;
                // Keep a real WinForms message loop alive while test windows come and go.
                // DoEvents alone tears down/recreates thread dispatchers between forms.
                using (Control host = new Control())
                {
                    host.CreateControl();
                    host.BeginInvoke((Action)(() => {
                        try
                        {
                            if (shellOnly) { Directory.CreateDirectory(Path.Combine(root, "renders")); Store.Write("cli", fixture); CheckShellAndWorkspace(); }
                            else { CheckFramework(); CheckPictures(); CheckSettings(); CheckMotion(); CheckSecrets(); CheckBridge(); CheckUiAndResources(); }
                            Report.Add("RESULT: PASS (offline; no real account or cloud request used)"); WriteReport(); exitCode = 0;
                        }
                        catch (Exception error) { ReportFailure(error); }
                        finally { Application.ExitThread(); }
                    }));
                    Application.Run();
                }
                Design.DisposeFonts(); return exitCode;
            }
            catch (Exception error)
            {
                ReportFailure(error); return 1;
            }
        }
        private static void ReportFailure(Exception error)
        {
            // Test names and exception types only. Never emit raw process output or machine paths.
            Report.Add("RESULT: FAIL / " + error.GetType().Name + " / " + (error is CheckFailed ? error.Message : "See the failing test stage"));
            StackFrame[] frames = new StackTrace(error).GetFrames();
            if (frames != null) Report.Add("METHODS: " + String.Join(" > ", frames.Take(8).Select(frame => frame.GetMethod().DeclaringType.Name + "." + frame.GetMethod().Name)));
            WriteReport();
        }
        private sealed class CheckFailed : Exception { public CheckFailed(string name) : base(name) { } }
        private static void Check(bool condition, string name)
        {
            if (!condition) throw new CheckFailed(name);
            Report.Add("PASS: " + name); WriteReport();
        }
        private static void WriteReport() { Directory.CreateDirectory(root); File.WriteAllLines(Path.Combine(root, "verification.txt"), Report, new UTF8Encoding(false)); }

        private static void CheckFramework()
        {
            TargetFrameworkAttribute target = (TargetFrameworkAttribute)Attribute.GetCustomAttribute(Assembly.GetExecutingAssembly(), typeof(TargetFrameworkAttribute));
            Check(target != null && target.FrameworkName == ".NETFramework,Version=v4.8", "Framework 4.8 metadata preserved");
            Check(Environment.Is64BitProcess, "x64 process");
            Check(Assembly.GetExecutingAssembly().GetReferencedAssemblies().All(a => new[] { "mscorlib", "System", "System.Core", "System.Drawing", "System.Windows.Forms", "System.Runtime.Serialization", "System.Xml" }.Contains(a.Name)), "only Windows/.NET Framework references (including native JSON trace parser)");
        }
        private static void CheckPictures()
        {
            Check(Pictures.Selection(new Point(90, 80), new Point(-10, 20), new Size(100, 100)) == new Rectangle(0, 20, 90, 60), "reverse selection clips bounds");
            Check(Pictures.Selection(new Point(-300, -50), new Point(-20, -1), new Size(100, 100)).IsEmpty, "selection outside negative origin is empty");
            using (Bitmap bitmap = new Bitmap(320, 180, PixelFormat.Format32bppArgb))
            {
                using (Graphics graphics = Graphics.FromImage(bitmap))
                {
                    graphics.Clear(Color.Transparent); graphics.FillRectangle(Brushes.Black, 20, 30, 280, 60);
                    using (Font font = new Font(SystemFonts.MessageBoxFont.FontFamily, 16)) graphics.DrawString("MonoShot / Aeglius", font, Brushes.White, 30, 44);
                }
                foreach (string extension in new[] { "png", "jpg", "bmp" })
                {
                    string file = Path.Combine(root, "sample." + extension); Pictures.Export(bitmap, file); Pictures.Export(bitmap, file);
                    using (Bitmap loaded = Pictures.Load(file))
                    {
                        Check(loaded.Size == bitmap.Size, "full-resolution export and atomic overwrite: " + extension);
                        if (extension == "png") Check(loaded.GetPixel(0, 0).A == 0, "PNG alpha retained");
                        if (extension == "jpg") Check(loaded.GetPixel(0, 0).R > 245, "JPEG transparency flattens to white");
                    }
                }
                string source = Path.Combine(root, "sample.png");
                using (Bitmap loaded = Pictures.Load(source)) { File.Move(source, source + ".moved"); File.Move(source + ".moved", source); Check(loaded.Width == 320, "image import releases source file handle"); }
            }
        }
        private static void CheckSettings()
        {
            Store.Write("language", "zh"); Store.Write("model", "fixture-model"); Store.Write("cli", fixture);
            Store.Write("prompt", "测试 draft"); Store.Write("prompt", "测试 updated draft");
            Check(Store.Read("language", "") == "zh" && Store.Read("model", "") == "fixture-model" && Store.FindCli() == fixture, "legacy configuration keys remain readable");
            Check(Store.Read("prompt", "") == "测试 updated draft" && Directory.GetFiles(Store.Data, "*.tmp").Length == 0, "atomic settings update leaves no temporary file");
            Check(Store.Read("nonexistent", "fallback") == "fallback", "missing optional settings use defaults");
            Store.Write("theme", "light"); Store.Write("accent", "ink");
        }
        private static void CheckMotion()
        {
            double now = 0, value = 0; bool allowed = true; object owner = new object();
            using (MotionHub hub = new MotionHub(() => now, () => allowed))
            {
                Check(MotionHub.Curve(Ease.Linear, .5) == .5 && MotionHub.Curve(Ease.OutCubic, .5) == .875 && MotionHub.Curve(Ease.InOutCubic, .5) == .5, "all three easing formulas");
                hub.Animate(owner, "hover", 0, 1, 100, Ease.OutCubic, v => value = v, null);
                now = 50; hub.Step(); Check(Math.Abs(value - .875) < .0001 && hub.ActiveCount == 1, "monotonic elapsed-time interpolation");
                double current = value; hub.Animate(owner, "hover", current, 0, 100, Ease.OutCubic, v => value = v, null);
                hub.Step(); Check(Math.Abs(value - current) < .0001 && hub.ActiveCount == 1, "reversal starts at the current value without duplicate tracks");
                now = 1000; hub.Step(); Check(value == 0 && hub.ActiveCount == 0 && !hub.IsRunning, "long frame reaches endpoint and stops scheduler");
                hub.Animate(owner, "hover", 0, 1, 100, Ease.Linear, v => value = v, null); allowed = false; hub.Step();
                Check(value == 1 && !hub.IsRunning, "reduced motion finishes active animations");
                hub.Animate(owner, "focus", 0, 1, 100, Ease.Linear, v => value = v, null); Check(value == 1 && !hub.IsRunning, "reduced motion avoids starting a timer");
                bool held = true; hub.Delay(owner, "hold", 2000, () => held = false); now += 100; hub.Step();
                Check(held && hub.IsRunning, "reduced motion retains the readable toast hold duration");
                now += 2000; hub.Step(); Check(!held && !hub.IsRunning, "toast hold completes and stops the shared scheduler");
                allowed = true; hub.Animate(owner, "hover", 0, 1, 100, Ease.Linear, v => value = v, null); hub.Cancel(owner, null);
                Check(hub.ActiveCount == 0 && !hub.IsRunning, "owner cancellation releases active tracks");
                hub.Animate(owner, "hover", 0, 1, 100, Ease.Linear, v => value = v, null); hub.Dispose(); now += 500; hub.Step();
                Check(hub.ActiveCount == 0, "disposed scheduler cannot access controls");
            }
            foreach (bool dark in new[] { false, true }) foreach (string accent in new[] { "ink", "blue", "green" })
            {
                Palette palette = Palette.Create(dark, accent);
                Check(Contrast(palette.Text, palette.Surface) >= 4.5 && Contrast(palette.OnAccent, palette.Accent) >= 4.5, "theme text contrast: " + (dark ? "dark/" : "light/") + accent);
            }
        }
        private static double Contrast(Color a, Color b)
        {
            Func<Color, double> luminance = c => {
                Func<double, double> linear = value => value <= .04045 ? value / 12.92 : Math.Pow((value + .055) / 1.055, 2.4);
                return .2126 * linear(c.R / 255.0) + .7152 * linear(c.G / 255.0) + .0722 * linear(c.B / 255.0);
            };
            double x = luminance(a), y = luminance(b); return (Math.Max(x, y) + .05) / (Math.Min(x, y) + .05);
        }
        private static void CheckSecrets()
        {
            string fake = "sk-" + new string('z', 24);
            Check(!Secrets.ForDisplay("api_key=" + fake).Contains(fake), "credential-shaped values are removed from display text");
            Check(Secrets.ForDisplay("DEVICE-CODE-FIXTURE").Contains("DEVICE-CODE-FIXTURE"), "device authorization instructions remain usable in ephemeral UI");
        }
        private static void CheckBridge()
        {
            Check(Bridge.Quote("a b\\") == "\"a b\\\\\"" && Bridge.Quote("x\"y") == "\"x\\\"y\"", "Windows argument quoting");
            ProcessStartInfo info = Bridge.StartInfo(fixture, "");
            Check(info.EnvironmentVariables["CODEX_HOME"] == Store.CodexHome && info.EnvironmentVariables["TEMP"] == Store.Temp && !info.UseShellExecute && info.CreateNoWindow, "portable isolated CLI environment and shell-free launch");
            string answer = Bridge.Analyze(fixture, Path.Combine(root, "sample.png"), "测试 prompt with \"quotes\" & punctuation", "", CancellationToken.None).GetAwaiter().GetResult();
            Check(answer.StartsWith("FAKE_OK") && Directory.GetFiles(Store.Temp, "answer-*.md").Length == 0, "UTF-8 prompt, image, output retrieval, and temporary answer cleanup");
            Check(Directory.GetDirectories(Store.Temp, "analysis-*").Length == 0, "analysis working directory and answer are cleaned after success");
            foreach (string name in new[] { "AGENTS.md", "AGENTS.override.md" })
            {
                string contextFile = Path.Combine(Store.CodexHome, name); bool contextRejected = false;
                File.WriteAllText(contextFile, "SYNTHETIC_UNRELATED_CONTEXT");
                try { Bridge.Analyze(fixture, Path.Combine(root, "sample.png"), "测试 quotes", "", CancellationToken.None).GetAwaiter().GetResult(); }
                catch (CliException error) { contextRejected = error.Kind == CliFailure.PolicyContext; }
                Check(contextRejected && File.ReadAllText(contextFile) == "SYNTHETIC_UNRELATED_CONTEXT", "account instructions fail closed without modification: " + name);
                File.Delete(contextFile);
            }
            string unverified = Path.Combine(Path.GetDirectoryName(fixture), "FakeCodexUnverified.exe");
            File.Copy(fixture, unverified, true);
            bool policyRejected = false;
            try { Bridge.Analyze(unverified, Path.Combine(root, "sample.png"), "测试 quotes", "", CancellationToken.None).GetAwaiter().GetResult(); }
            catch (CliException error) { policyRejected = error.Kind == CliFailure.PolicyUnsupported; }
            Check(policyRejected, "unverified CLI version fails before analysis starts");
            File.Delete(unverified);
            foreach (string mode in new[] { "fixture-command", "fixture-malformed", "fixture-unknown", "fixture-incomplete", "fixture-config" })
            {
                policyRejected = false; Stopwatch policyWatch = Stopwatch.StartNew();
                try { Bridge.Analyze(fixture, Path.Combine(root, "sample.png"), "测试 quotes", mode, CancellationToken.None).GetAwaiter().GetResult(); }
                catch (CliException error) { policyRejected = error.Kind == (mode == "fixture-config" ? CliFailure.PolicyUnsupported : CliFailure.PolicyViolation); }
                Check(policyRejected && policyWatch.ElapsedMilliseconds < 5000, "restricted or unverifiable trace rejected promptly: " + mode);
            }
            Check(Directory.GetDirectories(Store.Temp, "analysis-*").Length == 0, "failed analysis cleans its answer and unique working directory");
            Check(Errors.Key(new CliException(CliFailure.PolicyUnsupported)) == "ErrorAnalysisVersion" && Errors.Key(new CliException(CliFailure.PolicyViolation)) == "ErrorAnalysisPolicy", "analysis policy failures have separate safe UI messages from sign-in failures");
            AnalysisPolicy safeTrace = new AnalysisPolicy();
            safeTrace.OutputLine("{\"type\":\"thread.started\"}"); safeTrace.OutputLine("{\"type\":\"turn.started\"}");
            safeTrace.OutputLine("{\"type\":\"item.completed\",\"item\":{\"type\":\"agent_message\",\"text\":\"command_execution is quoted content only\"}}");
            safeTrace.OutputLine("{\"type\":\"turn.completed\"}"); safeTrace.Complete();
            Check(true, "trace validation parses envelopes without mistaking quoted result text for a tool call");
            bool rejected = false, authentication = false, timedOut = false, canceled = false;
            try { Bridge.Run(fixture, "--flood", null, null, CancellationToken.None, 4).GetAwaiter().GetResult(); }
            catch (CliException error) { rejected = error.Kind == CliFailure.Rejected && error.Message.Length < 100; }
            Check(rejected, "noisy failed CLI drains output and returns a bounded safe error");
            try { Bridge.Run(fixture, "--auth-fail", null, null, CancellationToken.None, 4).GetAwaiter().GetResult(); }
            catch (CliException error) { authentication = error.Kind == CliFailure.Authentication; }
            Check(authentication, "authentication failure classification without raw stderr");
            Stopwatch watch = Stopwatch.StartNew();
            using (CancellationTokenSource cancel = new CancellationTokenSource(150))
            {
                try { Bridge.Run(fixture, "--wait", null, null, cancel.Token, 4).GetAwaiter().GetResult(); }
                catch (OperationCanceledException) { canceled = true; }
            }
            Check(canceled && watch.ElapsedMilliseconds < 4000, "cancel terminates child within a bounded wait");
            try { Bridge.Run(fixture, "--wait", null, null, CancellationToken.None, 1).GetAwaiter().GetResult(); }
            catch (TimeoutException) { timedOut = true; }
            Check(timedOut, "CLI deadline is independent of user cancellation");
            string tail = null;
            string login = Bridge.Run(fixture, "--login-fixture", null, line => { tail = line; }, CancellationToken.None, 3).GetAwaiter().GetResult();
            Check(login.Length == 0 && tail == "DEVICE-CODE-FIXTURE", "unterminated final login output drains before return and is not returned as an analysis or log");
            Check(Process.GetProcessesByName("FakeCodex").Length == 0, "no fixture child remains after completion and cancellation");
        }

    }
}
