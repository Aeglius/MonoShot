﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MonoShot.Tests
{
    internal static partial class TestRunner
    {
        private static void CheckUiAndResources()
        {
            string render = Path.Combine(root, "renders"); Directory.CreateDirectory(render);
            Stopwatch startup = Stopwatch.StartNew();
            using (MainForm warmup = new MainForm(true)) { warmup.Show(); Application.DoEvents(); warmup.Close(); }
            startup.Stop();
            Check(Strings.Keys.All(key => !String.IsNullOrEmpty(Strings.Get("zh", key)) && !String.IsNullOrEmpty(Strings.Get("en", key))), "all centralized strings have two languages");
            Check(PromptCatalog.Items.Select(p => p.Id).Distinct().Count() == PromptCatalog.Items.Length, "prompt catalog has stable unique IDs");
            Check(Assembly.GetExecutingAssembly().GetName().Version.ToString() == "1.3.0.0" && Product.Version == "v1.3", "assembly and UI identify the v1.3 version");
            foreach (bool english in new[] { false, true }) foreach (string mode in new[] { "light", "dark", "system" })
            {
                using (MainForm form = new MainForm(true))
                {
                    form.State.SetLanguage(english ? "en" : "zh"); form.State.SetAppearance(mode, "ink");
                    form.Theme.ChangeMode(mode, "ink", false); form.ClientSize = new Size(english ? 924 : 1180, english ? 621 : 800);
                    form.Show(); Application.DoEvents();
                    Check(form.Text == Product.Name && form.Theme.Mode == mode, "version and theme mode: " + mode + (english ? "/en" : "/zh"));
                    Check(!form.AnalysisView.FindButton("analyze").Enabled && !form.CaptureView.FindButton("export").Enabled, "empty-image disabled states: " + mode + (english ? "/en" : "/zh"));
                    foreach (WorkspacePageId page in Enum.GetValues(typeof(WorkspacePageId)))
                    {
                        form.State.SelectPage(page); Pump(180);
                        string file = (english ? "en" : "zh") + "-" + mode + "-" + page + ".png";
                        using (Bitmap bitmap = new Bitmap(form.Width, form.Height)) { form.DrawToBitmap(bitmap, new Rectangle(Point.Empty, form.Size)); bitmap.Save(Path.Combine(render, file)); }
                        Control pageControl = page == WorkspacePageId.Capture ? (Control)form.CaptureView : page == WorkspacePageId.Analysis ? form.AnalysisView : (Control)form.SettingsView;
                        Check(pageControl.Visible && pageControl.ClientSize.Width > 800 && pageControl.ClientSize.Height > 400 && form.Navigation.Height > 30, "page layout rendered: " + file);
                    }
                    foreach (string accent in new[] { "ink", "blue", "green" }) { form.State.SetAppearance(mode, accent); form.Theme.ChangeMode(mode, accent, false); }
                    Check(form.State.Accent == "green" && form.SettingsView.Accent.SelectedIndex == 2, "appearance controls share state: " + mode + (english ? "/en" : "/zh"));
                    form.Close();
                }
            }
            CheckWorkspaceTasks(); CheckLoginLifecycle(); CheckShellAndWorkspace(); CheckKeyboardAndResize(); CheckOverlaySelection();
            Process process = Process.GetCurrentProcess();
            using (MainForm form = new MainForm(true))
            using (Bitmap snapshot = new Bitmap(320, 180))
            using (Bitmap target = new Bitmap(320, 180))
            {
                form.Show(); Application.DoEvents();
                for (int i = 0; i < 12; i++)
                {
                    using (CaptureOverlay overlay = new CaptureOverlay(snapshot, new Rectangle(-320, -180, 320, 180), true)) overlay.DrawToBitmap(target, new Rectangle(0, 0, 320, 180));
                    form.State.ReplaceImage(new Bitmap(640, 360), "fixture"); form.State.SelectPage((WorkspacePageId)(i % 3));
                }
                Pump(350); process.Refresh(); int gdiBefore = Native.GetGuiResources(process.Handle, 0), userBefore = Native.GetGuiResources(process.Handle, 1);
                long memoryBefore = process.PrivateMemorySize64;
                for (int i = 0; i < 120; i++)
                {
                    using (CaptureOverlay overlay = new CaptureOverlay(snapshot, new Rectangle(-320, -180, 320, 180), true)) overlay.DrawToBitmap(target, new Rectangle(0, 0, 320, 180));
                    form.State.ReplaceImage(new Bitmap(640, 360), "fixture"); form.State.SelectPage((WorkspacePageId)(i % 3));
                    if (i % 20 == 0) Application.DoEvents();
                }
                Pump(350); process.Refresh();
                int gdiDelta = Native.GetGuiResources(process.Handle, 0) - gdiBefore, userDelta = Native.GetGuiResources(process.Handle, 1) - userBefore;
                long memoryDelta = process.PrivateMemorySize64 - memoryBefore;
                Report.Add("RESOURCE: 120 capture/preview/page cycles GDI delta " + gdiDelta + "; USER delta " + userDelta + "; private-memory delta " + (memoryDelta / 1024) + " KiB"); WriteReport();
                Check(gdiDelta < 10 && userDelta < 16 && memoryDelta < 24 * 1024 * 1024, "shared-image and page lifecycles stabilize after warmup without forced GC");
                Pump(350); Check(!form.Motion.IsRunning, "idle UI has no active animation timer");
                TimeSpan cpuBefore = process.TotalProcessorTime; Pump(500); process.Refresh();
                Report.Add("MEASURED: first main-form construction/show " + startup.ElapsedMilliseconds + " ms; idle CPU over 500 ms " + (process.TotalProcessorTime - cpuBefore).TotalMilliseconds.ToString("F1") + " ms; runner working set " + (process.WorkingSet64 / 1024 / 1024) + " MiB");
                form.Close();
            }
            using (MainForm form = new MainForm(true))
            {
                form.Show(); Application.DoEvents(); form.CaptureView.FindButton("region").PerformClick(); Pump(20); form.Close(); Pump(250);
                Check(form.IsDisposed, "close during capture delay leaves no overlay or reopened window");
            }
            Report.Add("LIMITS: offline fixtures and current desktop DPI only; actual clipboard contents were untouched. Real cloud, physical input, mixed-monitor DPI, HDR and protected capture need manual confirmation.");
        }
        private static void CheckWorkspaceTasks()
        {
            TaskCompletionSource<string> response = new TaskCompletionSource<string>(); int calls = 0;
            string frozenPrompt = null; Color frozenPixel = Color.Empty; CancellationToken taskToken = CancellationToken.None;
            Func<string, string, string, string, CancellationToken, Task<string>> service = (cli, path, prompt, model, token) => {
                calls++; frozenPrompt = prompt; taskToken = token;
                using (Bitmap decoded = Pictures.Load(path)) frozenPixel = decoded.GetPixel(0, 0);
                return response.Task;
            };
            using (MainForm form = new MainForm(true, service))
            {
                form.Show(); Application.DoEvents(); WorkspaceState state = form.State;
                Bitmap first = new Bitmap(160, 90); first.SetPixel(0, 0, Color.Red); state.ReplaceImage(first, "fixture");
                Check(ReferenceEquals(first, form.CaptureView.Preview.Picture) && ReferenceEquals(first, form.AnalysisView.Thumbnail.Picture), "both previews borrow one full-resolution image");
                state.SelectPage(WorkspacePageId.Analysis); form.AnalysisView.PromptEditor.Editor.Text = "测试 old prompt with quotes";
                form.AnalysisView.PromptEditor.Editor.Focus(); form.AnalysisView.PromptEditor.Editor.Select(3, 5);
                state.SelectPage(WorkspacePageId.Settings); state.SelectPage(WorkspacePageId.Analysis);
                Check(state.Prompt == "测试 old prompt with quotes" && form.AnalysisView.PromptEditor.Editor.SelectionStart == 3 && form.AnalysisView.PromptEditor.Editor.SelectionLength == 5, "prompt and edit selection survive page round trip");
                long version = state.ImageVersion; Task running = form.Coordinator.StartAnalysis();
                Guid firstJob = state.CurrentJob.Id; state.EditPrompt("测试 edited prompt with quotes");
                Bitmap next = new Bitmap(80, 60); next.SetPixel(0, 0, Color.Blue); state.ReplaceImage(next, "fixture");
                Until(() => calls == 1, 3000); bool oldDisposed = false;
                try { first.GetPixel(0, 0); } catch (ArgumentException) { oldDisposed = true; }
                Check(oldDisposed && frozenPixel.ToArgb() == Color.Red.ToArgb() && frozenPrompt.Contains("old prompt") && !frozenPrompt.Contains("edited prompt"), "request freezes image pixels, version and prompt before await");
                Check(state.AnalysisJob.ImageVersion == version && state.AnalysisJob.ImageSize == new Size(160, 90), "task retains original image version and dimensions");
                Check(ReferenceEquals(running, form.Coordinator.StartAnalysis()) && calls == 1 && !form.AnalysisView.FindButton("analyze").Enabled, "repeated submit cannot start a second CLI request");
                for (int i = 0; i < 60; i++) state.SelectPage((WorkspacePageId)(i % 3));
                Check(state.IsWorking && !taskToken.IsCancellationRequested && ReferenceEquals(next, state.Image), "rapid page changes keep the task and image alive");
                MonoButton aiTab = (MonoButton)form.Navigation.Controls.Find("nav1", true).Single();
                Check(aiTab.Text.Contains(Strings.Get(state.Language, "Running")), "navigation reflects analysis running outside its page");
                state.SelectPage(WorkspacePageId.Settings); response.SetResult("FIRST_RESULT"); Until(() => running.IsCompleted, 3000);
                Check(state.Result == "FIRST_RESULT" && state.ResultJobId == firstJob && state.ResultImageVersion == version && state.AnalysisJob.Phase == JobPhase.Completed && state.Page == WorkspacePageId.Settings, "completion updates shared state without changing the visible page");
                state.SelectPage(WorkspacePageId.Analysis);
                Check(form.AnalysisView.ResultEditor.Editor.Text == "FIRST_RESULT" && form.AnalysisView.FindButton("analyze").Enabled, "result and buttons restore on return");
                response = new TaskCompletionSource<string>(); running = form.Coordinator.StartAnalysis(); Until(() => calls == 2, 3000);
                state.Cancel(); response.SetResult("STALE_RESULT_IGNORING_TOKEN"); Until(() => running.IsCompleted, 3000);
                Check(state.AnalysisJob.Phase == JobPhase.Canceled && state.Result == "FIRST_RESULT" && state.ResultJobId == firstJob && !state.IsWorking, "cancel rejects late output even when a service ignores its token");
                response = new TaskCompletionSource<string>(); running = form.Coordinator.StartAnalysis(); Until(() => calls == 3, 3000);
                response.SetException(new TimeoutException()); Until(() => running.IsCompleted, 3000);
                Check(state.AnalysisJob.Phase == JobPhase.TimedOut && form.AnalysisView.FindButton("analyze").Enabled && state.Result == "FIRST_RESULT", "timeout restores controls and preserves earlier result");
                response = new TaskCompletionSource<string>(); running = form.Coordinator.StartAnalysis(); Until(() => calls == 4, 3000);
                response.SetException(new CliException(CliFailure.Network)); Until(() => running.IsCompleted, 3000);
                Check(state.AnalysisJob.Phase == JobPhase.Failed && state.AnalysisJob.ErrorKey == "ErrorNetwork" && !state.IsWorking, "network failure restores task lifecycle without raw output");
                int notifications = 0; state.Changed += (s, e) => notifications++;
                bool wrongThreadRejected = false;
                try { Task.Run(() => state.EditPrompt("wrong thread")).GetAwaiter().GetResult(); } catch (InvalidOperationException) { wrongThreadRejected = true; }
                Check(wrongThreadRejected && notifications == 0, "state rejects worker-thread UI mutations before notification");
                string previousResult = state.Result;
                SynchronizationContext previousContext = SynchronizationContext.Current;
                try { SynchronizationContext.SetSynchronizationContext(null); running = form.Coordinator.StartLogin(); }
                finally { SynchronizationContext.SetSynchronizationContext(previousContext); }
                bool analysisBlockedDuringLogin = ReferenceEquals(running, form.Coordinator.StartAnalysis());
                state.SelectPage(WorkspacePageId.Capture); Until(() => state.AuthInstructions.Contains("FIXTURE") || running.IsCompleted, 3000);
                Check(state.CurrentJob.Kind == JobKind.Login && state.Result == previousResult && analysisBlockedDuringLogin, "offline device-login remains independent of analysis result");
                Until(() => running.IsCompleted, 4000);
                running.GetAwaiter().GetResult();
                Check(state.Connection == ConnectionPhase.SignedIn && state.AuthInstructions.Length == 0 && state.Result == previousResult, "login with a null ambient context returns to UI and clears ephemeral instructions");
                state.SelectPreset("ocr"); state.SetLanguage("en"); Check(state.Prompt == Strings.Get("en", "OcrPrompt"), "automatic preset follows language by stable ID");
                state.EditPrompt("custom prompt"); state.SetLanguage("zh"); Check(state.Prompt == "custom prompt", "language change preserves custom prompt and result");
                Bitmap unchanged = state.Image; Task load = form.LoadImage(Path.Combine(root, "invalid.png")); Until(() => load.IsCompleted, 3000);
                Check(ReferenceEquals(state.Image, unchanged) && !state.IsImageBusy, "invalid image import preserves current image and recovers controls");
                Task validLoad = form.LoadImage(Path.Combine(root, "sample.png")); Until(() => validLoad.IsCompleted, 3000);
                Check(state.Image.Size == new Size(320, 180) && ReferenceEquals(state.Image, form.AnalysisView.Thumbnail.Picture), "file-open workflow updates both shared previews once");
                Check(state.ImageName == "sample.png", "import stores only the image filename for the workspace heading");
                Pump(2700); Check(!form.Motion.IsRunning, "rapid navigation and toast tracks stop after settling"); form.Close();
            }
            bool entered = false;
            using (MainForm form = new MainForm(true, async (cli, path, prompt, model, token) => { entered = true; await Task.Delay(30000, token); return "UNEXPECTED"; }))
            {
                form.Show(); Application.DoEvents(); form.State.ReplaceImage(new Bitmap(64, 64), "fixture");
                Task running = form.Coordinator.StartAnalysis(); Until(() => entered, 3000);
                string ownedSnapshot = Path.Combine(Store.Temp, "image-" + form.State.CurrentJob.Id.ToString("N") + ".png"); form.Close();
                Until(() => running.IsCompleted && form.IsDisposed, 4000); Check(form.IsDisposed && !File.Exists(ownedSnapshot), "closing during analysis cancels, cleans its snapshot and disposes the window");
            }
            TaskCompletionSource<string> late = new TaskCompletionSource<string>(); entered = false;
            MainForm disposedForm = new MainForm(true, (cli, path, prompt, model, token) => { entered = true; return late.Task; });
            disposedForm.Show(); Application.DoEvents(); disposedForm.State.ReplaceImage(new Bitmap(32, 32), "fixture");
            Task orphan = disposedForm.Coordinator.StartAnalysis(); Until(() => entered, 3000); disposedForm.Dispose(); late.SetResult("LATE_DISPOSED");
            Until(() => orphan.IsCompleted, 3000); Check(orphan.Status == TaskStatus.RanToCompletion, "completion after forced disposal never accesses disposed controls");
            for (int i = 0; i < 6; i++)
            {
                entered = false;
                MainForm racing = new MainForm(true, (cli, path, prompt, model, token) => {
                    entered = true; TaskCompletionSource<string> canceled = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
                    token.Register(() => canceled.TrySetCanceled()); return canceled.Task;
                });
                racing.Show(); Application.DoEvents(); racing.State.ReplaceImage(new Bitmap(32, 32), "fixture");
                Task pending = racing.Coordinator.StartAnalysis(); Until(() => entered, 3000); racing.Dispose(); Until(() => pending.IsCompleted, 3000);
                pending.GetAwaiter().GetResult();
            }
            Check(true, "forced disposal tolerates cancellation completing during control teardown");
        }
        private static void CheckLoginLifecycle()
        {
            string savedCli = Store.Read("cli", "");
            try
            {
                Check(Secrets.HasDeviceInstructions("https://auth.openai.com/codex/device\nTEST-ONLY0") &&
                    !Secrets.HasDeviceInstructions("Synthetic CLI starting") &&
                    !Secrets.HasDeviceInstructions("https://auth.openai.com/\nAuthentication failed"), "device readiness requires both an official link and a code-shaped instruction");
                foreach (string scenario in new[] { "Silent", "Banner", "Network", "Unsupported", "Ready" })
                {
                    string cli = Path.Combine(Store.Temp, "FakeCodex" + scenario + ".exe"); File.Copy(fixture, cli, true); Store.Write("cli", cli);
                    using (MainForm form = new MainForm(true))
                    using (AnalysisCoordinator login = new AnalysisCoordinator(form.State, form, null, 800))
                    {
                        form.Show(); form.State.SelectPage(WorkspacePageId.Settings); Application.DoEvents();
                        Task running = login.StartLogin();
                        Check(form.SettingsView.Auth.Visible && form.SettingsView.Auth.Editor.Text == Strings.Get(form.State.Language, "LoginWaiting") &&
                            !form.SettingsView.FindButton("login").Enabled, "login immediately shows waiting instructions and blocks duplicates: " + scenario);
                        if (scenario == "Ready")
                        {
                            Until(() => form.State.AuthReady || running.IsCompleted, 3000);
                            Check(form.State.AuthReady && form.SettingsView.Auth.Editor.Text.Contains("TEST-ONLY0") &&
                                form.SettingsView.Auth.Height >= Design.Px(form, Design.TaskHeight), "stdout link and stderr device code are visible in the settings page");
                            using (Bitmap render = new Bitmap(form.Width, form.Height))
                            { form.DrawToBitmap(render, new Rectangle(Point.Empty, form.Size)); render.Save(Path.Combine(root, "renders", "login-ready.png")); }
                            form.State.SelectPage(WorkspacePageId.Capture); Pump(900);
                            Check(form.State.IsWorking && !running.IsCompleted, "received instructions lift only the startup deadline and page navigation keeps login running");
                        }
                        Until(() => running.IsCompleted, 4000); running.GetAwaiter().GetResult();
                        WorkspaceJob job = form.State.CurrentJob;
                        string expected = scenario == "Network" ? "ErrorNetwork" : scenario == "Unsupported" ? "ErrorCliVersion" : "ErrorLoginStart";
                        if (scenario == "Ready") Check(job.Phase == JobPhase.Completed && form.State.Connection == ConnectionPhase.SignedIn, "offline device login completes after the startup window");
                        else
                        {
                            Check(job.ErrorKey == expected && job.Phase == (scenario == "Silent" || scenario == "Banner" ? JobPhase.TimedOut : JobPhase.Failed), "login failure has the correct safe category: " + scenario);
                            Check(form.SettingsView.Auth.Visible && form.SettingsView.Auth.Editor.Text.Contains(Strings.Get(form.State.Language, expected)) &&
                                !form.SettingsView.Auth.Editor.Text.Contains("synthetic offline failure"), "failure remains readable without retaining raw CLI output: " + scenario);
                            form.State.SetLanguage("en");
                            Check(form.SettingsView.Auth.Editor.Text.Contains(Strings.Get("en", expected)), "failed-login guidance follows the interface language: " + scenario);
                            if (scenario == "Silent") using (Bitmap render = new Bitmap(form.Width, form.Height))
                            { form.DrawToBitmap(render, new Rectangle(Point.Empty, form.Size)); render.Save(Path.Combine(root, "renders", "login-timeout.png")); }
                        }
                        Check(form.State.AuthInstructions.Length == 0 && !form.State.AuthReady && form.SettingsView.FindButton("login").Enabled &&
                            !form.SettingsView.FindButton("cancel").Enabled, "ephemeral instructions clear and buttons recover: " + scenario);
                        form.Close();
                    }
                    File.Delete(cli);
                }
                Store.Write("cli", fixture);
                using (MainForm form = new MainForm(true))
                {
                    form.Show(); form.State.SelectPage(WorkspacePageId.Settings); form.State.EditConnection("missing-cli.exe", "");
                    form.SettingsView.FindButton("login").PerformClick();
                    Check(form.State.CurrentJob == null && form.State.StatusKey == "MissingCli", "invalid unsaved path cannot silently launch the previous CLI");
                    string cli = Path.Combine(Store.Temp, "FakeCodexReady.exe"); File.Copy(fixture, cli, true);
                    form.State.EditConnection(cli, ""); form.SettingsView.FindButton("login").PerformClick(); Task running = form.Coordinator.Running;
                    Check(form.State.IsWorking && form.State.CliPath == cli && Store.Read("cli", "") == cli, "login validates and saves the currently edited executable before starting");
                    Until(() => form.State.AuthReady || running.IsCompleted, 3000); form.State.Cancel(); Until(() => running.IsCompleted, 4000);
                    running.GetAwaiter().GetResult();
                    Check(form.State.CurrentJob.Phase == JobPhase.Canceled && form.State.AuthInstructions.Length == 0 && !form.SettingsView.Auth.Visible, "user cancellation remains distinct from startup timeout and clears the code");
                    for (int retry = 0; retry < 3; retry++)
                    {
                        running = form.Coordinator.StartLogin(); Until(() => form.State.AuthReady || running.IsCompleted, 3000);
                        form.State.Cancel(); Until(() => running.IsCompleted, 4000); running.GetAwaiter().GetResult();
                    }
                    Check(!form.State.IsWorking && form.SettingsView.FindButton("login").Enabled, "repeated start and cancel leaves no stale disabled login state");
                    running = form.Coordinator.StartLogin(); Until(() => form.State.AuthReady || running.IsCompleted, 3000); form.Close();
                    Until(() => running.IsCompleted && form.IsDisposed, 4000); running.GetAwaiter().GetResult();
                    Check(form.IsDisposed, "closing during login waits for local cancellation and releases the form"); File.Delete(cli);
                }
            }
            finally { Store.Write("cli", savedCli); }
        }
        private static void CheckOverlaySelection()
        {
            using (Bitmap snapshot = new Bitmap(160, 90))
            using (CaptureOverlay overlay = new CaptureOverlay(snapshot, new Rectangle(-160, -90, 160, 90), true))
            {
                typeof(CaptureOverlay).GetMethod("OnMouseDown", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(overlay, new object[] { new MouseEventArgs(MouseButtons.Left, 1, 10, 10, 0) });
                typeof(CaptureOverlay).GetMethod("OnMouseMove", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(overlay, new object[] { new MouseEventArgs(MouseButtons.Left, 0, 70, 50, 0) });
                typeof(CaptureOverlay).GetMethod("OnMouseUp", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(overlay, new object[] { new MouseEventArgs(MouseButtons.Left, 1, 70, 50, 0) });
                using (Bitmap result = overlay.TakeResult()) Check(result != null && result.Size == new Size(60, 40), "region event pipeline produces selected-size bitmap on synthetic desktop");
            }
            using (Bitmap snapshot = new Bitmap(160, 90))
            using (CaptureOverlay overlay = new CaptureOverlay(snapshot, new Rectangle(-160, -90, 160, 90), false))
            {
                typeof(CaptureOverlay).GetMethod("OnKeyDown", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(overlay, new object[] { new KeyEventArgs(Keys.Escape) });
                Check(overlay.DialogResult == DialogResult.Cancel && overlay.TakeResult() == null, "Escape cancels synthetic region capture without a result");
            }
        }
        private static void CheckKeyboardAndResize()
        {
            using (MainForm form = new MainForm(true))
            {
                form.Show(); Application.DoEvents();
                object[] command = { Message.Create(form.Handle, 0x0100, new IntPtr((int)Keys.D2), IntPtr.Zero), Keys.Control | Keys.D2 };
                bool handled = (bool)typeof(MainForm).GetMethod("ProcessCmdKey", BindingFlags.NonPublic | BindingFlags.Instance).Invoke(form, command);
                Check(handled && form.State.Page == WorkspacePageId.Analysis, "Ctrl+2 command selects the analysis page");
                MonoButton tab = (MonoButton)form.Navigation.Controls.Find("nav1", true).Single();
                typeof(MonoButton).GetMethod("OnKeyDown", BindingFlags.NonPublic | BindingFlags.Instance).Invoke(tab, new object[] { new KeyEventArgs(Keys.Right) });
                Pump(250); MonoButton selected = (MonoButton)form.Navigation.Controls.Find("nav2", true).Single();
                Check(form.State.Page == WorkspacePageId.Settings && selected.Focused && Math.Abs(form.Navigation.IndicatorPosition - selected.Left) < 1, "arrow navigation moves focus and settles its indicator");
                form.ClientSize = new Size(1300, 900); form.ClientSize = new Size(924, 621); Pump(250);
                Check(Math.Abs(form.Navigation.IndicatorPosition - selected.Left) < 1 && form.SettingsView.Width > 800, "resize keeps page and navigation indicator aligned");
                form.State.SelectPage(WorkspacePageId.Analysis); form.AnalysisView.PromptEditor.Editor.Focus();
                bool moved = form.AnalysisView.SelectNextControl(form.AnalysisView.PromptEditor.Editor, true, true, true, false);
                Check(moved && form.AnalysisView.ContainsFocus && !form.AnalysisView.PromptEditor.Editor.Focused, "Tab traversal remains within the visible analysis page");
                form.State.SelectPage(WorkspacePageId.Settings); form.SettingsView.AutoScrollPosition = new Point(0, 1000); Pump(50);
                using (Bitmap bitmap = new Bitmap(form.Width, form.Height)) { form.DrawToBitmap(bitmap, new Rectangle(Point.Empty, form.Size)); bitmap.Save(Path.Combine(root, "renders", "settings-credits.png")); }
                form.Close();
            }
        }
        private static void Until(Func<bool> condition, int milliseconds)
        {
            Stopwatch watch = Stopwatch.StartNew(); while (!condition()) { if (watch.ElapsedMilliseconds > milliseconds) throw new CheckFailed("asynchronous stage deadline"); Application.DoEvents(); Thread.Sleep(5); }
        }
        private static void Pump(int milliseconds)
        {
            Stopwatch stopwatch = Stopwatch.StartNew(); while (stopwatch.ElapsedMilliseconds < milliseconds) { Application.DoEvents(); Thread.Sleep(5); }
        }
    }
}
