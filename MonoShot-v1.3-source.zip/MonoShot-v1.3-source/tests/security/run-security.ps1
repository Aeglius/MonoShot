param([Parameter(Mandatory=$true)][string]$Cli)
$ErrorActionPreference = 'Stop'
$project = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$probeRoot = Join-Path $project ('.cache\security-v1.3-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $probeRoot | Out-Null
$env:TEMP = $probeRoot; $env:TMP = $probeRoot
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$dump = Join-Path $probeRoot 'PolicyArguments.exe'
$sources = @(Get-ChildItem -LiteralPath (Join-Path $project 'src') -Filter '*.cs' | ForEach-Object { $_.FullName })
& $compiler /nologo /platform:x64 /optimize+ /langversion:5 /codepage:65001 /target:exe /main:MonoShot.Tests.PolicyArguments /r:System.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.Runtime.Serialization.dll /r:System.Xml.dll "/out:$dump" @sources (Join-Path $PSScriptRoot 'PolicyArguments.cs')
if ($LASTEXITCODE -ne 0) { throw 'Security probe compilation failed.' }
# Python is a development-only dependency; no module installation, no external service.
python -B (Join-Path $PSScriptRoot 'verify-policy.py') --cli $Cli --arguments $dump --output $probeRoot
if ($LASTEXITCODE -ne 0) { throw 'Offline security verification failed.' }
Write-Output ('Evidence saved under project cache: ' + [IO.Path]::GetFileName($probeRoot))
