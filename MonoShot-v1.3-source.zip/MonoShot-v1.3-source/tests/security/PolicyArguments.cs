﻿using System;
namespace MonoShot.Tests
{
    // Build only in the separate security probe; not part of the release executable.
    internal static class PolicyArguments
    {
        private static int Main(string[] args)
        {
            if (args.Length == 2 && args[0] == "--check-home")
            {
                try { AnalysisPolicy.VerifyHome(args[1]); return 0; }
                catch (CliException error) { return error.Kind == CliFailure.PolicyContext ? 3 : 4; }
            }
            if (args.Length == 2 && args[0] == "--check-trace")
            {
                try { AnalysisPolicy policy = new AnalysisPolicy(); foreach (string line in System.IO.File.ReadAllLines(args[1])) policy.OutputLine(line); policy.Complete(); return 0; }
                catch (CliException) { return 4; }
            }
            if (args.Length != 3) return 2;
            Console.Write(AnalysisPolicy.Arguments(args[0], args[1], args[2])); return 0;
        }
    }
}
