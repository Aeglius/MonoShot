using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MonoShot.Tests
{
    internal static partial class TestRunner
    {
        private static void CheckShellAndWorkspace()
        {
            Check(Native.ScreenPoint(Native.PackPoint(new Point(-1920, -240))) == new Point(-1920, -240), "native screen coordinates preserve signed negative monitor origins");
            foreach (int scale in new[] { 100, 150, 200 })
            {
                Size size = new Size(1000 * scale / 100, 700 * scale / 100); int edge = Design.ResizeBorder * scale / 100;
                Point[] points = { new Point(1, 1), new Point(size.Width / 2, 1), new Point(size.Width - 1, 1), new Point(1, size.Height / 2),
                    new Point(size.Width - 1, size.Height / 2), new Point(1, size.Height - 1), new Point(size.Width / 2, size.Height - 1), new Point(size.Width - 1, size.Height - 1) };
                int[] hits = { 13, 12, 14, 10, 11, 16, 15, 17 };
                bool correct = true; for (int i = 0; i < points.Length; i++) correct &= Native.ResizeHit(points[i], size, edge, false) == hits[i] && Native.ResizeHit(points[i], size, edge, true) == Native.HtClient;
                Check(correct, "all eight resize regions scale and disable when maximized: geometry at " + scale + "%");
            }
            Native.MinMaxInfo info = new Native.MinMaxInfo();
            Native.ApplyWorkArea(ref info, new Rectangle(-1920, -100, 1920, 1080), new Rectangle(-1880, -100, 1880, 1040), new Size(940, 660));
            Check(info.MaxPosition.X == 40 && info.MaxPosition.Y == 0 && info.MaxSize.X == 1880 && info.MaxSize.Y == 1040 && info.MinTrackSize.X == 940, "monitor-relative maximize geometry respects negative coordinates and taskbars on a side or bottom");
            using (MainForm form = new MainForm(true))
            {
                form.Show(); Pump(80);
                Check(Native.HasWindowStyles(form.Handle, 0x000F0000) && form.ClientSize == form.Size, "custom client frame removes native caption visuals while retaining native sizing and system-control styles");
                Point title = new Point(Design.Px(form, 290), Design.Px(form, 22));
                Check(Native.SendMessage(form.Handle, Native.WmNcHitTest, IntPtr.Zero, Native.PackPoint(form.PointToScreen(title))).ToInt32() == Native.HtCaption, "the native hit-test route recognizes a draggable title region");
                Check(form.Chrome.HitTest(new Point(form.Chrome.Close.Left + 10, form.Chrome.Close.Top + 10)) == Native.HtClient &&
                    form.Chrome.HitTest(new Point(form.Chrome.Maximize.Left + 10, form.Chrome.Maximize.Top + 10)) == Native.HtMaxButton, "caption buttons exclude dragging and maximize exposes the Snap hit code");
                Point max = form.PointToScreen(new Point(form.Chrome.Maximize.Left + 10, form.Chrome.Maximize.Top + 10));
                Check(Native.SendMessage(form.Chrome.Maximize.Handle, Native.WmNcHitTest, IntPtr.Zero, Native.PackPoint(max)).ToInt32() == -1, "maximize child delegates hit testing to the form rather than swallowing Snap");
                Rectangle normal = form.Bounds;
                form.Chrome.Maximize.PerformClick(); Pump(80); Rectangle work = Screen.FromHandle(form.Handle).WorkingArea;
                Rectangle visibleClient = form.RectangleToScreen(form.ClientRectangle);
                Check(form.WindowState == FormWindowState.Maximized && form.Chrome.Maximize.Restored && work.Contains(visibleClient), "actual maximized client stays inside the monitor work area and updates the restore glyph");
                form.Chrome.Maximize.PerformClick(); Pump(80);
                Check(form.WindowState == FormWindowState.Normal && !form.Chrome.Maximize.Restored && form.Bounds == normal, "custom restore returns the actual native window to its prior bounds");
                for (int cycle = 0; cycle < 10; cycle++) { form.Chrome.Maximize.PerformClick(); form.Chrome.Maximize.PerformClick(); }
                Check(form.Bounds == normal, "repeated native maximize/restore has no cumulative client-size drift");
                Native.SendMessage(form.Handle, 0xA3, new IntPtr(Native.HtCaption), Native.PackPoint(form.PointToScreen(title))); Pump(60);
                Check(form.WindowState == FormWindowState.Maximized, "native non-client title double-click maximizes");
                Native.SendMessage(form.Handle, 0xA3, new IntPtr(Native.HtCaption), Native.PackPoint(form.PointToScreen(title))); Pump(60);
                Check(form.WindowState == FormWindowState.Normal, "native non-client title double-click restores");
                form.Chrome.Maximize.PerformClick(); form.Chrome.Minimize.PerformClick(); Pump(40);
                Native.SendMessage(form.Handle, Native.WmSysCommand, new IntPtr(0xF120), IntPtr.Zero); Pump(60);
                Check(form.WindowState == FormWindowState.Maximized && form.Chrome.Maximize.Restored, "a minimized maximized window restores to maximized state");
                form.Chrome.Maximize.PerformClick(); Pump(40);
                form.Chrome.Minimize.PerformClick(); Pump(60);
                Check(form.WindowState == FormWindowState.Minimized, "custom minimize reaches native minimized state"); form.WindowState = FormWindowState.Normal; Pump(60);
                Check(form.Visible && form.WindowState == FormWindowState.Normal, "native minimized window restores without losing the workspace");
                form.State.SetLanguage("en");
                Check(form.Chrome.Close.AccessibleName == "Close window" && form.Chrome.Maximize.AccessibleName == "Maximize", "caption accessibility names follow the language and window state");
                form.State.ReplaceImage(CreateWorkbenchImage(), "fixture", "synthetic-workbench.png"); ImageCanvas canvas = form.CaptureView.Preview; Bitmap image = form.State.Image;
                Pump(50); double fit = canvas.ActualScale; RectangleF destination = canvas.ImageRectangle;
                Check(form.State.FitImage && fit <= 1 && Math.Abs(destination.Width / destination.Height - 16.0 / 9) < .001, "fit preview preserves image aspect ratio and avoids enlarging a small image");
                Check(form.CaptureView.ZoomText.Contains((fit * 100).ToString("0.#") + "%"), "fit percentage uses the actual rendered geometry");
                form.CaptureView.FindButton("actual").PerformClick();
                Check(!form.State.FitImage && canvas.ActualScale == 1 && canvas.ImageRectangle.Width == image.Width, "100 percent maps source pixels to physical preview pixels");
                float left = canvas.ImageRectangle.Left;
                typeof(ImageCanvas).GetMethod("OnMouseDown", BindingFlags.NonPublic | BindingFlags.Instance).Invoke(canvas, new object[] { new MouseEventArgs(MouseButtons.Left, 1, 180, 180, 0) });
                typeof(ImageCanvas).GetMethod("OnMouseMove", BindingFlags.NonPublic | BindingFlags.Instance).Invoke(canvas, new object[] { new MouseEventArgs(MouseButtons.Left, 1, 260, 220, 0) });
                typeof(ImageCanvas).GetMethod("OnMouseUp", BindingFlags.NonPublic | BindingFlags.Instance).Invoke(canvas, new object[] { new MouseEventArgs(MouseButtons.Left, 1, 260, 220, 0) });
                Check(canvas.ImageRectangle.Left > left && ReferenceEquals(image, canvas.Picture), "native mouse-event panning changes only the preview transform, not the bitmap");
                form.CaptureView.FindButton("zoomin").PerformClick(); Check(canvas.ActualScale == Design.ZoomStep, "zoom in changes the actual image transform");
                form.CaptureView.FindButton("zoomout").PerformClick(); Check(canvas.ActualScale == 1, "zoom out returns to the previous scale");
                form.State.SetZoom(100); Check(form.State.Zoom == Design.MaximumZoom, "zoom upper bound prevents an unbounded transform");
                form.State.SetZoom(.0001); Check(form.State.Zoom == Design.MinimumZoom, "zoom lower bound remains usable");
                form.State.SetZoom(Double.NaN); Check(form.State.Zoom == Design.MinimumZoom, "invalid zoom does not poison shared state");
                form.CaptureView.FindButton("fit").PerformClick(); form.ClientSize = new Size(1300, 900); Pump(40);
                Check(form.State.FitImage && form.CaptureView.ZoomText.Contains((canvas.ActualScale * 100).ToString("0.#") + "%"), "resize recomputes the fit label without reloading the bitmap");
                form.State.SetAppearance("dark", "ink"); form.Theme.ChangeMode("dark", "ink", false); form.State.SetLanguage("zh");
                RenderWorkbench(form, "shell-P1-dark.png");
                Control editor = form.AnalysisView.PromptEditor.Editor;
                ((MonoButton)form.Navigation.Controls.Find("nav1", true)[0]).PerformClick(); Pump(300);
                Check(form.AnalysisView.Visible && form.AnalysisView.Parent == form.CaptureView.SideHost && form.CaptureView.Preview.Width < form.CaptureView.Width - Design.SidePanelWidth / 2,
                    "AI side mode mounts the existing analysis page and releases preview width");
                MonoButton quick = form.AnalysisView.FindButton("quickocr");
                Check(quick.Bottom <= quick.Parent.ClientSize.Height && form.AnalysisView.FindButton("sideclose").Width >= Design.Px(form, Design.ButtonHeight), "side-panel quick tasks and close action have unclipped click areas");
                form.AnalysisView.PromptEditor.Editor.Text = "side panel custom prompt"; form.AnalysisView.PromptEditor.Editor.Focus(); form.AnalysisView.PromptEditor.Editor.Select(3, 5);
                form.State.SelectPage(WorkspacePageId.Analysis); Pump(30);
                Check(ReferenceEquals(editor, form.AnalysisView.PromptEditor.Editor) && form.AnalysisView.PromptEditor.Editor.SelectionStart == 3 && form.AnalysisView.PromptEditor.Editor.SelectionLength == 5,
                    "side mode to analysis page retains the same native prompt editor and edit selection");
                form.State.SelectPage(WorkspacePageId.Capture); Pump(300); RenderWorkbench(form, "shell-P2-dark.png");
                form.AnalysisView.FindButton("sideclose").PerformClick(); Pump(300);
                Check(!form.State.AnalysisPanelOpen && !form.AnalysisView.Visible && form.State.Prompt == "side panel custom prompt", "closing the side panel preserves the prompt and restores the image workspace");
                Process process = Process.GetCurrentProcess(); Pump(250); int before = Native.GetGuiResources(process.Handle, 0);
                for (int cycle = 0; cycle < 50; cycle++) { form.State.ShowAnalysisPanel(true); form.State.ShowAnalysisPanel(false); }
                Pump(250);
                Check(ReferenceEquals(image, canvas.Picture) && ReferenceEquals(editor, form.AnalysisView.PromptEditor.Editor) && Native.GetGuiResources(process.Handle, 0) - before < 12,
                    "repeated side-panel changes keep bitmap/editor identities and bounded GDI usage");
                form.ClientSize = Design.MinimumWindow; form.State.ShowAnalysisPanel(true); form.State.SetLanguage("en"); form.State.SetAppearance("light", "ink"); form.Theme.ChangeMode("light", "ink", false); Pump(300);
                Check(form.AnalysisView.PromptEditor.Height > 50 && form.AnalysisView.ResultEditor.Height > 40 && form.AnalysisView.AutoScroll,
                    "minimum-size AI sidebar keeps usable editors with a scrollable short-window layout");
                RenderWorkbench(form, "shell-P2-minimum-en.png");
                Native.SendMessage(form.Handle, Native.WmSysCommand, new IntPtr(0xF060), IntPtr.Zero); Pump(50);
                Check(form.IsDisposed, "native system Close command reaches safe form shutdown");
            }
            CheckPanelTaskLifecycle();
            CheckPanelMotion();
        }
        private static Bitmap CreateWorkbenchImage()
        {
            Bitmap image = new Bitmap(1920, 1080);
            using (Graphics graphics = Graphics.FromImage(image))
            using (SolidBrush surface = new SolidBrush(Color.FromArgb(40, 44, 50)))
            using (Pen grid = new Pen(Color.FromArgb(65, 70, 78), 2))
            {
                graphics.Clear(Color.FromArgb(15, 17, 20)); graphics.FillRectangle(surface, 0, 0, image.Width, 90);
                for (int x = 80; x < 1920; x += 160) graphics.DrawLine(grid, x, 130, x, 1000);
                for (int y = 140; y < 1080; y += 120) graphics.DrawLine(grid, 80, y, 1840, y);
                graphics.DrawRectangle(Pens.White, 600, 290, 720, 500);
                graphics.DrawString("MonoShot / synthetic 1920 x 1080 image", Design.SectionFont, Brushes.White, 40, 30);
                graphics.DrawString("Image workspace", Design.TitleFont, Brushes.White, 740, 520);
            }
            return image;
        }
        private static void RenderWorkbench(MainForm form, string filename)
        { using (Bitmap bitmap = new Bitmap(form.Width, form.Height)) { form.DrawToBitmap(bitmap, new Rectangle(Point.Empty, form.Size)); bitmap.Save(Path.Combine(root, "renders", filename)); } }
        private static void CheckPanelTaskLifecycle()
        {
            TaskCompletionSource<string> answer = new TaskCompletionSource<string>(); bool started = false;
            using (MainForm form = new MainForm(true, (cli, path, prompt, model, token) => { started = true; return answer.Task; }))
            {
                form.Show(); form.State.ReplaceImage(new Bitmap(160, 90), "fixture"); form.State.ShowAnalysisPanel(true);
                Task running = form.Coordinator.StartAnalysis(); Until(() => started, 3000); long version = form.State.CurrentJob.ImageVersion;
                form.AnalysisView.FindButton("sideclose").PerformClick(); form.State.ReplaceImage(new Bitmap(80, 60), "fixture");
                Check(form.State.IsWorking && !form.State.Cancellation.IsCancellationRequested, "closing the side panel and replacing the image do not cancel analysis");
                form.State.SelectPage(WorkspacePageId.Settings); answer.SetResult("SIDEBAR_RESULT"); Until(() => running.IsCompleted, 3000);
                form.State.SelectPage(WorkspacePageId.Capture); form.State.ShowAnalysisPanel(true);
                Check(form.State.Result == "SIDEBAR_RESULT" && form.State.ResultImageVersion == version && form.State.ImageVersion != version &&
                    form.AnalysisView.ResultEditor.Editor.Text == "SIDEBAR_RESULT", "background side-panel result is retained and identifies its original image version");
                form.Close();
            }
        }
        private static void CheckPanelMotion()
        {
            double clock = 0; bool allowed = true;
            MotionHub scheduler = new MotionHub(() => clock, () => allowed);
            MainForm form = new MainForm(true, null, scheduler);
            try
            {
                form.Show(); Application.DoEvents(); clock = 1000; scheduler.Step();
                form.State.SetAppearance("dark", "ink"); form.Theme.ChangeMode("dark", "ink", false);
                form.State.ReplaceImage(CreateWorkbenchImage(), "fixture", "motion-test.png"); Bitmap image = form.State.Image;
                MonoButton ai = (MonoButton)form.Navigation.Controls.Find("nav1", true)[0];
                Check(form.CaptureView.Controls.Find("sideai", true).Length == 0, "only the top navigation exposes the AI entry, with no duplicate toolbar action");
                ai.PerformClick(); Application.DoEvents(); Control editor = form.AnalysisView.PromptEditor.Editor;
                Check(form.State.Page == WorkspacePageId.Capture && form.State.AnalysisPanelOpen && ai.Selected, "the single AI entry selects the adjacent work mode");
                Check(form.CaptureView.SidebarAnimating && form.CaptureView.SidebarProgress == 0, "opening begins at the existing closed geometry rather than snapping open");
                int hostWidth = form.CaptureView.SideHost.Width, editorWidth = editor.Width;
                clock += 40; scheduler.Step(); Application.DoEvents();
                Check(form.CaptureView.SidebarProgress > 0 && form.CaptureView.SidebarProgress < 1 && form.CaptureView.SideHost.Width == hostWidth && editor.Width == editorWidth,
                    "intermediate animation clips a fixed-width editor instead of reflowing its text");
                RenderWorkbench(form, "motion-opening.png"); double opening = form.CaptureView.SidebarProgress;
                ai.PerformClick();
                Check(!form.State.AnalysisPanelOpen && form.AnalysisView.Visible && form.CaptureView.SidebarProgress == opening && !form.CaptureView.SideHost.Enabled,
                    "closing retains the visible panel at its current position and releases its input focus");
                clock += 25; scheduler.Step(); Application.DoEvents(); double closingProgress = form.CaptureView.SidebarProgress;
                Check(closingProgress < opening && closingProgress > 0, "closing interpolates smoothly toward the closed width");
                ai.PerformClick();
                Check(form.State.AnalysisPanelOpen && Math.Abs(form.CaptureView.SidebarProgress - closingProgress) < .0001 && ReferenceEquals(editor, form.AnalysisView.PromptEditor.Editor),
                    "rapid reversal resumes from the current geometry without recreating editors");
                clock += 1000; scheduler.Step(); Application.DoEvents();
                Check(form.CaptureView.SidebarProgress == 1 && !form.CaptureView.SidebarAnimating && form.CaptureView.SideHost.Enabled && !scheduler.IsRunning,
                    "a delayed frame reaches the exact open state and stops all idle animation tracks");
                form.AnalysisView.PromptEditor.Editor.Text = "motion preserves this prompt";
                form.AnalysisView.FindButton("fullview").PerformClick();
                Check(form.State.Page == WorkspacePageId.Analysis && form.CaptureView.SidebarProgress == 0 && !form.CaptureView.SidebarAnimating,
                    "the distinct Full view action retains the analysis page and settles hidden sidebar motion");
                ai.PerformClick(); clock += 1000; scheduler.Step(); Application.DoEvents();
                ai.PerformClick(); clock += 30; scheduler.Step(); Application.DoEvents();
                form.State.SetZoom(1); double current = form.CaptureView.SidebarProgress;
                Check(current > 0 && form.CaptureView.SidebarAnimating, "unrelated zoom notifications do not restart or prematurely detach closing motion");
                form.State.SelectPage(WorkspacePageId.Settings);
                Check(form.CaptureView.SidebarProgress == 0 && !form.CaptureView.SidebarAnimating && form.AnalysisView.Parent != form.CaptureView.SideHost,
                    "leaving the workbench cancels hidden panel motion and releases its visual host");
                ai.PerformClick(); clock += 1000; scheduler.Step(); Application.DoEvents();
                Check(form.State.Prompt == "motion preserves this prompt" && ReferenceEquals(image, form.State.Image), "settings and rapid animation changes preserve the shared image and prompt");
                allowed = false; ai.PerformClick(); Application.DoEvents();
                Check(form.CaptureView.SidebarProgress == 0 && !form.CaptureView.SidebarAnimating && !form.AnalysisView.Visible,
                    "reduced motion closes immediately and detaches the panel without waiting for animation");
                ai.PerformClick(); Application.DoEvents();
                Check(form.CaptureView.SidebarProgress == 1 && !form.CaptureView.SidebarAnimating, "reduced motion opens immediately with the same state contract");
                allowed = true; ai.PerformClick(); clock += 30; scheduler.Step(); form.Dispose(); clock += 1000; scheduler.Step();
                Check(form.IsDisposed && !scheduler.IsRunning, "closing during motion removes callbacks and does not touch disposed controls");
            }
            finally { form.Dispose(); }
        }
    }
}
