﻿using System;
using System.IO;
using System.Text;
using System.Threading;
internal static class FakeCodex
{
    private static int Main(string[] args)
    {
        string name = Path.GetFileNameWithoutExtension(Environment.GetCommandLineArgs()[0]);
        if (Array.IndexOf(args, "--version") >= 0)
        { Console.WriteLine("codex-cli " + (name.EndsWith("Unverified") ? "99.0.0" : "0.160.1")); return 0; }
        // Offline synthetic fixture; no credentials, environment dumps or argument logging.
        if (Array.IndexOf(args, "--wait") >= 0) { Thread.Sleep(30000); return 0; }
        if (Array.IndexOf(args, "--fail") >= 0) { Console.Error.WriteLine("Synthetic request rejected."); return 7; }
        if (Array.IndexOf(args, "--auth-fail") >= 0) { Console.Error.WriteLine("Authentication required."); return 9; }
        if (Array.IndexOf(args, "--flood") >= 0) { for (int line = 0; line < 1200; line++) Console.Error.WriteLine(new string('x', 150)); return 8; }
        if (Array.IndexOf(args, "--login-fixture") >= 0) { Console.Write("DEVICE-CODE-FIXTURE"); return 0; }
        if (args.Length > 0 && args[0] == "login")
        {
            string scenario = Path.GetFileNameWithoutExtension(Environment.GetCommandLineArgs()[0]);
            if (scenario.EndsWith("Silent") || scenario.EndsWith("Banner"))
            { if (scenario.EndsWith("Banner")) Console.WriteLine("Synthetic CLI starting, not a device code."); Thread.Sleep(30000); return 0; }
            if (scenario.EndsWith("Network")) { Console.Error.Write("Error sending request for url (https://auth.openai.com/): synthetic offline failure."); return 9; }
            if (scenario.EndsWith("Unsupported")) { Console.Error.Write("error: unexpected argument '--device-auth' found"); return 2; }
            Console.WriteLine("DEVICE-CODE-FIXTURE: offline synthetic instructions only");
            Console.WriteLine("https://auth.openai.com/codex/device"); Console.Error.WriteLine("TEST-ONLY0");
            Thread.Sleep(1500); return 0;
        }
        // Enforce policy arguments independently of the production argument builder.
        foreach (string required in new[] { "--json", "--ignore-rules", "--strict-config", "shell_tool", "apps", "plugins", "hooks", "multi_agent", "view_image", "browser_use", "computer_use", "image_generation", "tool_suggest", "workspace_dependencies", "web_search=disabled", "project_doc_max_bytes=0", "mcp_servers={}", "agents.enabled=false" })
            if (Array.IndexOf(args, required) < 0) return 11;
        if (Environment.CurrentDirectory == Environment.GetEnvironmentVariable("CODEX_HOME") || !Path.GetFileName(Environment.CurrentDirectory).StartsWith("analysis-")) return 12;
        int modelIndex = Array.IndexOf(args, "--model");
        string mode = modelIndex < 0 ? "" : args[modelIndex + 1];
        Console.WriteLine("{\"type\":\"thread.started\",\"thread_id\":\"offline\"}");
        Console.WriteLine("{\"type\":\"turn.started\"}");
        if (mode == "fixture-command")
        {
            Console.WriteLine("{\"type\":\"item.started\",\"item\":{\"type\":\"command_execution\",\"id\":\"blocked\"}}");
            Thread.Sleep(30000); return 0;
        }
        if (mode == "fixture-malformed") { Console.WriteLine("not-json"); return 0; }
        if (mode == "fixture-unknown") { Console.WriteLine("{\"type\":\"future.unknown\"}"); return 0; }
        if (mode == "fixture-config") { Console.Error.WriteLine("Codex is ignoring 1 unrecognized configuration setting."); return 0; }
        int output = Array.IndexOf(args, "--output-last-message"), image = Array.IndexOf(args, "--image");
        if (output < 0 || image < 0 || !File.Exists(args[image + 1])) return 4;
        string prompt = new StreamReader(Console.OpenStandardInput(), Encoding.UTF8).ReadToEnd();
        if (!prompt.Contains("测试") || !prompt.Contains("quotes")) return 5;
        string home = Environment.GetEnvironmentVariable("CODEX_HOME");
        if (String.IsNullOrEmpty(home) || !Directory.Exists(home)) return 6;
        File.WriteAllText(args[output + 1], "FAKE_OK: offline bridge verification, not a model response.", new UTF8Encoding(false));
        Console.WriteLine("{\"type\":\"item.completed\",\"item\":{\"id\":\"safe\",\"type\":\"agent_message\",\"text\":\"FAKE_OK\"}}");
        if (mode != "fixture-incomplete") Console.WriteLine("{\"type\":\"turn.completed\",\"usage\":{}}");
        return 0;
    }
}
