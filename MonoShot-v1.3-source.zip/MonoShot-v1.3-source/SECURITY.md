﻿# Security and privacy / 安全与隐私

Do not post credentials, device codes, personal images, complete CLI logs or local configuration in public issues. Share a minimal reproduction using synthetic images and placeholder values. For a sensitive report, use a private reporting channel offered by the repository host when available; no private endpoint is bundled in this project.

Screenshots and exports remain local until you explicitly request Codex analysis. Device-code sign-in is handled by the optional official CLI. MonoShot uses a separate portable Codex home and does not inspect other apps' credentials. Authentication instructions are temporary UI text, not an analysis result or log. Error messages use safe categories instead of raw CLI output. Credential-shaped text is redacted as a best-effort safeguard; it is not a guarantee that arbitrary personal information is detected.

Portable deployment is convenient, not encrypted storage. Anyone with access to the application directory can read its settings, draft prompts and CLI-managed account files. Distribute only the allowlisted clean package. Close all instances before manually clearing temporary files. Windows and the browser manage their own caches outside the app's control.

不要在公开问题中附上密钥、设备码、真实截图、完整 CLI 输出或个人配置。使用合成图片复现。便携目录不是加密容器；仅分享纯净发布包。模式脱敏与发布扫描只能作为辅助措施，无法保证识别任意个人信息。

## v1.3 analysis policy / 分析策略

Analysis is restricted to verified CLI 0.160.1 with explicit capability/context settings and a complete JSON trace; there is no permissive fallback. Account instructions cause a preflight refusal without reading or altering their contents. Sign-in still uses the same portable CLI account and device flow. See [EA-01 fix](docs/EA01_FIX.md) for tested boundaries, the inert question tool, read-only patch rejection and remaining trust assumptions. Cancellation stops local processes and rejects late results; it does not guarantee stopping already-started remote computation. Abnormal process termination can still leave temporary image data (EA-02 remains open).

v1.3 不是对任意 CLI、系统管理员策略或模型服务的安全隔离容器。已完成合成数据与本地模拟服务测试；未将真实用户数据用于攻击验证。旧审计中的 EA-02 至 EA-06 不因本次修复自动关闭。
