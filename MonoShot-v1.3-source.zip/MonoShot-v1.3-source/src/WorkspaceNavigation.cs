using System;
using System.Drawing;
using System.Windows.Forms;

namespace MonoShot
{
    internal sealed class WorkspaceNavigation : Control
    {
        private readonly WorkspaceState state;
        private readonly UiTheme theme;
        private readonly MotionHub motion;
        private readonly MonoButton[] tabs = new MonoButton[3];
        private readonly SolidBrush indicator = new SolidBrush(Color.Black);
        private double indicatorX;
        private int indicatorWidth;
        private int selectedIndex;
        public WorkspaceNavigation(WorkspaceState state, UiTheme theme, MotionHub motion)
        {
            this.state = state; this.theme = theme; this.motion = motion;
            Name = "navigation"; AccessibleRole = AccessibleRole.PageTabList; TabStop = false; DoubleBuffered = true;
            SetStyle(ControlStyles.ResizeRedraw, true);
            for (int i = 0; i < tabs.Length; i++)
            {
                int index = i;
                tabs[i] = new MonoButton(theme, motion) { Name = "nav" + i, TabIndex = i, AccessibleRole = AccessibleRole.PageTab };
                tabs[i].Click += (s, e) => Activate(index, true);
                tabs[i].KeyDown += (s, e) => {
                    int target = e.KeyCode == Keys.Left ? (index + 2) % 3 : e.KeyCode == Keys.Right ? (index + 1) % 3 : e.KeyCode == Keys.Home ? 0 : e.KeyCode == Keys.End ? 2 : -1;
                    if (target < 0) return; e.Handled = e.SuppressKeyPress = true; Activate(target, false); tabs[target].Focus();
                };
                Controls.Add(tabs[i]);
            }
            state.Changed += StateChanged; theme.Changed += ThemeChanged; RefreshTabs();
        }
        internal double IndicatorPosition { get { return indicatorX; } }
        private void Activate(int index, bool toggle)
        {
            if (index == 2) { state.SelectPage(WorkspacePageId.Settings); return; }
            if (index == 0) { state.ShowAnalysisPanel(false); state.SelectPage(WorkspacePageId.Capture); return; }
            bool close = toggle && state.Page == WorkspacePageId.Capture && state.AnalysisPanelOpen;
            state.ShowAnalysisPanel(!close); state.SelectPage(WorkspacePageId.Capture);
        }
        private void StateChanged(object sender, StateChangedEventArgs e)
        {
            if ((e.Changes & (StateChange.Language | StateChange.Page | StateChange.Job | StateChange.View)) == 0) return;
            RefreshTabs();
            int next = (int)state.NavigationPage;
            if (selectedIndex != next)
            {
                selectedIndex = next;
                motion.Animate(this, "navigation", indicatorX, tabs[next].Left, Design.NavigationMs, Ease.OutCubic,
                    value => { Rectangle old = IndicatorBounds(); indicatorX = value; Invalidate(Rectangle.Union(old, IndicatorBounds())); }, null);
            }
        }
        private Rectangle IndicatorBounds() { return new Rectangle((int)Math.Round(indicatorX), Height - Design.Px(this, Design.NavigationIndicator), indicatorWidth, Design.Px(this, Design.NavigationIndicator)); }
        private void RefreshTabs()
        {
            string[] keys = { "Capture", "Analysis", "Settings" };
            for (int i = 0; i < tabs.Length; i++)
            {
                string label = Strings.Get(state.Language, keys[i]);
                if (state.IsWorking && (i == 1 && state.CurrentJob.Kind == JobKind.Analysis || i == 2 && state.CurrentJob.Kind == JobKind.Login))
                    label += " · " + Strings.Get(state.Language, state.CurrentJob.Phase == JobPhase.Canceling ? "Canceling" : i == 1 ? "Running" : "SigningIn");
                tabs[i].Text = label; tabs[i].Selected = (int)state.NavigationPage == i;
                tabs[i].AccessibleDescription = tabs[i].Selected ? Strings.Get(state.Language, "Selected") : "";
                tabs[i].Invalidate();
            }
            indicatorWidth = tabs[(int)state.NavigationPage].Width;
        }
        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e); if (tabs[0] == null) return;
            motion.Cancel(this, "navigation");
            int gap = Design.Px(this, Design.Gap), width = Design.Px(this, Design.NavigationItemWidth), settings = Design.Px(this, Design.SettingsNavigationWidth);
            tabs[0].SetBounds(0, 0, width, Height - Design.Px(this, Design.Gap));
            tabs[1].SetBounds(width + gap, 0, width, Height - Design.Px(this, Design.Gap));
            tabs[2].SetBounds(Math.Max(width * 2 + gap * 2, Width - settings), 0, settings, Height - Design.Px(this, Design.Gap));
            selectedIndex = (int)state.NavigationPage; indicatorWidth = tabs[selectedIndex].Width;
            indicatorX = tabs[selectedIndex].Left; Invalidate();
        }
        protected override void OnDpiChangedAfterParent(EventArgs e) { base.OnDpiChangedAfterParent(e); OnSizeChanged(EventArgs.Empty); }
        private void ThemeChanged(object sender, EventArgs e) { Invalidate(); }
        protected override void OnPaint(PaintEventArgs e)
        { e.Graphics.Clear(theme.Colors.Background); indicator.Color = theme.Colors.Accent; e.Graphics.FillRectangle(indicator, IndicatorBounds()); }
        protected override void Dispose(bool disposing)
        {
            if (disposing) { state.Changed -= StateChanged; theme.Changed -= ThemeChanged; motion.Cancel(this, null); indicator.Dispose(); }
            base.Dispose(disposing);
        }
    }

    // The native combo keeps keyboard and accessibility behavior; only its list colors are drawn here.
    internal sealed class ThemeChoice : ComboBox
    {
        private readonly UiTheme theme;
        private readonly SolidBrush fill = new SolidBrush(Color.White);
        public ThemeChoice(UiTheme theme)
        {
            this.theme = theme; Font = theme.Body; DropDownStyle = ComboBoxStyle.DropDownList; DrawMode = DrawMode.OwnerDrawFixed;
            ItemHeight = Design.PromptChoiceHeight - Design.ToolbarGap; Dock = DockStyle.Fill; Margin = new Padding(0, 0, 0, Design.Gap);
            theme.Changed += Changed; Changed(this, EventArgs.Empty);
        }
        private void Changed(object sender, EventArgs e) { BackColor = theme.Colors.Input; ForeColor = theme.Colors.Text; Invalidate(); }
        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            fill.Color = (e.State & DrawItemState.Selected) != 0 ? theme.Colors.Hover : theme.Colors.Input;
            e.Graphics.FillRectangle(fill, e.Bounds);
            TextRenderer.DrawText(e.Graphics, e.Index < 0 ? "" : Items[e.Index].ToString(), Font, Rectangle.Inflate(e.Bounds, -Design.Px(this, Design.Gap), 0), theme.Colors.Text,
                TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis);
            if ((e.State & DrawItemState.Focus) != 0) e.DrawFocusRectangle();
        }
        protected override void Dispose(bool disposing) { if (disposing) { theme.Changed -= Changed; fill.Dispose(); } base.Dispose(disposing); }
    }
}
