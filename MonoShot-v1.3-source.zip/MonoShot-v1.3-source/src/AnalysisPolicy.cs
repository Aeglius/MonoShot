﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.RegularExpressions;

namespace MonoShot
{
    // A deliberately versioned policy. Revalidate the real tool registry before adding a CLI version.
    internal sealed class AnalysisPolicy
    {
        internal const string SupportedVersion = "0.160.1";
        private static readonly string[] DisabledFeatures = {
            "shell_tool", "shell_snapshot", "apps", "browser_use", "browser_use_external",
            "computer_use", "image_generation", "multi_agent", "plugins", "remote_plugin",
            "hooks", "memories", "code_mode", "code_mode_host", "tool_suggest",
            "workspace_dependencies", "view_image", "goals", "skill_search", "sleep_tool",
            "skill_mcp_dependency_install", "request_permissions_tool", "in_app_browser", "in_app_local_automation"
        };
        private bool started, turnStarted, completed, failed;
        private readonly DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(TraceEvent));

        internal static void VerifyVersion(string output)
        {
            if (!Regex.IsMatch(output ?? "", @"(?m)^codex-cli " + Regex.Escape(SupportedVersion) + @"\r?$"))
                throw new CliException(CliFailure.PolicyUnsupported);
        }

        internal static void VerifyHome(string home)
        {
            // In this CLI version the account-level AGENTS file bypasses project_doc_max_bytes.
            // Do not read, alter or forward its contents. Login itself remains unrestricted.
            foreach (string name in new[] { "AGENTS.md", "AGENTS.override.md" })
                if (File.Exists(Path.Combine(home, name))) throw new CliException(CliFailure.PolicyContext);
        }

        internal static string Arguments(string image, string output, string model)
        {
            StringBuilder args = new StringBuilder("-a never exec --sandbox read-only --skip-git-repo-check --ephemeral --ignore-user-config --ignore-rules --strict-config --color never --json");
            args.Append(" -c skills.include_instructions=false -c include_environment_context=false -c web_search=\"disabled\" -c project_doc_max_bytes=0 -c agents.enabled=false -c mcp_servers={} -c features.skip_host_skill_discovery=true");
            foreach (string feature in DisabledFeatures) args.Append(" --disable ").Append(feature);
            args.Append(" --output-last-message ").Append(Bridge.Quote(output)).Append(" --image ").Append(Bridge.Quote(image));
            if (!String.IsNullOrWhiteSpace(model)) args.Append(" --model ").Append(Bridge.Quote(model));
            return args.Append(" -- -").ToString();
        }

        internal void ErrorLine(string line)
        {
            // Unknown config can otherwise silently enable defaults in a different build.
            if (Regex.IsMatch(line, "unrecognized configuration|unknown feature|is ignored|ignoring .*configuration", RegexOptions.IgnoreCase))
                throw new CliException(CliFailure.PolicyUnsupported);
        }

        internal void OutputLine(string line)
        {
            if (line.Length > 1024 * 1024) throw new CliException(CliFailure.PolicyViolation);
            TraceEvent value;
            try
            {
                using (MemoryStream input = new MemoryStream(Encoding.UTF8.GetBytes(line)))
                    value = (TraceEvent)serializer.ReadObject(input);
            }
            catch (SerializationException) { throw new CliException(CliFailure.PolicyViolation); }
            catch (System.Xml.XmlException) { throw new CliException(CliFailure.PolicyViolation); }
            if (value == null) throw new CliException(CliFailure.PolicyViolation);
            switch (value.Type)
            {
                case "thread.started": if (started) Reject(); started = true; break;
                case "turn.started": if (!started || turnStarted) Reject(); turnStarted = true; break;
                case "turn.completed": if (!turnStarted || completed) Reject(); completed = true; break;
                case "turn.failed": case "error": failed = true; break; // Run preserves auth/network/timeout error categories.
                case "item.started": case "item.updated": case "item.completed":
                    if (value.Item == null) { Reject(); break; }
                    string type = value.Item.Type;
                    if (type != "agent_message" && type != "reasoning" && type != "error") Reject();
                    if (type == "error") ErrorLine(value.Item.Message ?? "");
                    break;
                default: Reject(); break;
            }
        }
        internal void Complete() { if (!started || !turnStarted || !completed || failed) Reject(); }
        private static void Reject() { throw new CliException(CliFailure.PolicyViolation); }

        [DataContract]
        private sealed class TraceEvent
        {
            [DataMember(Name = "type")] public string Type { get; set; }
            [DataMember(Name = "item")] public TraceItem Item { get; set; }
        }
        [DataContract]
        private sealed class TraceItem
        {
            [DataMember(Name = "type")] public string Type { get; set; }
            [DataMember(Name = "message")] public string Message { get; set; }
        }
    }
}
