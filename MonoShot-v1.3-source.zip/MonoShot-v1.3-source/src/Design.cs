using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using Microsoft.Win32;

namespace MonoShot
{
    internal static class Design
    {
        // Five system-font instances for the application lifetime. Reusing identities also keeps
        // WinForms' native text-font cache bounded across repeated dialogs and window tests.
        public static readonly Font BodyFont = new Font(SystemFonts.MessageBoxFont.FontFamily, 9F);
        public static readonly Font SmallFont = new Font(SystemFonts.MessageBoxFont.FontFamily, 8F);
        public static readonly Font TitleFont = new Font(SystemFonts.MessageBoxFont.FontFamily, 22F, FontStyle.Bold);
        public static readonly Font SectionFont = new Font(SystemFonts.MessageBoxFont.FontFamily, 13F, FontStyle.Bold);
        public static readonly Font HeroFont = new Font(SystemFonts.MessageBoxFont.FontFamily, 16F);
        public const int Radius = 8, Gap = 8, Gutter = 14, ButtonHeight = 38;
        public const int TitleBarHeight = 48, CaptionButtonWidth = 46, CaptionIconSize = 10, ResizeBorder = 6,
            BrandWidth = 240, PreviewPadding = 20, ZoomBarHeight = 46, SidePanelWidth = 352, SideInputHeight = 260,
            SidebarMinimumHeight = 600, NavigationItemWidth = 180, SettingsNavigationWidth = 150;
        public const double MinimumZoom = .05, MaximumZoom = 8, ZoomStep = 1.25;
        public const int HoverMs = 125, PressMs = 90, FocusMs = 160, ThemeMs = 210, PanelMs = 210, PanelMinMs = 80, AnalysisExpandWidth = 96, ToastMs = 190;
        public const int PagePadding = 16, SurfacePadding = 14, HeaderHeight = 48, NavigationHeight = 44,
            NavigationMs = 150, NavigationIndicator = 3, StatusHeight = 32, MetadataHeight = 30,
            ToolbarGap = 12, ThumbnailHeight = 150, CompactThumbnailHeight = 96, FieldHeight = 44, LabelHeight = 28, PromptChoiceHeight = 36,
            TaskHeight = 100, MinimumPageHeight = 500, SettingsMinimumHeight = 900;
        public static readonly Size InitialSize = new Size(1180, 800), MinimumWindow = new Size(940, 660);
        public const float AnalysisInputPercent = 44, SettingsLabelPercent = 30;
        public static int ButtonWidth(string key)
        { return key == "sideclose" ? 38 : key == "zoomout" || key == "zoomin" ? 40 : key == "actual" ? 72 : key == "fit" ? 118 : key == "region" ? 136 : key == "analyze" || key == "save" ? 144 : key == "export" || key == "copytext" || key == "savetext" ? 116 : 96; }
        public static int Px(Control control, int logical) { return (int)Math.Round(logical * control.DeviceDpi / 96.0); }
        public static Color Mix(Color first, Color second, double progress)
        {
            double t = Math.Max(0, Math.Min(1, progress));
            return Color.FromArgb((int)Math.Round(first.R + (second.R - first.R) * t),
                (int)Math.Round(first.G + (second.G - first.G) * t),
                (int)Math.Round(first.B + (second.B - first.B) * t));
        }
        public static GraphicsPath Rounded(RectangleF rectangle, float radius)
        {
            GraphicsPath path = new GraphicsPath();
            float diameter = Math.Min(radius * 2, Math.Min(rectangle.Width, rectangle.Height));
            if (diameter <= 0) { path.AddRectangle(rectangle); return path; }
            path.AddArc(rectangle.Left, rectangle.Top, diameter, diameter, 180, 90);
            path.AddArc(rectangle.Right - diameter, rectangle.Top, diameter, diameter, 270, 90);
            path.AddArc(rectangle.Right - diameter, rectangle.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(rectangle.Left, rectangle.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();
            return path;
        }
        public static void DisposeFonts() { BodyFont.Dispose(); SmallFont.Dispose(); TitleFont.Dispose(); SectionFont.Dispose(); HeroFont.Dispose(); }
    }

    internal sealed class Palette
    {
        public Color Background, Surface, Input, Text, Muted, Border, Hover, Pressed, Disabled,
            Accent, OnAccent, Selected, SelectedText, Canvas, CanvasText, CanvasMuted, Dot, Chrome, CloseHover, ClosePressed, CloseText;

        public static Palette Create(bool dark, string accent)
        {
            Palette p = dark ? new Palette {
                Background = Color.FromArgb(25, 28, 32), Surface = Color.FromArgb(35, 38, 43),
                Input = Color.FromArgb(25, 28, 32), Text = Color.FromArgb(237, 238, 240), Muted = Color.FromArgb(166, 169, 177),
                Border = Color.FromArgb(65, 67, 73), Hover = Color.FromArgb(45, 47, 52), Pressed = Color.FromArgb(60, 63, 70),
                Disabled = Color.FromArgb(126, 130, 139), Canvas = Color.FromArgb(15, 16, 18),
                CanvasText = Color.FromArgb(238, 239, 241), CanvasMuted = Color.FromArgb(160, 163, 170), Dot = Color.FromArgb(36, 38, 42)
            } : new Palette {
                Background = Color.FromArgb(246, 247, 249), Surface = Color.White, Input = Color.FromArgb(249, 250, 251),
                Text = Color.FromArgb(26, 29, 34), Muted = Color.FromArgb(99, 105, 115), Border = Color.FromArgb(212, 216, 223),
                Hover = Color.FromArgb(237, 240, 244), Pressed = Color.FromArgb(223, 228, 235), Disabled = Color.FromArgb(123, 128, 138),
                Canvas = Color.FromArgb(26, 28, 32), CanvasText = Color.FromArgb(241, 242, 244),
                CanvasMuted = Color.FromArgb(174, 179, 190), Dot = Color.FromArgb(43, 46, 52)
            };
            p.Accent = accent == "blue" ? (dark ? Color.FromArgb(140, 180, 255) : Color.FromArgb(33, 89, 191)) :
                accent == "green" ? (dark ? Color.FromArgb(116, 218, 177) : Color.FromArgb(16, 112, 79)) :
                (dark ? Color.FromArgb(237, 238, 240) : Color.FromArgb(29, 32, 37));
            p.OnAccent = dark ? Color.FromArgb(16, 23, 31) : Color.White;
            p.Selected = Design.Mix(p.Surface, p.Accent, dark ? .17 : .09); p.SelectedText = p.Text;
            p.Chrome = p.Surface; p.CloseHover = Color.FromArgb(196, 43, 49); p.ClosePressed = Color.FromArgb(156, 32, 38); p.CloseText = Color.White;
            if (SystemInformation.HighContrast)
            {
                p.Background = p.Surface = p.Input = SystemColors.Window;
                p.Text = p.CanvasText = SystemColors.WindowText; p.Muted = p.CanvasMuted = SystemColors.WindowText;
                p.Border = SystemColors.WindowText; p.Hover = p.Pressed = SystemColors.Control;
                p.Disabled = SystemColors.GrayText; p.Accent = SystemColors.Highlight; p.OnAccent = SystemColors.HighlightText;
                p.Selected = SystemColors.Highlight; p.SelectedText = SystemColors.HighlightText;
                p.Canvas = SystemColors.Window; p.Dot = SystemColors.Window;
                p.Chrome = SystemColors.Window; p.CloseHover = p.ClosePressed = SystemColors.Highlight; p.CloseText = SystemColors.HighlightText;
            }
            return p;
        }

        public Palette Snapshot() { return (Palette)MemberwiseClone(); }
        public void Blend(Palette a, Palette b, double t)
        {
            Background = Design.Mix(a.Background, b.Background, t); Surface = Design.Mix(a.Surface, b.Surface, t);
            Input = Design.Mix(a.Input, b.Input, t); Text = Design.Mix(a.Text, b.Text, t); Muted = Design.Mix(a.Muted, b.Muted, t);
            Border = Design.Mix(a.Border, b.Border, t); Hover = Design.Mix(a.Hover, b.Hover, t); Pressed = Design.Mix(a.Pressed, b.Pressed, t);
            Disabled = Design.Mix(a.Disabled, b.Disabled, t); Accent = Design.Mix(a.Accent, b.Accent, t); OnAccent = Design.Mix(a.OnAccent, b.OnAccent, t);
            Selected = Design.Mix(a.Selected, b.Selected, t); SelectedText = Design.Mix(a.SelectedText, b.SelectedText, t);
            Canvas = Design.Mix(a.Canvas, b.Canvas, t); CanvasText = Design.Mix(a.CanvasText, b.CanvasText, t);
            CanvasMuted = Design.Mix(a.CanvasMuted, b.CanvasMuted, t); Dot = Design.Mix(a.Dot, b.Dot, t);
            Chrome = Design.Mix(a.Chrome, b.Chrome, t); CloseHover = Design.Mix(a.CloseHover, b.CloseHover, t);
            ClosePressed = Design.Mix(a.ClosePressed, b.ClosePressed, t); CloseText = Design.Mix(a.CloseText, b.CloseText, t);
        }
    }

    internal sealed class UiTheme : IDisposable
    {
        private readonly MotionHub motion;
        public readonly Font Body, Small, Title, Section, Hero;
        public Palette Colors { get; private set; }
        public bool Dark { get; private set; }
        public string Mode { get; private set; }
        public string Accent { get; private set; }
        public event EventHandler Changed;

        public UiTheme(MotionHub scheduler)
        {
            motion = scheduler;
            Body = Design.BodyFont; Small = Design.SmallFont; Title = Design.TitleFont; Section = Design.SectionFont; Hero = Design.HeroFont;
            Mode = WorkspaceState.NormalizeMode(Store.Read("theme", "light"));
            Dark = Mode == "system" ? SystemDark() : Mode == "dark"; Accent = WorkspaceState.NormalizeAccent(Store.Read("accent", "ink"));
            Colors = Palette.Create(Dark, Accent);
        }

        public void Change(bool dark, string accent, bool animate)
        { ChangeMode(dark ? "dark" : "light", accent, animate); }
        public static bool SystemDark()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"))
                    return key != null && Convert.ToInt32(key.GetValue("AppsUseLightTheme", 1)) == 0;
            }
            catch (System.Security.SecurityException) { return SystemColors.Window.GetBrightness() < .5; }
            catch (UnauthorizedAccessException) { return SystemColors.Window.GetBrightness() < .5; }
            catch (System.IO.IOException) { return SystemColors.Window.GetBrightness() < .5; }
            catch (FormatException) { return false; }
        }
        public void ChangeMode(string mode, string accent, bool animate)
        {
            Mode = WorkspaceState.NormalizeMode(mode); Dark = Mode == "system" ? SystemDark() : Mode == "dark";
            Accent = WorkspaceState.NormalizeAccent(accent);
            Palette start = Colors.Snapshot(), target = Palette.Create(Dark, Accent);
            motion.Animate(this, "theme", 0, 1, animate ? Design.ThemeMs : 0, Ease.InOutCubic,
                value => { Colors.Blend(start, target, value); EventHandler changed = Changed; if (changed != null) changed(this, EventArgs.Empty); }, null);
        }

        public void Save() { Store.Write("theme", Mode); Store.Write("accent", Accent); }
        public void Dispose()
        {
            motion.Cancel(this, null); Changed = null;
        }
    }
}
