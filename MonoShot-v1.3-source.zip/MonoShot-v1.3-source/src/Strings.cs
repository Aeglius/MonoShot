﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace MonoShot
{
    internal static class Product
    {
        public const string Version = "v1.3";
        public const string Name = "MonoShot " + Version;
        public const string Credits = "Created by Aeglius\r\nBuilt with the assistance of GPT-6.1 Sol & GPT-6 Astra\r\nTested by Stellar & enterprise";
    }

    internal static class Strings
    {
        private static readonly Dictionary<string, string[]> Values = new Dictionary<string, string[]> {
            { "WindowMinimize", new[] { "最小化", "Minimize" } }, { "WindowMaximize", new[] { "最大化", "Maximize" } },
            { "WindowRestore", new[] { "还原", "Restore" } }, { "WindowClose", new[] { "关闭窗口", "Close window" } },
            { "fullview", new[] { "独立视图", "Full view" } }, { "sideclose", new[] { "×", "×" } },
            { "AnalyzeCurrent", new[] { "分析当前图片", "Analyze current image" } },
            { "HideAnalysis", new[] { "关闭分析面板", "Close analysis panel" } },
            { "ZoomOut", new[] { "缩小图像", "Zoom out" } }, { "ZoomIn", new[] { "放大图像", "Zoom in" } },
            { "zoomout", new[] { "−", "−" } }, { "zoomin", new[] { "+", "+" } }, { "actual", new[] { "100%", "100%" } },
            { "fit", new[] { "适应窗口", "Fit window" } }, { "FitShort", new[] { "适应", "Fit" } },
            { "CaptureName", new[] { "截图 {0}.png", "Capture {0}.png" } }, { "OpenedImage", new[] { "已打开的图像", "Opened image" } },
            { "ClipboardImage", new[] { "剪贴板图像", "Clipboard image" } },
            { "quickocr", new[] { "提取文字", "Extract text" } }, { "quicksummary", new[] { "总结内容", "Summarize" } },
            { "Capture", new[] { "截图", "Capture" } }, { "Analysis", new[] { "AI 分析", "AI Analysis" } },
            { "Settings", new[] { "设置", "Settings" } }, { "Tagline", new[] { "轻一点，专注眼前。", "Less clutter. More clarity." } },
            { "Demo", new[] { "可换肤工作台 Demo", "Skinnable workspace demo" } },
            { "region", new[] { "＋ 区域截图", "＋ Capture region" } }, { "screen", new[] { "全屏截图", "Full screen" } },
            { "open", new[] { "打开图片", "Open" } }, { "copy", new[] { "复制", "Copy" } },
            { "paste", new[] { "粘贴", "Paste" } }, { "export", new[] { "导出图片", "Export image" } },
            { "analyze", new[] { "分析图片", "Analyze image" } }, { "cancel", new[] { "取消任务", "Cancel task" } },
            { "copytext", new[] { "复制结果", "Copy result" } }, { "savetext", new[] { "保存结果", "Save result" } },
            { "browse", new[] { "选择程序", "Browse" } }, { "save", new[] { "保存连接", "Save connection" } },
            { "login", new[] { "登录 Codex", "Sign in" } }, { "Selected", new[] { "当前页面", "Selected page" } },
            { "NoImage", new[] { "尚无图片", "No image" } }, { "ImageInfo", new[] { "图像 v{0} · {1} × {2} px · 原始分辨率导出", "Image v{0} · {1} × {2} px · Full-resolution export" } },
            { "CanvasTitle", new[] { "捕捉一刻，留住灵感。", "A little frame. A clear idea." } },
            { "CanvasHint", new[] { "框选屏幕、粘贴图片，或拖入一张图片", "Capture, paste, or drop an image here" } },
            { "CaptureHint", new[] { "拖动框选  ·  Esc / 右键取消", "Drag to capture  ·  Esc / right-click to cancel" } },
            { "CurrentImage", new[] { "当前图像 v{0} · {1} × {2} px", "Current image v{0} · {1} × {2} px" } },
            { "Ready", new[] { "就绪 · Ctrl + Alt + A 截图 · Ctrl + 1 / 2 / 3 切页", "Ready · Ctrl + Alt + A capture · Ctrl + 1 / 2 / 3 pages" } },
            { "ImageReady", new[] { "图片已载入。", "Image ready." } }, { "Opening", new[] { "正在打开图片…", "Opening image…" } },
            { "Copied", new[] { "已复制。", "Copied." } }, { "Exported", new[] { "已导出。", "Exported." } },
            { "Saved", new[] { "连接已保存。", "Connection saved." } }, { "NoClipboardImage", new[] { "剪贴板中没有图片。", "No image in the clipboard." } },
            { "CaptureCanceled", new[] { "已取消截图。", "Capture canceled." } },
            { "HotkeyUnavailable", new[] { "全局快捷键被占用，请使用区域截图按钮。", "Hotkey unavailable; use Capture region." } },
            { "Prompt", new[] { "你想了解什么？", "What would you like to know?" } },
            { "Presets", new[] { "Prompt 预设", "Prompt presets" } }, { "Result", new[] { "分析结果", "Analysis result" } },
            { "ResultEmpty", new[] { "分析结果会保留在这里。\r\n首次使用：设置 → 登录 Codex。", "Your analysis stays here.\r\nFirst use: Settings → Sign in." } },
            { "ResultVersion", new[] { "结果对应图像 v{0} · 当前图像 v{1}", "Result for image v{0} · Current image v{1}" } },
            { "SendNote", new[] { "点击分析后，当前图像与问题才会发送给 Codex。", "Analyze sends the current image and question to Codex." } },
            { "JobImage", new[] { "任务图像 v{0} · {1} × {2} px", "Task image v{0} · {1} × {2} px" } },
            { "ImageChanged", new[] { "当前已切换到图像 v{0}，任务仍分析 v{1}。", "Current image is v{0}; the task still analyzes v{1}." } },
            { "Idle", new[] { "尚未发起任务", "No task yet" } }, { "Running", new[] { "分析中…", "Analyzing…" } },
            { "Canceling", new[] { "正在取消…", "Canceling…" } }, { "Completed", new[] { "分析完成", "Analysis complete" } },
            { "Canceled", new[] { "任务已取消", "Task canceled" } }, { "Failed", new[] { "任务失败", "Task failed" } },
            { "TimedOut", new[] { "任务超时", "Task timed out" } },
            { "SigningIn", new[] { "登录中…", "Signing in…" } }, { "SignedIn", new[] { "本次登录成功", "Signed in this session" } },
            { "Configured", new[] { "CLI 已配置，账号状态由 Codex 登录确认。", "CLI configured; sign in to confirm account access." } },
            { "MissingCli", new[] { "请选择有效的原生 codex.exe。", "Choose a valid native codex.exe." } },
            { "LoginNote", new[] { "请自行在浏览器完成设备码登录。说明仅在此流程临时显示。", "Complete device-code sign-in in your browser. Instructions are temporary." } },
            { "LoginEnded", new[] { "登录流程已结束。", "Sign-in flow ended." } },
            { "LoginWaiting", new[] { "正在请求登录网址与设备码（最长等待 30 秒）…", "Requesting the sign-in link and device code (up to 30 seconds)…" } },
            { "ErrorLoginStart", new[] { "30 秒内未收到设备码，请检查网络、代理及设备码登录权限后重试。", "No device code arrived within 30 seconds. Check network, proxy and device-code permissions, then retry." } },
            { "ErrorCliVersion", new[] { "当前 CLI 不支持设备码登录参数，请选择支持 login --device-auth 的原生 codex.exe。", "This CLI does not support device-code sign-in. Choose a native codex.exe supporting login --device-auth." } },
            { "LoginTroubleshoot", new[] { "登录未完成。请确认 Codex CLI 可访问官方登录服务；浏览器可联网不代表 CLI 已使用同一代理。设备码登录需在 ChatGPT 的安全设置或工作区权限中开启。修正后点击“登录 Codex”重试。", "Sign-in did not complete. Check that Codex CLI can reach the official sign-in service; browser proxy settings may differ. Enable device-code login in ChatGPT security settings or workspace permissions, then retry Sign in." } },
            { "CliLabel", new[] { "Codex CLI 程序（.exe）", "Codex CLI executable (.exe)" } },
            { "ModelLabel", new[] { "模型（选填；留空使用 CLI 默认值）", "Model (optional; blank uses the CLI default)" } },
            { "Appearance", new[] { "外观与语言", "Appearance and language" } },
            { "Theme", new[] { "主题模式", "Theme mode" } }, { "Accent", new[] { "强调色", "Accent color" } },
            { "Language", new[] { "界面语言", "Language" } }, { "Light", new[] { "浅色", "Light" } },
            { "Dark", new[] { "深色", "Dark" } }, { "System", new[] { "跟随系统", "System" } },
            { "Ink", new[] { "墨色", "Ink" } }, { "Blue", new[] { "蓝色", "Blue" } }, { "Green", new[] { "绿色", "Green" } },
            { "Version", new[] { "版本与贡献者", "Version and contributors" } },
            { "PortableNote", new[] { "便携配置与登录流程沿用原有实现。切页不会中止任务。", "Portable settings and sign-in are unchanged. Tasks continue across pages." } },
            { "ErrorCancel", new[] { "操作已取消。", "Operation canceled." } },
            { "ErrorTimeout", new[] { "连接超时，请检查网络后重试。", "The connection timed out. Check your network and retry." } },
            { "ErrorAuth", new[] { "请在设置页登录 Codex 后重试。", "Sign in to Codex under Settings, then retry." } },
            { "ErrorNetwork", new[] { "无法连接 Codex，请检查网络。", "Could not connect to Codex. Check your network." } },
            { "ErrorCli", new[] { "无法启动 Codex，请检查程序路径。", "Could not start Codex. Check its executable path." } },
            { "ErrorAnalysisContext", new[] { "为防止附带无关内容，分析已停止：便携账户目录 data/codex 中存在 AGENTS.md 或 AGENTS.override.md。请自行移走这些说明文件后重试；登录不受影响。", "Analysis stopped to prevent unrelated context: data/codex contains AGENTS.md or AGENTS.override.md. Move these instruction files yourself and retry. Sign-in is unaffected." } },
            { "ErrorAnalysisVersion", new[] { "安全分析仅支持已验证的 Codex CLI 0.160.1；请在设置中选择此版本。登录功能不受此限制。", "Secure analysis requires verified Codex CLI 0.160.1. Select this version in Settings. Sign-in is unaffected." } },
            { "ErrorAnalysisPolicy", new[] { "分析已停止：CLI 返回了受限工具操作或无法验证的任务轨迹，结果未被接受。", "Analysis stopped: a restricted tool event or unverifiable trace was returned. The result was not accepted." } },
            { "ErrorResult", new[] { "Codex 未返回有效结果，请检查账号与模型设置。", "Codex did not return a valid result. Check your account and model." } },
            { "ErrorClipboard", new[] { "剪贴板暂时不可用，请稍后重试。", "The clipboard is busy. Please retry." } },
            { "ErrorImage", new[] { "无法处理图片，请尝试较小的 PNG、JPEG 或 BMP。", "Could not process the image. Try a smaller PNG, JPEG or BMP." } },
            { "ErrorFile", new[] { "操作未完成，请检查文件与目录权限。", "Could not complete the operation. Check file and folder permissions." } },
            { "SummaryTitle", new[] { "概括与建议", "Summary + next steps" } },
            { "SummaryPrompt", new[] { "请概括图片内容，提取重要文字，并给出可操作的建议。", "Summarize this image, extract key text, and suggest useful next steps." } },
            { "OcrTitle", new[] { "文字提取（OCR）", "Extract text (OCR)" } },
            { "OcrPrompt", new[] { "提取图片中的文字，保留段落、数字与重要格式。", "Extract the text in this image, preserving paragraphs, numbers, and important formatting." } },
            { "ReviewTitle", new[] { "界面分析", "Review interface" } },
            { "ReviewPrompt", new[] { "分析这张界面的信息层级与交互问题，给出具体的改进建议。", "Review this interface's hierarchy and interaction issues. Suggest specific improvements." } }
        };
        public static string Get(string language, string key, params object[] args)
        {
            string[] pair;
            string text = Values.TryGetValue(key ?? "", out pair) ? pair[language == "en" ? 1 : 0] : key ?? "";
            return args.Length == 0 ? text : String.Format(CultureInfo.CurrentCulture, text, args);
        }
        internal static IEnumerable<string> Keys { get { return Values.Keys; } }
    }

    internal sealed class PromptPreset
    {
        public readonly string Id, TitleKey, TextKey;
        public PromptPreset(string id, string title, string text) { Id = id; TitleKey = title; TextKey = text; }
    }
    internal static class PromptCatalog
    {
        public static readonly PromptPreset[] Items = {
            new PromptPreset("summary", "SummaryTitle", "SummaryPrompt"), new PromptPreset("ocr", "OcrTitle", "OcrPrompt"),
            new PromptPreset("review", "ReviewTitle", "ReviewPrompt") };
        public static PromptPreset Find(string id) { foreach (PromptPreset item in Items) if (item.Id == id) return item; return Items[0]; }
    }
}
