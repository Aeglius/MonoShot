using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace MonoShot
{
    internal static class Pictures
    {
        // Guard decoded images before allocating a second full-resolution bitmap.
        public static Bitmap Load(string path)
        {
            using (Image image = Image.FromFile(path))
            {
                if ((long)image.Width * image.Height > 100000000)
                    throw new InvalidDataException("Image is larger than 100 megapixels.");
                return new Bitmap(image);
            }
        }

        public static Rectangle Selection(Point start, Point end, Size size)
        {
            return Rectangle.Intersect(new Rectangle(Point.Empty, size),
                Rectangle.FromLTRB(Math.Min(start.X, end.X), Math.Min(start.Y, end.Y),
                    Math.Max(start.X, end.X), Math.Max(start.Y, end.Y)));
        }

        public static void Export(Bitmap image, string path)
        {
            string extension = Path.GetExtension(path).ToLowerInvariant();
            if (extension != ".png" && extension != ".jpg" && extension != ".jpeg" && extension != ".bmp")
                throw new InvalidDataException("Choose PNG, JPEG or BMP.");
            // Encode to a sibling temporary file first, so failures do not truncate an existing export.
            string temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                if (extension == ".jpg" || extension == ".jpeg")
                {
                    using (Bitmap flattened = new Bitmap(image.Width, image.Height))
                    {
                        using (Graphics graphics = Graphics.FromImage(flattened))
                        {
                            graphics.Clear(Color.White);
                            graphics.DrawImageUnscaled(image, 0, 0);
                        }
                        flattened.Save(temporary, ImageFormat.Jpeg);
                    }
                }
                else image.Save(temporary, extension == ".bmp" ? ImageFormat.Bmp : ImageFormat.Png);
                Native.CommitFile(temporary, path);
            }
            finally { Store.TryDelete(temporary); }
        }
    }
}
