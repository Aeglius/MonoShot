using System;
using System.Drawing;
using System.Threading;

namespace MonoShot
{
    internal enum WorkspacePageId { Capture, Analysis, Settings }
    internal enum JobPhase { Idle, Running, Canceling, Completed, Canceled, Failed, TimedOut }
    internal enum JobKind { Analysis, Login }
    internal enum ConnectionPhase { Missing, Configured, SigningIn, SignedIn, NeedsLogin }
    [Flags] internal enum StateChange { None = 0, Image = 1, Page = 2, Prompt = 4, Job = 8, Appearance = 16, Language = 32, Connection = 64, Status = 128, View = 256, All = 511 }
    internal sealed class StateChangedEventArgs : EventArgs
    {
        public readonly StateChange Changes;
        public StateChangedEventArgs(StateChange changes) { Changes = changes; }
    }
    internal sealed class WorkspaceJob
    {
        public readonly Guid Id = Guid.NewGuid();
        public readonly JobKind Kind;
        public readonly long ImageVersion;
        public readonly Size ImageSize;
        public readonly string Prompt, Language;
        public JobPhase Phase { get; internal set; }
        public string ErrorKey { get; internal set; }
        public WorkspaceJob(JobKind kind, long version, Size size, string prompt, string language)
        { Kind = kind; ImageVersion = version; ImageSize = size; Prompt = prompt; Language = language; Phase = JobPhase.Running; }
    }

    // All mutations and notifications belong to the WinForms UI thread. The state owns the only
    // current image; both preview controls borrow it. Worker tasks receive their own short-lived snapshot.
    internal sealed class WorkspaceState : IDisposable
    {
        private readonly int thread = Thread.CurrentThread.ManagedThreadId;
        private bool disposed;
        public event EventHandler<StateChangedEventArgs> Changed;
        public Bitmap Image { get; private set; }
        public long ImageVersion { get; private set; }
        public string ImageSource { get; private set; }
        public string ImageName { get; private set; }
        public bool FitImage { get; private set; }
        public double Zoom { get; private set; }
        public bool AnalysisPanelOpen { get; private set; }
        public WorkspacePageId NavigationPage { get { return Page == WorkspacePageId.Capture && AnalysisPanelOpen ? WorkspacePageId.Analysis : Page; } }
        public WorkspacePageId Page { get; private set; }
        public string Prompt { get; private set; }
        public string PresetId { get; private set; }
        public bool AutomaticPrompt { get; private set; }
        public string Result { get; private set; }
        public long ResultImageVersion { get; private set; }
        public Guid ResultJobId { get; private set; }
        public WorkspaceJob CurrentJob { get; private set; }
        public WorkspaceJob AnalysisJob { get; private set; }
        public CancellationTokenSource Cancellation { get; private set; }
        public string AuthInstructions { get; private set; }
        public bool AuthReady { get; private set; }
        public string Language { get; private set; }
        public string ThemeMode { get; private set; }
        public string Accent { get; private set; }
        public string CliPath { get; private set; }
        public string Model { get; private set; }
        public string CliDraft { get; private set; }
        public string ModelDraft { get; private set; }
        public ConnectionPhase Connection { get; private set; }
        public string StatusKey { get; private set; }
        public bool StatusTransient { get; private set; }
        public bool IsClosing { get; private set; }
        public bool IsImageBusy { get; private set; }
        public bool IsDisposed { get { return disposed; } }
        public bool IsWorking { get { return Cancellation != null; } }

        public WorkspaceState()
        {
            FitImage = true; Zoom = 1;
            Language = Store.Read("language", "zh") == "en" ? "en" : "zh";
            ThemeMode = NormalizeMode(Store.Read("theme", "light")); Accent = NormalizeAccent(Store.Read("accent", "ink"));
            PresetId = PromptCatalog.Find(Store.Read("preset", "summary")).Id;
            string draft = Store.Read("prompt", ""); AutomaticPrompt = String.IsNullOrWhiteSpace(draft);
            Prompt = AutomaticPrompt ? Strings.Get(Language, PromptCatalog.Find(PresetId).TextKey) : draft;
            Result = AuthInstructions = ""; CliPath = CliDraft = Store.FindCli(); Model = ModelDraft = Store.Read("model", "");
            Connection = CliPath == "" ? ConnectionPhase.Missing : ConnectionPhase.Configured; StatusKey = "Ready";
        }
        public static string NormalizeMode(string mode) { return mode == "dark" || mode == "system" ? mode : "light"; }
        public static string NormalizeAccent(string accent) { return accent == "blue" || accent == "green" ? accent : "ink"; }
        private void Verify() { if (disposed) throw new ObjectDisposedException("WorkspaceState"); if (Thread.CurrentThread.ManagedThreadId != thread) throw new InvalidOperationException("State changes require the UI thread."); }
        private void Notify(StateChange changes) { EventHandler<StateChangedEventArgs> handler = Changed; if (handler != null) handler(this, new StateChangedEventArgs(changes)); }
        public void ReplaceImage(Bitmap image, string source, string name = null)
        {
            Verify(); if (ReferenceEquals(image, Image)) return;
            Bitmap old = Image; Image = image; ImageSource = source; ImageName = name; ImageVersion++; FitImage = true; Zoom = 1;
            try { Notify(StateChange.Image); } finally { if (old != null) old.Dispose(); }
        }
        public void SetZoom(double zoom) { Verify(); if (Double.IsNaN(zoom) || Double.IsInfinity(zoom)) return; Zoom = Math.Max(Design.MinimumZoom, Math.Min(Design.MaximumZoom, zoom)); FitImage = false; Notify(StateChange.View); }
        public void FitPreview() { Verify(); FitImage = true; Notify(StateChange.View); }
        public void ShowAnalysisPanel(bool open) { Verify(); if (AnalysisPanelOpen == open) return; AnalysisPanelOpen = open; Notify(StateChange.View); }
        public void SelectPage(WorkspacePageId page) { Verify(); if (Page == page) return; Page = page; Notify(StateChange.Page); }
        public void EditPrompt(string text) { Verify(); if (Prompt == text) return; Prompt = text; AutomaticPrompt = false; Notify(StateChange.Prompt); }
        public void SelectPreset(string id) { Verify(); PresetId = PromptCatalog.Find(id).Id; AutomaticPrompt = true; Prompt = Strings.Get(Language, PromptCatalog.Find(PresetId).TextKey); Notify(StateChange.Prompt); }
        public void SetLanguage(string language)
        {
            Verify(); language = language == "en" ? "en" : "zh"; if (Language == language) return;
            Language = language; if (AutomaticPrompt) Prompt = Strings.Get(Language, PromptCatalog.Find(PresetId).TextKey);
            Notify(StateChange.Language | StateChange.Prompt | StateChange.Status);
        }
        public void SetAppearance(string mode, string accent)
        { Verify(); ThemeMode = NormalizeMode(mode); Accent = NormalizeAccent(accent); Notify(StateChange.Appearance); }
        public void EditConnection(string cli, string model) { Verify(); CliDraft = cli; ModelDraft = model; Notify(StateChange.Connection); }
        public void CommitConnection()
        { Verify(); CliPath = CliDraft; Model = ModelDraft; Connection = CliPath == "" ? ConnectionPhase.Missing : ConnectionPhase.Configured; Notify(StateChange.Connection); }
        public void Status(string key, bool transient) { Verify(); StatusKey = key; StatusTransient = transient; Notify(StateChange.Status); }
        public void ImageBusy(bool busy) { Verify(); IsImageBusy = busy; Notify(StateChange.Image); }
        internal void Begin(WorkspaceJob job, CancellationTokenSource cancellation)
        {
            Verify(); if (IsWorking) throw new InvalidOperationException("Only one CLI task can run at once.");
            CurrentJob = job; Cancellation = cancellation;
            if (job.Kind == JobKind.Analysis) AnalysisJob = job;
            else { AuthInstructions = ""; AuthReady = false; Connection = ConnectionPhase.SigningIn; }
            StatusKey = job.Kind == JobKind.Analysis ? "Running" : "SigningIn"; StatusTransient = false;
            Notify(StateChange.Job | StateChange.Connection | StateChange.Status);
        }
        internal bool IsCurrent(WorkspaceJob job) { return !disposed && !IsClosing && CurrentJob == job && Cancellation != null; }
        internal void AuthLine(WorkspaceJob job, string line)
        {
            Verify(); if (!IsCurrent(job) || job.Kind != JobKind.Login || Cancellation.IsCancellationRequested) return;
            if (AuthInstructions.Length < 32768) { AuthInstructions += line + Environment.NewLine; AuthReady = Secrets.HasDeviceInstructions(AuthInstructions); Notify(StateChange.Connection); }
        }
        internal void Complete(WorkspaceJob job, JobPhase phase, string result, string error)
        {
            Verify(); if (CurrentJob != job) return;
            job.Phase = phase; job.ErrorKey = error;
            if (job.Kind == JobKind.Analysis && phase == JobPhase.Completed && !IsClosing && !Cancellation.IsCancellationRequested)
            { Result = result; ResultImageVersion = job.ImageVersion; ResultJobId = job.Id; }
            if (job.Kind == JobKind.Login) Connection = phase == JobPhase.Completed ? ConnectionPhase.SignedIn : ConnectionPhase.Configured;
            if (error == "ErrorAuth") Connection = ConnectionPhase.NeedsLogin;
            StatusKey = error ?? (job.Kind == JobKind.Login && phase == JobPhase.Completed ? "SignedIn" : phase.ToString()); StatusTransient = false;
            Notify(StateChange.Job | StateChange.Connection | StateChange.Status);
        }
        internal void End(WorkspaceJob job)
        {
            Verify(); if (CurrentJob != job) return;
            Cancellation = null; AuthInstructions = ""; AuthReady = false; Notify(StateChange.Job | StateChange.Connection);
        }
        public void Cancel()
        {
            Verify(); if (!IsWorking || Cancellation.IsCancellationRequested) return;
            CurrentJob.Phase = JobPhase.Canceling;
            try { Cancellation.Cancel(); } catch (ObjectDisposedException) { /* The coordinator may already have released this borrowed source. */ }
            StatusKey = "Canceling"; StatusTransient = false; Notify(StateChange.Job | StateChange.Status);
        }
        public void Close() { Verify(); IsClosing = true; Cancel(); }
        public void Dispose()
        {
            if (disposed) return; Verify(); IsClosing = true;
            if (Cancellation != null) { try { Cancellation.Cancel(); } catch (ObjectDisposedException) { } Cancellation = null; }
            disposed = true; Changed = null; if (Image != null) Image.Dispose(); Image = null; AuthInstructions = "";
        }
    }
}
