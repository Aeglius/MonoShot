using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;

namespace MonoShot
{
    internal enum Ease { Linear, OutCubic, InOutCubic }

    internal sealed class MotionHub : IDisposable
    {
        private sealed class Track
        {
            public object Owner; public string Channel; public double Start, Duration, From, To;
            public Ease Curve; public Action<double> Update; public Action Complete;
            public bool Delay;
        }
        private readonly Timer timer = new Timer { Interval = 16 };
        private readonly List<Track> tracks = new List<Track>();
        private readonly List<Track> frame = new List<Track>();
        private readonly Func<double> clock;
        private readonly Func<bool> allowed;
        private bool disposed;
        public int ActiveCount { get { return tracks.Count; } }
        public bool IsRunning { get { return timer.Enabled; } }

        public MotionHub() : this(() => Stopwatch.GetTimestamp() * 1000.0 / Stopwatch.Frequency, () => Native.MotionAllowed) { }
        internal MotionHub(Func<double> monotonicClock, Func<bool> motionAllowed)
        {
            clock = monotonicClock;
            allowed = motionAllowed;
            timer.Tick += Tick;
        }

        public static double Curve(Ease ease, double progress)
        {
            double t = Math.Max(0, Math.Min(1, progress));
            if (ease == Ease.OutCubic) return 1 - Math.Pow(1 - t, 3);
            if (ease == Ease.InOutCubic) return t < .5 ? 4 * t * t * t : 1 - Math.Pow(-2 * t + 2, 3) / 2;
            return t;
        }

        public void Animate(object owner, string channel, double from, double to, int milliseconds,
            Ease curve, Action<double> update, Action complete)
        {
            if (disposed) return;
            Cancel(owner, channel);
            if (milliseconds <= 0 || !allowed() || Math.Abs(from - to) < .0001)
            {
                update(to);
                if (complete != null) complete();
                return;
            }
            tracks.Add(new Track { Owner = owner, Channel = channel, Start = clock(), Duration = milliseconds,
                From = from, To = to, Curve = curve, Update = update, Complete = complete });
            timer.Start();
        }

        public void Cancel(object owner, string channel)
        {
            for (int i = tracks.Count - 1; i >= 0; i--)
                if (ReferenceEquals(tracks[i].Owner, owner) && (channel == null || tracks[i].Channel == channel))
                    tracks.RemoveAt(i);
            if (tracks.Count == 0) timer.Stop();
        }

        public void Delay(object owner, string channel, int milliseconds, Action complete)
        {
            if (disposed) return;
            Cancel(owner, channel);
            if (milliseconds <= 0) { if (complete != null) complete(); return; }
            tracks.Add(new Track { Owner = owner, Channel = channel, Start = clock(), Duration = milliseconds,
                Delay = true, Complete = complete });
            timer.Start();
        }

        private void Tick(object sender, EventArgs e) { Step(); }
        internal void Step()
        {
            if (disposed) return;
            double now = clock();
            bool animate = allowed();
            // Reuse a snapshot because callbacks may replace or cancel another channel.
            frame.Clear();
            frame.AddRange(tracks);
            foreach (Track track in frame)
            {
                if (!tracks.Contains(track)) continue;
                double progress = animate || track.Delay ? Math.Max(0, Math.Min(1, (now - track.Start) / track.Duration)) : 1;
                if (progress >= 1) tracks.Remove(track);
                if (track.Update != null) track.Update(track.From + (track.To - track.From) * Curve(track.Curve, progress));
                if (progress >= 1 && track.Complete != null) track.Complete();
            }
            frame.Clear();
            if (tracks.Count == 0) timer.Stop();
        }

        public void Dispose()
        {
            if (disposed) return;
            disposed = true;
            timer.Stop();
            timer.Tick -= Tick;
            timer.Dispose();
            tracks.Clear();
            frame.Clear();
        }
    }
}
