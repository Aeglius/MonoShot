using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace MonoShot
{
    internal sealed class MainForm : Form
    {
        private readonly MotionHub motion;
        private readonly UiTheme theme;
        private readonly WorkspaceState state;
        private readonly AnalysisCoordinator coordinator;
        private readonly CancellationTokenSource lifetime = new CancellationTokenSource();
        private readonly TableLayoutPanel root;
        private readonly Panel pageHost;
        private readonly CustomTitleBar chrome;
        private readonly StatusNote status;
        private readonly WorkspaceNavigation navigation;
        private readonly WorkspacePage[] pages;
        private readonly bool previewMode;
        private readonly Icon appIcon;
        private CaptureOverlay overlay;
        private bool imageBusy, capturing, closing, closeQueued, hotkeyRegistered, resourcesDisposed, systemEvents;
        private WorkspacePageId visiblePage;
        private bool mountedSidebar, requestedSidebar;
        private Size normalBeforeMaximize;
        private bool restoreSizePending;
        internal CustomTitleBar Chrome { get { return chrome; } }
        internal WorkspaceState State { get { return state; } }
        internal UiTheme Theme { get { return theme; } }
        internal MotionHub Motion { get { return motion; } }
        internal AnalysisCoordinator Coordinator { get { return coordinator; } }
        internal CapturePage CaptureView { get { return (CapturePage)pages[0]; } }
        internal AnalysisPage AnalysisView { get { return (AnalysisPage)pages[1]; } }
        internal PreferencesPage SettingsView { get { return (PreferencesPage)pages[2]; } }
        internal WorkspaceNavigation Navigation { get { return navigation; } }
        internal bool IsBusy { get { return imageBusy || capturing || state.IsWorking; } }
        public MainForm() : this(false, null) { }
        internal MainForm(bool preview) : this(preview, null) { }
        internal MainForm(bool preview, Func<string, string, string, string, CancellationToken, Task<string>> analysis)
            : this(preview, analysis, null) { }
        internal MainForm(bool preview, Func<string, string, string, string, CancellationToken, Task<string>> analysis, MotionHub scheduler)
        {
            motion = scheduler ?? new MotionHub();
            previewMode = preview; state = new WorkspaceState(); theme = new UiTheme(motion);
            coordinator = analysis == null ? new AnalysisCoordinator(state, this) : new AnalysisCoordinator(state, this, analysis);
            AutoScaleDimensions = new SizeF(96, 96); AutoScaleMode = AutoScaleMode.Dpi;
            Font = theme.Body; Text = Product.Name; ClientSize = Design.InitialSize; MinimumSize = Design.MinimumWindow;
            appIcon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); Icon = appIcon;
            StartPosition = FormStartPosition.CenterScreen; KeyPreview = true; DoubleBuffered = true;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            // Client painting has no managed non-client insets; CreateParams retains native sizing/system styles.
            FormBorderStyle = FormBorderStyle.None; UpdateShellPadding();
            root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3,
                Padding = new Padding(Design.PagePadding, Design.Gap, Design.PagePadding, 0) };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, Design.NavigationHeight));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); root.RowStyles.Add(new RowStyle(SizeType.Absolute, Design.StatusHeight)); Controls.Add(root);
            navigation = new WorkspaceNavigation(state, theme, motion) { Dock = DockStyle.Fill, Margin = Padding.Empty, TabIndex = 0 }; root.Controls.Add(navigation, 0, 0);
            pageHost = new Panel { Dock = DockStyle.Fill, Margin = Padding.Empty, TabIndex = 1 }; root.Controls.Add(pageHost, 0, 1);
            pages = new WorkspacePage[] { new CapturePage(state, theme, motion), new AnalysisPage(state, theme, motion), new PreferencesPage(state, theme, motion) };
            foreach (WorkspacePage page in pages) { page.Visible = false; page.ActionRequested += RunAction; pageHost.Controls.Add(page); }
            CaptureView.SidebarHidden += SidebarHidden;
            status = new StatusNote(theme, motion) { Dock = DockStyle.Fill, Margin = Padding.Empty }; root.Controls.Add(status, 0, 2);
            chrome = new CustomTitleBar(this, theme, motion, state);
            state.Changed += StateChanged; theme.Changed += ThemeChanged;
            AllowDrop = CaptureView.Preview.AllowDrop = true;
            DragEnter += DragImageEnter; DragDrop += DropImage; CaptureView.Preview.DragEnter += DragImageEnter; CaptureView.Preview.DragDrop += DropImage;
            Translate(); ApplyTheme(); ShowPage(false, false); UpdateImageControls();
            FormClosing += HandleClosing; Shown += ShownWindow;
        }
        private string T(string key) { return Strings.Get(state.Language, key); }
        private void StateChanged(object sender, StateChangedEventArgs e)
        {
            if (resourcesDisposed) return;
            if ((e.Changes & StateChange.Page) != 0) ShowPage(true);
            else if ((e.Changes & StateChange.View) != 0 && requestedSidebar != (state.Page == WorkspacePageId.Capture && state.AnalysisPanelOpen)) ShowPage(true);
            if ((e.Changes & StateChange.Language) != 0)
            {
                Translate(); if (!previewMode) TrySave(() => Store.Write("language", state.Language));
            }
            if ((e.Changes & StateChange.Appearance) != 0)
            {
                theme.ChangeMode(state.ThemeMode, state.Accent, true); Native.StyleWindow(Handle, theme.Dark);
                if (!previewMode) TrySave(theme.Save);
            }
            if ((e.Changes & (StateChange.Status | StateChange.Language)) != 0) status.ShowMessage(T(state.StatusKey), state.StatusTransient);
            if ((e.Changes & StateChange.Job) != 0) CloseIfReady();
        }
        private void ShowPage(bool restoreFocus, bool animateSidebar = true)
        {
            bool aiFocus = AnalysisView.ContainsFocus; pages[(int)visiblePage].RememberFocus(); AnalysisView.RememberFocus(); pageHost.SuspendLayout();
            requestedSidebar = state.Page == WorkspacePageId.Capture && state.AnalysisPanelOpen;
            mountedSidebar = requestedSidebar || (mountedSidebar && state.Page == WorkspacePageId.Capture && animateSidebar && CaptureView.SidebarProgress > 0);
            Control host = mountedSidebar ? (Control)CaptureView.SideHost : pageHost;
            if (AnalysisView.Parent != host) { AnalysisView.Parent.Controls.Remove(AnalysisView); host.Controls.Add(AnalysisView); }
            AnalysisView.SetSidebar(mountedSidebar);
            for (int i = 0; i < pages.Length; i++) pages[i].Visible = i == (int)state.Page || (i == 1 && mountedSidebar);
            visiblePage = state.Page; pages[(int)visiblePage].BringToFront(); if (mountedSidebar) AnalysisView.BringToFront(); pageHost.ResumeLayout(true);
            CaptureView.SetSidebarVisible(requestedSidebar, animateSidebar && state.Page == WorkspacePageId.Capture);
            if (restoreFocus && !closing) { if (aiFocus && requestedSidebar) AnalysisView.RestoreFocus(); else pages[(int)visiblePage].RestoreFocus(); }
        }
        private void SidebarHidden(object sender, EventArgs e)
        {
            if (!IsHandleCreated || resourcesDisposed || closing) return;
            BeginInvoke((Action)(() => {
                if (!resourcesDisposed && !closing && !requestedSidebar && mountedSidebar && state.Page == WorkspacePageId.Capture)
                    ShowPage(false, false);
            }));
        }
        private void Translate()
        {
            status.ShowMessage(T(state.StatusKey), state.StatusTransient);
        }
        private void ThemeChanged(object sender, EventArgs e) { ApplyTheme(); }
        private void ApplyTheme()
        {
            root.BackColor = BackColor = pageHost.BackColor = theme.Colors.Background;
            Invalidate();
        }
        private void SystemPreferencesChanged(object sender, UserPreferenceChangedEventArgs e)
        {
            if (!IsHandleCreated || closing || resourcesDisposed) return;
            try { BeginInvoke((Action)(() => { if (!closing && !resourcesDisposed) { theme.ChangeMode(state.ThemeMode, state.Accent, true); Native.StyleWindow(Handle, theme.Dark); } })); }
            catch (InvalidOperationException) { }
        }
        private void TrySave(Action save) { try { save(); } catch (IOException) { state.Status("ErrorFile", false); } catch (UnauthorizedAccessException) { state.Status("ErrorFile", false); } }
        private void RunAction(WorkspaceAction action)
        {
            if (closing) return;
            try
            {
                switch (action)
                {
                    case WorkspaceAction.Region: CaptureScreen(false); break;
                    case WorkspaceAction.Screen: CaptureScreen(true); break;
                    case WorkspaceAction.Open: OpenImage(); break;
                    case WorkspaceAction.Copy: CopyImage(); break;
                    case WorkspaceAction.Paste: PasteImage(); break;
                    case WorkspaceAction.Export: ExportImage(); break;
                    case WorkspaceAction.Analyze: RunCli(false); break;
                    case WorkspaceAction.Login: RunCli(true); break;
                    case WorkspaceAction.Cancel: state.Cancel(); break;
                    case WorkspaceAction.CopyResult: CopyAnswer(); break;
                    case WorkspaceAction.SaveResult: SaveAnswer(); break;
                    case WorkspaceAction.Browse: BrowseCli(); break;
                    case WorkspaceAction.SaveConnection: SaveConnection(); break;
                    case WorkspaceAction.OpenAnalysisWorkspace: state.SelectPage(WorkspacePageId.Analysis); break;
                    case WorkspaceAction.CloseAnalysisPanel: state.ShowAnalysisPanel(false); break;
                }
            }
            catch (Exception error) { ShowError(error); }
        }
        private async void RunCli(bool login)
        {
            try
            {
                if (login && !state.IsWorking) { if (!SaveConnection()) return; state.SelectPage(WorkspacePageId.Settings); }
                await (login ? coordinator.StartLogin() : coordinator.StartAnalysis());
            }
            catch (Exception error) { ShowError(error); }
            finally { CloseIfReady(); }
        }
        private void BrowseCli()
        {
            using (OpenFileDialog dialog = new OpenFileDialog { Filter = "Codex executable|*.exe" })
                if (dialog.ShowDialog(this) == DialogResult.OK) state.EditConnection(dialog.FileName, state.ModelDraft);
        }
        private bool SaveConnection()
        {
            if (state.IsWorking) return false;
            if (!Store.IsExecutable(state.CliDraft)) { state.Status("MissingCli", false); return false; }
            Store.Write("cli", state.CliDraft); Store.Write("model", state.ModelDraft); state.CommitConnection(); state.Status("Saved", true);
            return true;
        }
        private void ShowError(Exception error) { if (!closing && !IsDisposed && !state.IsDisposed) state.Status(Errors.Key(error), false); }
        private void ReplaceImage(Bitmap image, string source, string name = null) { state.ReplaceImage(image, source, name); state.Status("ImageReady", true); }
        private void UpdateImageControls() { CaptureView.SetImageBusy(imageBusy || capturing); state.ImageBusy(imageBusy || capturing); }
        private async void OpenImage()
        {
            if (imageBusy || capturing || closing) return;
            using (OpenFileDialog dialog = new OpenFileDialog { Filter = "Images|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tif;*.tiff", InitialDirectory = Store.Exports })
                if (dialog.ShowDialog(this) == DialogResult.OK) await LoadImage(dialog.FileName);
        }
        internal async Task LoadImage(string path)
        {
            if (imageBusy || capturing || closing) return; imageBusy = true; UpdateImageControls(); state.Status("Opening", false);
            try { Bitmap image = await Task.Run(() => Pictures.Load(path)); if (closing) image.Dispose(); else ReplaceImage(image, "open", Path.GetFileName(path)); }
            catch (Exception error) { ShowError(error); }
            finally { imageBusy = false; UpdateImageControls(); CloseIfReady(); }
        }
        private static void DragImageEnter(object sender, DragEventArgs e) { if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy; }
        private async void DropImage(object sender, DragEventArgs e)
        {
            if (!e.Data.GetDataPresent(DataFormats.FileDrop) || closing) return;
            string[] files = e.Data.GetData(DataFormats.FileDrop) as string[]; if (files != null && files.Length > 0) await LoadImage(files[0]);
        }
        private async Task ClipboardAction(Action action)
        {
            for (int attempt = 0; attempt < 4; attempt++)
            {
                lifetime.Token.ThrowIfCancellationRequested();
                try { action(); return; } catch (ExternalException) { if (attempt == 3) throw; }
                await Task.Delay(40, lifetime.Token);
            }
        }
        private async void CopyImage()
        {
            if (state.Image == null || closing) return;
            try { await ClipboardAction(() => { if (state.Image != null) Clipboard.SetImage(state.Image); }); if (!closing) state.Status("Copied", true); }
            catch (Exception error) { ShowError(error); }
        }
        private async void PasteImage()
        {
            if (imageBusy || capturing || closing) return;
            string file = null;
            try
            {
                await ClipboardAction(() => {
                    if (Clipboard.ContainsImage()) { using (Image image = Clipboard.GetImage()) if (image != null) ReplaceImage(new Bitmap(image), "paste"); }
                    else if (Clipboard.ContainsFileDropList()) { System.Collections.Specialized.StringCollection files = Clipboard.GetFileDropList(); if (files.Count > 0) file = files[0]; }
                    else state.Status("NoClipboardImage", true);
                });
                if (file != null) await LoadImage(file);
            }
            catch (Exception error) { ShowError(error); }
        }
        private async void ExportImage()
        {
            if (state.Image == null || imageBusy || capturing || closing) return;
            using (SaveFileDialog dialog = new SaveFileDialog { Filter = "PNG image|*.png|JPEG image|*.jpg|Bitmap image|*.bmp", InitialDirectory = Store.Exports,
                FileName = "MonoShot-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".png", AddExtension = true, OverwritePrompt = true })
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                imageBusy = true; UpdateImageControls();
                try
                {
                    using (Bitmap snapshot = state.Image.Clone(new Rectangle(Point.Empty, state.Image.Size), PixelFormat.Format32bppArgb))
                        await Task.Run(() => Pictures.Export(snapshot, dialog.FileName));
                    if (!closing) state.Status("Exported", true);
                }
                catch (Exception error) { ShowError(error); }
                finally { imageBusy = false; UpdateImageControls(); CloseIfReady(); }
            }
        }
        private async void CopyAnswer()
        {
            if (state.Result.Length == 0 || closing) return;
            try { await ClipboardAction(() => Clipboard.SetText(state.Result)); if (!closing) state.Status("Copied", true); }
            catch (Exception error) { ShowError(error); }
        }
        private async void SaveAnswer()
        {
            if (state.Result.Length == 0 || imageBusy || closing) return;
            using (SaveFileDialog dialog = new SaveFileDialog { Filter = "Markdown|*.md|Text|*.txt", InitialDirectory = Store.Exports, FileName = "analysis-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".md" })
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                string result = state.Result; imageBusy = true; UpdateImageControls();
                try { await Task.Run(() => File.WriteAllText(dialog.FileName, result, new UTF8Encoding(false))); if (!closing) state.Status("Exported", true); }
                catch (Exception error) { ShowError(error); }
                finally { imageBusy = false; UpdateImageControls(); CloseIfReady(); }
            }
        }
        private async void CaptureScreen(bool full)
        {
            if (capturing || imageBusy || closing) return;
            state.SelectPage(WorkspacePageId.Capture); capturing = true; UpdateImageControls(); Hide(); Bitmap screenshot = null, captured = null;
            try
            {
                await Task.Delay(180, lifetime.Token); Rectangle desktop = SystemInformation.VirtualScreen;
                screenshot = await Task.Run(() => {
                    Bitmap bitmap = new Bitmap(desktop.Width, desktop.Height, PixelFormat.Format32bppArgb);
                    try { using (Graphics graphics = Graphics.FromImage(bitmap)) graphics.CopyFromScreen(desktop.Location, Point.Empty, desktop.Size, CopyPixelOperation.SourceCopy); return bitmap; }
                    catch { bitmap.Dispose(); throw; }
                });
                lifetime.Token.ThrowIfCancellationRequested();
                if (full) { captured = screenshot; screenshot = null; }
                else
                {
                    using (overlay = new CaptureOverlay(screenshot, desktop, state.Language == "en"))
                        if (overlay.ShowDialog(this) == DialogResult.OK) captured = overlay.TakeResult();
                    overlay = null;
                }
                if (captured != null && !closing) { ReplaceImage(captured, full ? "screen" : "region"); captured = null; }
                else if (!closing) state.Status("CaptureCanceled", true);
            }
            catch (Exception error) { ShowError(error); }
            finally
            {
                overlay = null; if (screenshot != null) screenshot.Dispose(); if (captured != null) captured.Dispose();
                capturing = false; if (!closing && !IsDisposed) { Show(); Activate(); } UpdateImageControls(); CloseIfReady();
            }
        }
        private void ShownWindow(object sender, EventArgs e)
        {
            CaptureView.RestoreFocus(); if (previewMode) return;
            hotkeyRegistered = Native.RegisterHotKey(Handle, 191, 0x4003, (uint)Keys.A);
            if (!hotkeyRegistered) state.Status("HotkeyUnavailable", false);
            SystemEvents.UserPreferenceChanged += SystemPreferencesChanged; systemEvents = true;
        }
        private void HandleClosing(object sender, FormClosingEventArgs e)
        {
            if (!closing)
            {
                closing = true; lifetime.Cancel(); state.Close();
                if (overlay != null && !overlay.IsDisposed) overlay.Close();
                if (!previewMode) TrySave(() => { Store.Write("prompt", Secrets.ForDisplay(state.Prompt)); Store.Write("preset", state.PresetId); });
            }
            e.Cancel = IsBusy;
        }
        private void CloseIfReady()
        {
            if (closing && !IsBusy && !closeQueued && !IsDisposed && IsHandleCreated)
            { closeQueued = true; BeginInvoke((Action)Close); }
        }
        private void UpdateShellPadding() { int edge = Design.Px(this, Design.ResizeBorder); Padding = new Padding(edge, Design.Px(this, Design.TitleBarHeight), edge, edge); }
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams parameters = base.CreateParams;
                // Keep WS_THICKFRAME, WS_SYSMENU, WS_MINIMIZEBOX and WS_MAXIMIZEBOX.
                // Only the native caption's visual styles are removed.
                parameters.Style = (parameters.Style & ~0x00C00000) | 0x000F0000; return parameters;
            }
        }
        protected override void OnDpiChanged(DpiChangedEventArgs e)
        { base.OnDpiChanged(e); UpdateShellPadding(); MinimumSize = new Size(Design.Px(this, Design.MinimumWindow.Width), Design.Px(this, Design.MinimumWindow.Height)); if (chrome != null) chrome.Layout(); }
        protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e); Native.StyleWindow(Handle, theme != null && theme.Dark); Native.FrameChanged(Handle); }
        protected override void WndProc(ref Message message)
        {
            if (message.Msg == Native.WmSysCommand)
            {
                int command = message.WParam.ToInt32() & 0xFFF0;
                if (command == 0xF030 && WindowState == FormWindowState.Normal) { normalBeforeMaximize = Size; restoreSizePending = true; }
                base.WndProc(ref message);
                // WinForms accounts for WS_THICKFRAME again when restoring a borderless client.
                // Correct the client size, preserving the native location (including drag-to-restore).
                if (command == 0xF120 && restoreSizePending && WindowState == FormWindowState.Normal)
                { restoreSizePending = false; Size = normalBeforeMaximize; }
                return;
            }
            if (message.Msg == Native.WmNcCalcSize && message.WParam != IntPtr.Zero) { Native.ConstrainMaximizedClient(message.HWnd, message.LParam); message.Result = IntPtr.Zero; return; }
            if (message.Msg == Native.WmGetMinMaxInfo) { base.WndProc(ref message); Native.SetMinMax(message.HWnd, message.LParam, MinimumSize); return; }
            if (message.Msg == Native.WmNcHitTest && chrome != null) { message.Result = new IntPtr(chrome.HitTest(PointToClient(Native.ScreenPoint(message.LParam)))); return; }
            if (chrome != null && chrome.HandleNonClient(ref message)) return;
            if (message.Msg == 0x0312 && message.WParam.ToInt32() == 191 && !closing) CaptureScreen(false);
            base.WndProc(ref message);
        }
        private static bool EditingText(Control parent)
        {
            if (parent.Focused && parent is TextBoxBase) return true;
            foreach (Control child in parent.Controls) if (child.ContainsFocus && EditingText(child)) return true;
            return false;
        }
        protected override bool ProcessCmdKey(ref Message message, Keys key)
        {
            if (closing) return base.ProcessCmdKey(ref message, key);
            if (key == (Keys.Alt | Keys.Space)) { Native.ShowSystemMenu(this, PointToScreen(new Point(Design.ResizeBorder, Design.Px(this, Design.TitleBarHeight)))); return true; }
            if (key >= (Keys.Control | Keys.D1) && key <= (Keys.Control | Keys.D3)) { state.SelectPage((WorkspacePageId)((int)key - (int)(Keys.Control | Keys.D1))); return true; }
            if (key == (Keys.Control | Keys.O)) { OpenImage(); return true; }
            if (key == (Keys.Control | Keys.S)) { ExportImage(); return true; }
            if (!EditingText(this))
            {
                if (key == (Keys.Control | Keys.C)) { CopyImage(); return true; }
                if (key == (Keys.Control | Keys.V)) { PasteImage(); return true; }
            }
            return base.ProcessCmdKey(ref message, key);
        }
        internal void Preview(bool english, bool dark, string accent)
        { state.SetLanguage(english ? "en" : "zh"); state.SetAppearance(dark ? "dark" : "light", accent); theme.Change(dark, accent, false); }
        protected override void Dispose(bool disposing)
        {
            bool release = disposing && !resourcesDisposed;
            if (release)
            {
                resourcesDisposed = true;
                if (hotkeyRegistered && IsHandleCreated) Native.UnregisterHotKey(Handle, 191);
                if (systemEvents) SystemEvents.UserPreferenceChanged -= SystemPreferencesChanged;
                state.Changed -= StateChanged; theme.Changed -= ThemeChanged; coordinator.Dispose(); lifetime.Cancel(); motion.Dispose();
                if (chrome != null) chrome.Dispose();
                CaptureView.SidebarHidden -= SidebarHidden;
            }
            base.Dispose(disposing);
            if (release) { state.Dispose(); lifetime.Dispose(); theme.Dispose(); if (appIcon != null) appIcon.Dispose(); }
        }
    }
}
