using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Windows.Forms;

namespace MonoShot
{
    internal static class Native
    {
        internal const int WmNcHitTest = 0x84, WmNcCalcSize = 0x83, WmGetMinMaxInfo = 0x24, WmSysCommand = 0x112,
            HtClient = 1, HtCaption = 2, HtMaxButton = 9, HtLeft = 10, HtRight = 11, HtTop = 12, HtTopLeft = 13, HtTopRight = 14, HtBottom = 15, HtBottomLeft = 16, HtBottomRight = 17;
        [StructLayout(LayoutKind.Sequential)] internal struct NativePoint { public int X, Y; public NativePoint(int x, int y) { X = x; Y = y; } }
        [StructLayout(LayoutKind.Sequential)] internal struct NativeRect { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential)] internal struct MinMaxInfo { public NativePoint Reserved, MaxSize, MaxPosition, MinTrackSize, MaxTrackSize; }
        [StructLayout(LayoutKind.Sequential)] private struct MonitorInfo { public int Size; public NativeRect Monitor, Work; public uint Flags; }
        [StructLayout(LayoutKind.Sequential)] private struct MouseTrack { public uint Size, Flags; public IntPtr Window; public uint HoverTime; }
        [DllImport("user32.dll")] private static extern IntPtr MonitorFromWindow(IntPtr window, uint flags);
        [DllImport("user32.dll")] private static extern IntPtr MonitorFromRect(ref NativeRect rectangle, uint flags);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorInfo info);
        [DllImport("user32.dll")] internal static extern IntPtr SendMessage(IntPtr window, int message, IntPtr wparam, IntPtr lparam);
        [DllImport("user32.dll")] internal static extern bool ReleaseCapture();
        [DllImport("user32.dll")] internal static extern IntPtr SetCapture(IntPtr window);
        [DllImport("user32.dll")] private static extern bool IsZoomed(IntPtr window);
        [DllImport("user32.dll", EntryPoint = "GetWindowLongW")] private static extern int GetWindowLong(IntPtr window, int index);
        internal static bool HasWindowStyles(IntPtr window, int styles) { return (GetWindowLong(window, -16) & styles) == styles; }
        [DllImport("user32.dll")] private static extern bool TrackMouseEvent(ref MouseTrack track);
        [DllImport("user32.dll")] private static extern IntPtr GetSystemMenu(IntPtr window, bool reset);
        [DllImport("user32.dll")] private static extern uint TrackPopupMenuEx(IntPtr menu, uint flags, int x, int y, IntPtr window, IntPtr parameters);
        [DllImport("user32.dll")] private static extern bool EnableMenuItem(IntPtr menu, uint item, uint flags);
        [DllImport("user32.dll")] private static extern bool SetWindowPos(IntPtr window, IntPtr after, int x, int y, int width, int height, uint flags);

        internal static Point ScreenPoint(IntPtr packed) { long value = packed.ToInt64(); return new Point(unchecked((short)(value & 65535)), unchecked((short)((value >> 16) & 65535))); }
        internal static IntPtr PackPoint(Point point) { return new IntPtr(unchecked((int)(((uint)(ushort)point.Y << 16) | (ushort)point.X))); }
        internal static int ResizeHit(Point p, Size size, int edge, bool maximized)
        {
            if (maximized || p.X < 0 || p.Y < 0 || p.X >= size.Width || p.Y >= size.Height) return HtClient;
            bool left = p.X < edge, right = p.X >= size.Width - edge, top = p.Y < edge, bottom = p.Y >= size.Height - edge;
            return top ? (left ? HtTopLeft : right ? HtTopRight : HtTop) : bottom ? (left ? HtBottomLeft : right ? HtBottomRight : HtBottom) : left ? HtLeft : right ? HtRight : HtClient;
        }
        internal static void ApplyWorkArea(ref MinMaxInfo info, Rectangle monitor, Rectangle work, Size minimum)
        {
            info.MaxPosition = new NativePoint(work.Left - monitor.Left, work.Top - monitor.Top);
            info.MaxSize = new NativePoint(work.Width, work.Height);
            info.MinTrackSize = new NativePoint(minimum.Width, minimum.Height);
        }
        internal static void SetMinMax(IntPtr window, IntPtr address, Size minimum)
        {
            MonitorInfo monitor = new MonitorInfo { Size = Marshal.SizeOf(typeof(MonitorInfo)) };
            if (!GetMonitorInfo(MonitorFromWindow(window, 2), ref monitor)) return;
            MinMaxInfo info = (MinMaxInfo)Marshal.PtrToStructure(address, typeof(MinMaxInfo));
            ApplyWorkArea(ref info, Rectangle.FromLTRB(monitor.Monitor.Left, monitor.Monitor.Top, monitor.Monitor.Right, monitor.Monitor.Bottom),
                Rectangle.FromLTRB(monitor.Work.Left, monitor.Work.Top, monitor.Work.Right, monitor.Work.Bottom), minimum);
            Marshal.StructureToPtr(info, address, false);
        }
        internal static void ConstrainMaximizedClient(IntPtr window, IntPtr address)
        {
            if (!IsZoomed(window)) return;
            NativeRect area = (NativeRect)Marshal.PtrToStructure(address, typeof(NativeRect));
            MonitorInfo monitor = new MonitorInfo { Size = Marshal.SizeOf(typeof(MonitorInfo)) };
            if (!GetMonitorInfo(MonitorFromRect(ref area, 2), ref monitor)) return;
            area.Left = Math.Max(area.Left, monitor.Work.Left); area.Top = Math.Max(area.Top, monitor.Work.Top);
            area.Right = Math.Min(area.Right, monitor.Work.Right); area.Bottom = Math.Min(area.Bottom, monitor.Work.Bottom);
            Marshal.StructureToPtr(area, address, false);
        }
        internal static void FrameChanged(IntPtr window) { SetWindowPos(window, IntPtr.Zero, 0, 0, 0, 0, 0x37); }
        internal static void TrackNonClientLeave(IntPtr window) { MouseTrack track = new MouseTrack { Size = (uint)Marshal.SizeOf(typeof(MouseTrack)), Flags = 0x12, Window = window }; TrackMouseEvent(ref track); }
        internal static void ShowSystemMenu(Form owner, Point screen)
        {
            IntPtr menu = GetSystemMenu(owner.Handle, false); bool max = owner.WindowState == FormWindowState.Maximized;
            EnableMenuItem(menu, 0xF120, max ? 0u : 1u); EnableMenuItem(menu, 0xF030, max ? 1u : 0u);
            EnableMenuItem(menu, 0xF000, max ? 1u : 0u); EnableMenuItem(menu, 0xF010, max ? 1u : 0u);
            uint command = TrackPopupMenuEx(menu, 0x100 | 0x2, screen.X, screen.Y, owner.Handle, IntPtr.Zero);
            if (command != 0) SendMessage(owner.Handle, WmSysCommand, new IntPtr(command), IntPtr.Zero);
        }
        [DllImport("user32.dll")] internal static extern bool RegisterHotKey(IntPtr window, int id, uint modifiers, uint key);
        [DllImport("user32.dll")] internal static extern bool UnregisterHotKey(IntPtr window, int id);
        [DllImport("user32.dll")] private static extern bool SetProcessDpiAwarenessContext(IntPtr context);
        [DllImport("user32.dll")] private static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")] private static extern bool SystemParametersInfo(uint action, uint parameter, out int value, uint flags);
        [DllImport("user32.dll", EntryPoint = "SystemParametersInfoW")]
        private static extern bool GetAnimationInfo(uint action, uint parameter, ref AnimationInfo value, uint flags);
        [DllImport("dwmapi.dll")] private static extern int DwmSetWindowAttribute(IntPtr window, int attribute, ref int value, int size);
        [DllImport("user32.dll")] internal static extern int GetGuiResources(IntPtr process, int flags);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool MoveFileEx(string existingName, string newName, uint flags);
        [StructLayout(LayoutKind.Sequential)] private struct AnimationInfo { public int Size; public int MinimizeAnimation; }

        public static void InitializeDpi()
        {
            try { if (!SetProcessDpiAwarenessContext(new IntPtr(-4))) SetProcessDPIAware(); }
            catch (EntryPointNotFoundException) { SetProcessDPIAware(); }
        }

        public static void CommitFile(string temporary, string destination)
        {
            // Same-directory rename; avoids ReplaceFile's ACL-merge permission requirement.
            if (!MoveFileEx(temporary, destination, 0x1 | 0x8))
                throw new System.IO.IOException("Could not commit the file.");
        }

        public static bool MotionAllowed
        {
            get
            {
                int clientAnimation;
                bool client = !SystemParametersInfo(0x1042, 0, out clientAnimation, 0) || clientAnimation != 0;
                AnimationInfo info = new AnimationInfo { Size = 8 };
                bool window = !GetAnimationInfo(0x48, 8, ref info, 0) || info.MinimizeAnimation != 0;
                return client && window && !System.Windows.Forms.SystemInformation.HighContrast;
            }
        }

        public static void StyleWindow(IntPtr handle, bool dark)
        {
            // Windows 11 rounded corners; older Windows simply ignores unsupported attributes.
            try
            {
                int rounded = 2, useDark = dark ? 1 : 0;
                DwmSetWindowAttribute(handle, 33, ref rounded, 4);
                DwmSetWindowAttribute(handle, 20, ref useDark, 4);
            }
            catch (DllNotFoundException) { }
        }
    }

    internal sealed class ProcessJob : IDisposable
    {
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern IntPtr CreateJobObject(IntPtr attributes, string name);
        [DllImport("kernel32.dll")] private static extern bool SetInformationJobObject(IntPtr job, int type, ref ExtendedLimit information, uint size);
        [DllImport("kernel32.dll")] private static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);
        [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr handle);
        [StructLayout(LayoutKind.Sequential)] private struct BasicLimit
        {
            public long ProcessTime, JobTime; public uint Flags; public UIntPtr MinWorking, MaxWorking;
            public uint ActiveProcesses; public UIntPtr Affinity; public uint Priority, Scheduling;
        }
        [StructLayout(LayoutKind.Sequential)] private struct IoCounters
        { public ulong ReadOps, WriteOps, OtherOps, ReadBytes, WriteBytes, OtherBytes; }
        [StructLayout(LayoutKind.Sequential)] private struct ExtendedLimit
        {
            public BasicLimit Basic; public IoCounters Io;
            public UIntPtr ProcessMemory, JobMemory, PeakProcessMemory, PeakJobMemory;
        }
        private IntPtr handle;
        public bool Assigned { get; private set; }

        public ProcessJob(Process process)
        {
            handle = CreateJobObject(IntPtr.Zero, null);
            if (handle == IntPtr.Zero) return;
            ExtendedLimit limit = new ExtendedLimit();
            limit.Basic.Flags = 0x2000; // JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            if (SetInformationJobObject(handle, 9, ref limit, (uint)Marshal.SizeOf(limit)))
                Assigned = AssignProcessToJobObject(handle, process.Handle);
            if (!Assigned) Dispose();
        }

        public void Dispose()
        {
            if (handle == IntPtr.Zero) return;
            CloseHandle(handle);
            handle = IntPtr.Zero;
        }
    }
}
