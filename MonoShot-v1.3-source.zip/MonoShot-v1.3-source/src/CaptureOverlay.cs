using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace MonoShot
{
    internal sealed class CaptureOverlay : Form
    {
        private readonly Bitmap screen; // borrowed; the capture workflow owns it
        private readonly SolidBrush shade = new SolidBrush(Color.FromArgb(145, 0, 0, 0));
        private readonly Pen border = new Pen(Color.White, 1);
        private readonly Font hintFont;
        private readonly SolidBrush textInk = new SolidBrush(Color.White), hintBackground = new SolidBrush(Color.Black);
        private readonly Region dirty = new Region();
        private readonly bool english;
        private Point start, end;
        private bool drawing;
        private Bitmap result;

        public CaptureOverlay(Bitmap snapshot, Rectangle desktop, bool en)
        {
            screen = snapshot; english = en;
            hintFont = new Font(SystemFonts.MessageBoxFont.FontFamily, 10F);
            AutoScaleMode = AutoScaleMode.None; FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual; Bounds = desktop;
            TopMost = true; ShowInTaskbar = false; DoubleBuffered = true; KeyPreview = true;
            Cursor = Cursors.Cross; Text = "MonoShot Capture";
            dirty.MakeEmpty();
        }

        public Bitmap TakeResult() { Bitmap captured = result; result = null; return captured; }
        private Rectangle Selected { get { return Pictures.Selection(start, end, screen.Size); } }
        private static Rectangle Hint(Rectangle rectangle) { return new Rectangle(rectangle.Left, Math.Max(54, rectangle.Top - 29), 200, 28); }

        private void UnionBorder(Rectangle rectangle)
        {
            dirty.Union(new Rectangle(rectangle.Left - 2, rectangle.Top - 2, rectangle.Width + 4, 5));
            dirty.Union(new Rectangle(rectangle.Left - 2, rectangle.Bottom - 2, rectangle.Width + 4, 5));
            dirty.Union(new Rectangle(rectangle.Left - 2, rectangle.Top - 2, 5, rectangle.Height + 4));
            dirty.Union(new Rectangle(rectangle.Right - 2, rectangle.Top - 2, 5, rectangle.Height + 4));
        }
        private void RepaintSelection(Rectangle previous, Rectangle next)
        {
            dirty.MakeEmpty(); dirty.Union(previous); dirty.Xor(next);
            UnionBorder(previous); UnionBorder(next); dirty.Union(Hint(previous)); dirty.Union(Hint(next));
            Invalidate(dirty, false);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.DrawImage(screen, e.ClipRectangle, e.ClipRectangle, GraphicsUnit.Pixel);
            e.Graphics.FillRectangle(shade, e.ClipRectangle);
            Rectangle selected = Selected;
            if (drawing && selected.Width > 0 && selected.Height > 0)
            {
                e.Graphics.DrawImage(screen, selected, selected, GraphicsUnit.Pixel);
                e.Graphics.DrawRectangle(border, selected.Left, selected.Top, Math.Max(0, selected.Width - 1), Math.Max(0, selected.Height - 1));
                Rectangle hint = Hint(selected); e.Graphics.FillRectangle(hintBackground, hint);
                e.Graphics.DrawString(selected.Width + " × " + selected.Height + " px", hintFont, textInk, hint);
            }
            string instruction = Strings.Get(english ? "en" : "zh", "CaptureHint");
            e.Graphics.FillRectangle(hintBackground, new Rectangle(20, 20, 400, 29));
            e.Graphics.DrawString(instruction, hintFont, textInk, new PointF(24, 24));
        }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right) { DialogResult = DialogResult.Cancel; return; }
            if (e.Button != MouseButtons.Left) return;
            Rectangle previous = Selected; start = end = e.Location; drawing = true; Capture = true;
            RepaintSelection(previous, Selected);
        }
        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (!drawing || end == e.Location) return;
            Rectangle previous = Selected; end = e.Location; RepaintSelection(previous, Selected);
        }
        protected override void OnMouseUp(MouseEventArgs e)
        {
            if (!drawing || e.Button != MouseButtons.Left) return;
            end = e.Location; Rectangle selected = Selected;
            if (selected.Width < 2 || selected.Height < 2) { drawing = false; Capture = false; Invalidate(); return; }
            result = screen.Clone(selected, PixelFormat.Format32bppArgb);
            drawing = false; Capture = false; DialogResult = DialogResult.OK;
        }
        protected override void OnKeyDown(KeyEventArgs e) { if (e.KeyCode == Keys.Escape) { e.Handled = true; DialogResult = DialogResult.Cancel; } base.OnKeyDown(e); }
        protected override void OnDeactivate(EventArgs e) { if (Visible) DialogResult = DialogResult.Cancel; base.OnDeactivate(e); }
        protected override void WndProc(ref Message message)
        {
            // A virtual-desktop overlay is sized in physical pixels, not one monitor's suggested DPI rect.
            if (message.Msg == 0x02E0) return;
            base.WndProc(ref message);
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing) { if (result != null) result.Dispose(); hintFont.Dispose(); border.Dispose(); shade.Dispose(); dirty.Dispose(); textInk.Dispose(); hintBackground.Dispose(); }
            base.Dispose(disposing);
        }
    }
}
