using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace MonoShot
{
    internal enum WorkspaceAction { None = -1, Region, Screen, Open, Copy, Paste, Export, Analyze, Cancel, CopyResult, SaveResult, Browse, SaveConnection, Login, OpenAnalysisWorkspace, CloseAnalysisPanel }

    internal abstract class WorkspacePage : UserControl
    {
        protected readonly WorkspaceState State;
        protected readonly UiTheme Theme;
        protected readonly MotionHub Motion;
        protected readonly Dictionary<string, MonoButton> Buttons = new Dictionary<string, MonoButton>();
        private readonly Dictionary<Control, string> textBindings = new Dictionary<Control, string>();
        private Control lastFocus;
        private int selectionStart, selectionLength;
        protected bool Binding;
        public event Action<WorkspaceAction> ActionRequested;
        protected WorkspacePage(WorkspaceState state, UiTheme theme, MotionHub motion)
        { State = state; Theme = theme; Motion = motion; Dock = DockStyle.Fill; Margin = Padding.Empty; DoubleBuffered = true; TabStop = false; }
        protected string T(string key, params object[] args) { return Strings.Get(State.Language, key, args); }
        protected void ActivateBindings()
        { State.Changed += Changed; Theme.Changed += ThemeChanged; TrackFocus(this); RefreshLanguage(); RefreshState(StateChange.All); ApplyTheme(); }
        private void TrackFocus(Control parent)
        {
            foreach (Control child in parent.Controls) { Control target = child; child.Enter += (s, e) => { if (target.CanSelect) lastFocus = target; }; TrackFocus(child); }
        }
        public void RememberFocus() { TextBoxBase text = lastFocus as TextBoxBase; if (text != null) { selectionStart = text.SelectionStart; selectionLength = text.SelectionLength; } }
        public void RestoreFocus()
        {
            if (lastFocus == null || lastFocus.IsDisposed || !lastFocus.CanSelect) { SelectNextControl(null, true, true, true, false); return; }
            lastFocus.Focus(); TextBoxBase text = lastFocus as TextBoxBase;
            if (text != null) text.Select(Math.Min(selectionStart, text.TextLength), Math.Min(selectionLength, Math.Max(0, text.TextLength - selectionStart)));
        }
        private void Changed(object sender, StateChangedEventArgs e) { if ((e.Changes & StateChange.Language) != 0) RefreshLanguage(); RefreshState(e.Changes); }
        private void ThemeChanged(object sender, EventArgs e) { ApplyTheme(); }
        protected virtual void ApplyTheme() { BackColor = Theme.Colors.Background; ApplyChildColors(this); }
        private void ApplyChildColors(Control parent)
        {
            foreach (Control child in parent.Controls)
            {
                Label label = child as Label; if (label != null) label.ForeColor = label.Tag as string == "muted" ? Theme.Colors.Muted : Theme.Colors.Text;
                if (child is TableLayoutPanel || child is FlowLayoutPanel) child.BackColor = parent.BackColor;
                ApplyChildColors(child);
            }
        }
        protected virtual void RefreshLanguage() { foreach (KeyValuePair<Control, string> binding in textBindings) binding.Key.Text = T(binding.Value); }
        protected abstract void RefreshState(StateChange changes);
        protected Label Label(string key, bool muted)
        {
            Label label = new Label { Dock = DockStyle.Fill, Font = Theme.Body, UseMnemonic = false, Margin = Padding.Empty, TextAlign = ContentAlignment.MiddleLeft, Tag = muted ? "muted" : "text" };
            if (key != null) textBindings.Add(label, key); return label;
        }
        protected FlowLayoutPanel Toolbar() { return new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true, Margin = new Padding(0, 0, 0, Design.ToolbarGap) }; }
        protected MonoButton Button(string key, WorkspaceAction action, Control parent, bool primary)
        {
            MonoButton button = new MonoButton(Theme, Motion) { Name = key, Primary = primary, Width = Design.ButtonWidth(key), Margin = new Padding(0, 0, Design.Gap, Design.Gap) };
            textBindings.Add(button, key); Buttons.Add(key, button); parent.Controls.Add(button);
            button.Click += (s, e) => { Action<WorkspaceAction> handler = ActionRequested; if (handler != null) handler(action); }; return button;
        }
        private sealed class BufferedLayout : TableLayoutPanel { public BufferedLayout() { DoubleBuffered = true; } }
        protected TableLayoutPanel Table(int columns, int rows) { return new BufferedLayout { Dock = DockStyle.Fill, ColumnCount = columns, RowCount = rows, Margin = Padding.Empty }; }
        protected SurfacePanel Surface() { return new SurfacePanel(Theme, Motion) { Dock = DockStyle.Fill, Padding = new Padding(Design.SurfacePadding) }; }
        internal MonoButton FindButton(string key) { return Buttons[key]; }
        public virtual void SetImageBusy(bool busy) { }
        protected override void Dispose(bool disposing) { if (disposing) { State.Changed -= Changed; Theme.Changed -= ThemeChanged; ActionRequested = null; } base.Dispose(disposing); }
    }

    internal sealed class CapturePage : WorkspacePage
    {
        internal readonly ImageCanvas Preview;
        internal readonly Panel SideHost;
        private readonly Label metadata, filename, zoom;
        private readonly TableLayoutPanel workspace;
        private readonly Panel sideClip;
        private double sidebarProgress;
        private bool sidebarTarget, sidebarAnimating;
        internal event EventHandler SidebarHidden;
        internal double SidebarProgress { get { return sidebarProgress; } }
        internal bool SidebarAnimating { get { return sidebarAnimating; } }
        private sealed class ClipPanel : Panel { public ClipPanel() { DoubleBuffered = true; } }
        internal string ZoomText { get { return zoom.Text; } }
        private bool imageBusy;
        public CapturePage(WorkspaceState state, UiTheme theme, MotionHub motion) : base(state, theme, motion)
        {
            Name = "capturePage"; TableLayoutPanel root = Table(1, 2); Controls.Add(root);
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize)); root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            TableLayoutPanel tools = Table(3, 1); tools.AutoSize = true;
            tools.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize)); tools.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); tools.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            root.Controls.Add(tools, 0, 0); FlowLayoutPanel imports = Toolbar(), exports = Toolbar(); tools.Controls.Add(imports, 0, 0); tools.Controls.Add(exports, 2, 0);
            imports.WrapContents = exports.WrapContents = false; imports.Dock = exports.Dock = DockStyle.None;
            imports.AutoSizeMode = exports.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            Button("region", WorkspaceAction.Region, imports, true); Button("screen", WorkspaceAction.Screen, imports, false);
            Button("open", WorkspaceAction.Open, imports, false); Button("paste", WorkspaceAction.Paste, imports, false);
            Button("copy", WorkspaceAction.Copy, exports, false); Button("export", WorkspaceAction.Export, exports, false);
            workspace = Table(3, 1); workspace.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            workspace.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 0)); workspace.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 0)); root.Controls.Add(workspace, 0, 1);
            SurfacePanel content = Surface(); content.Padding = Padding.Empty; content.DrawBorder = true; workspace.Controls.Add(content, 0, 0);
            sideClip = new ClipPanel { Dock = DockStyle.Fill, Margin = Padding.Empty, Visible = false, Name = "analysisSideClip" }; workspace.Controls.Add(sideClip, 2, 0);
            SideHost = new Panel { Margin = Padding.Empty, Name = "analysisSideHost", Width = Design.SidePanelWidth }; sideClip.Controls.Add(SideHost);
            sideClip.SizeChanged += (s, e) => LayoutSideContent();
            TableLayoutPanel image = Table(1, 3); image.Padding = new Padding(1); content.Controls.Add(image);
            image.RowStyles.Add(new RowStyle(SizeType.Absolute, Design.ButtonHeight)); image.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); image.RowStyles.Add(new RowStyle(SizeType.Absolute, Design.ZoomBarHeight));
            TableLayoutPanel information = Table(2, 1); information.Padding = new Padding(Design.Gap, 0, Design.Gap, 0);
            information.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60)); information.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40)); image.Controls.Add(information, 0, 0);
            filename = Label(null, false); filename.AutoEllipsis = true; information.Controls.Add(filename, 0, 0);
            metadata = Label(null, true); metadata.TextAlign = ContentAlignment.MiddleRight; information.Controls.Add(metadata, 1, 0);
            Preview = new ImageCanvas(theme, motion, state) { Dock = DockStyle.Fill, Name = "capturePreview" }; image.Controls.Add(Preview, 0, 1);
            TableLayoutPanel zoomArea = Table(1, 1); image.Controls.Add(zoomArea, 0, 2);
            FlowLayoutPanel zoomTools = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Anchor = AnchorStyles.None, Margin = Padding.Empty }; zoomArea.Controls.Add(zoomTools, 0, 0);
            Button("zoomout", WorkspaceAction.None, zoomTools, false).Click += (s, e) => State.SetZoom(Preview.ActualScale / Design.ZoomStep);
            zoom = Label(null, true); zoom.Dock = DockStyle.None; zoom.Size = new Size(90, Design.ButtonHeight); zoom.TextAlign = ContentAlignment.MiddleCenter; zoomTools.Controls.Add(zoom);
            Button("zoomin", WorkspaceAction.None, zoomTools, false).Click += (s, e) => State.SetZoom(Preview.ActualScale * Design.ZoomStep);
            Button("actual", WorkspaceAction.None, zoomTools, false).Click += (s, e) => State.SetZoom(1);
            Button("fit", WorkspaceAction.None, zoomTools, false).Click += (s, e) => State.FitPreview();
            Preview.ScaleChanged += (s, e) => RefreshZoom(); ActivateBindings();
        }
        protected override void RefreshState(StateChange changes)
        {
            bool picture = State.Image != null;
            foreach (string key in new[] { "region", "screen", "open", "paste" }) Buttons[key].Enabled = !imageBusy && !State.IsClosing;
            Buttons["copy"].Enabled = picture && !State.IsClosing; Buttons["export"].Enabled = picture && !imageBusy && !State.IsClosing;
            filename.Text = picture ? State.ImageName ?? T(State.ImageSource == "open" ? "OpenedImage" : State.ImageSource == "paste" ? "ClipboardImage" : "CaptureName", State.ImageVersion) : T("NoImage");
            metadata.Text = picture ? State.Image.Width + " × " + State.Image.Height + " px" : "";
            RefreshZoom();
        }
        private void RefreshZoom()
        {
            if (zoom == null) return;
            zoom.Text = State.Image == null ? "—" : (State.FitImage ? T("FitShort") + " · " : "") + (Preview.ActualScale * 100).ToString("0.#") + "%";
            foreach (string key in new[] { "zoomout", "zoomin", "actual", "fit" }) Buttons[key].Enabled = State.Image != null && !State.IsClosing;
            Buttons["zoomout"].Enabled &= Preview.ActualScale > Design.MinimumZoom;
            Buttons["zoomin"].Enabled &= Preview.ActualScale < Design.MaximumZoom;
            Buttons["zoomout"].AccessibleName = T("ZoomOut"); Buttons["zoomin"].AccessibleName = T("ZoomIn");
            Buttons["fit"].Selected = State.FitImage; Buttons["actual"].Selected = !State.FitImage && Math.Abs(State.Zoom - 1) < .0001;
        }
        private void LayoutSideContent()
        {
            SideHost.SetBounds(0, 0, Design.Px(this, Design.SidePanelWidth), sideClip.ClientSize.Height);
        }
        private void ApplySidebarFrame(double progress)
        {
            sidebarProgress = progress; int width = (int)Math.Round(Design.Px(this, Design.SidePanelWidth) * progress);
            int gap = (int)Math.Round(Design.Px(this, Design.Gutter) * progress);
            bool visible = progress > 0 || sidebarTarget;
            if (workspace.ColumnStyles[2].Width != width || workspace.ColumnStyles[1].Width != gap || sideClip.Visible != visible)
            {
                workspace.SuspendLayout(); sideClip.Visible = visible; workspace.ColumnStyles[1].Width = gap; workspace.ColumnStyles[2].Width = width; workspace.ResumeLayout(true);
            }
            LayoutSideContent();
        }
        internal void SetSidebarVisible(bool visible, bool animate = true)
        {
            if (sidebarTarget == visible && !sidebarAnimating && Math.Abs(sidebarProgress - (visible ? 1 : 0)) < .0001) { ApplySidebarFrame(sidebarProgress); return; }
            sidebarTarget = visible; SideHost.Enabled = visible; LayoutSideContent(); sidebarAnimating = animate;
            int duration = animate ? Math.Max(Design.PanelMinMs, (int)Math.Round(Design.PanelMs * Math.Abs((visible ? 1 : 0) - sidebarProgress))) : 0;
            Motion.Animate(this, "analysis-panel", sidebarProgress, visible ? 1 : 0, duration, Ease.OutCubic,
                value => { if (!IsDisposed) ApplySidebarFrame(value); }, () => {
                    sidebarAnimating = false;
                    if (!sidebarTarget) { EventHandler handler = SidebarHidden; if (handler != null) handler(this, EventArgs.Empty); }
                });
        }
        protected override void OnDpiChangedAfterParent(EventArgs e) { base.OnDpiChangedAfterParent(e); if (workspace != null) SetSidebarVisible(sidebarTarget, false); }
        protected override void Dispose(bool disposing) { if (disposing) { Motion.Cancel(this, "analysis-panel"); SidebarHidden = null; } base.Dispose(disposing); }
        public override void SetImageBusy(bool busy) { imageBusy = busy; RefreshState(StateChange.Image); }
    }

    internal sealed class AnalysisPage : WorkspacePage
    {
        internal readonly ImageCanvas Thumbnail;
        internal readonly InputSurface PromptEditor, ResultEditor;
        internal readonly ThemeChoice Presets;
        private readonly Label imageInfo, jobInfo, resultInfo;
        private readonly TableLayoutPanel input, columns, root, output;
        private readonly SurfacePanel left, right;
        private readonly Control sideHeader;
        private bool sidebar;
        public AnalysisPage(WorkspaceState state, UiTheme theme, MotionHub motion) : base(state, theme, motion)
        {
            Name = "analysisPage"; root = Table(1, 3); Controls.Add(root);
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 0)); root.RowStyles.Add(new RowStyle(SizeType.AutoSize)); root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            TableLayoutPanel heading = Table(3, 1); heading.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            heading.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Design.AnalysisExpandWidth)); heading.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Design.ButtonHeight));
            heading.Controls.Add(Label("AnalyzeCurrent", false), 0, 0);
            Button("fullview", WorkspaceAction.OpenAnalysisWorkspace, heading, false); heading.SetCellPosition(Buttons["fullview"], new TableLayoutPanelCellPosition(1, 0));
            Button("sideclose", WorkspaceAction.CloseAnalysisPanel, heading, false); heading.SetCellPosition(Buttons["sideclose"], new TableLayoutPanelCellPosition(2, 0));
            Buttons["fullview"].Dock = DockStyle.Fill; Buttons["fullview"].Margin = new Padding(0, 0, Design.Gap, 0);
            Buttons["sideclose"].Dock = DockStyle.Fill; Buttons["sideclose"].Margin = Padding.Empty;
            sideHeader = heading; sideHeader.Visible = false; root.Controls.Add(sideHeader, 0, 0);
            FlowLayoutPanel tools = Toolbar(); root.Controls.Add(tools, 0, 1);
            Button("analyze", WorkspaceAction.Analyze, tools, true); Button("cancel", WorkspaceAction.Cancel, tools, false);
            Button("copytext", WorkspaceAction.CopyResult, tools, false); Button("savetext", WorkspaceAction.SaveResult, tools, false);
            columns = Table(3, 1); columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, Design.AnalysisInputPercent)); columns.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Design.Gutter)); columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100 - Design.AnalysisInputPercent)); root.Controls.Add(columns, 0, 2);
            left = Surface(); right = Surface(); columns.Controls.Add(left, 0, 0); columns.Controls.Add(right, 2, 0);
            input = Table(1, 7); left.Controls.Add(input);
            foreach (int height in new[] { Design.ThumbnailHeight, Design.MetadataHeight, Design.ButtonHeight + Design.Gap, Design.PromptChoiceHeight, Design.LabelHeight, 0, Design.TaskHeight / 2 })
                input.RowStyles.Add(new RowStyle(height == 0 ? SizeType.Percent : SizeType.Absolute, height == 0 ? 100 : height));
            Thumbnail = new ImageCanvas(theme, motion, state) { Compact = true, Dock = DockStyle.Fill, Name = "analysisThumbnail" }; input.Controls.Add(Thumbnail, 0, 0);
            imageInfo = Label(null, true); input.Controls.Add(imageInfo, 0, 1);
            FlowLayoutPanel quick = Toolbar(); quick.WrapContents = false; quick.Margin = Padding.Empty; input.Controls.Add(quick, 0, 2);
            Button("quickocr", WorkspaceAction.None, quick, false).Click += (s, e) => State.SelectPreset("ocr");
            Button("quicksummary", WorkspaceAction.None, quick, false).Click += (s, e) => State.SelectPreset("summary");
            Presets = new ThemeChoice(theme) { Name = "presets" }; input.Controls.Add(Presets, 0, 3);
            input.Controls.Add(Label("Prompt", false), 0, 4);
            PromptEditor = new InputSurface(theme, motion, true) { Dock = DockStyle.Fill, Name = "promptEditor" }; PromptEditor.Editor.AccessibleName = "Prompt"; input.Controls.Add(PromptEditor, 0, 5);
            input.Controls.Add(Label("SendNote", true), 0, 6);
            output = Table(1, 3); right.Controls.Add(output);
            output.RowStyles.Add(new RowStyle(SizeType.Absolute, Design.TaskHeight)); output.RowStyles.Add(new RowStyle(SizeType.Absolute, Design.LabelHeight * 2)); output.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            jobInfo = Label(null, true); output.Controls.Add(jobInfo, 0, 0); resultInfo = Label(null, false); output.Controls.Add(resultInfo, 0, 1);
            ResultEditor = new InputSurface(theme, motion, true) { Dock = DockStyle.Fill, Name = "resultEditor" }; ResultEditor.Editor.ReadOnly = true; ResultEditor.Editor.AccessibleName = "Codex result"; output.Controls.Add(ResultEditor, 0, 2);
            PromptEditor.Editor.TextChanged += (s, e) => { if (!Binding) State.EditPrompt(PromptEditor.Editor.Text); };
            Presets.SelectedIndexChanged += (s, e) => { if (!Binding && Presets.SelectedIndex >= 0) State.SelectPreset(PromptCatalog.Items[Presets.SelectedIndex].Id); };
            ActivateBindings();
        }
        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            if (input != null) input.RowStyles[0].Height = sidebar ? 0 : Design.Px(this, Height < Design.Px(this, Design.MinimumPageHeight) ? Design.CompactThumbnailHeight : Design.ThumbnailHeight);
            if (sidebar && root != null) root.Height = Math.Max(ClientSize.Height, Design.Px(this, Design.SidebarMinimumHeight));
        }
        internal void SetSidebar(bool value)
        {
            if (sidebar == value) return; sidebar = value; columns.SuspendLayout();
            AutoScroll = value; AutoScrollPosition = Point.Empty; root.Dock = value ? DockStyle.Top : DockStyle.Fill;
            if (value) root.Height = Math.Max(ClientSize.Height, Design.Px(this, Design.SidebarMinimumHeight));
            columns.Controls.Remove(left); columns.Controls.Remove(right); columns.ColumnStyles.Clear(); columns.RowStyles.Clear();
            columns.ColumnCount = value ? 1 : 3; columns.RowCount = value ? 2 : 1;
            if (value)
            {
                columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
                columns.RowStyles.Add(new RowStyle(SizeType.Absolute, Design.Px(this, Design.SideInputHeight))); columns.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
                columns.Controls.Add(left, 0, 0); columns.Controls.Add(right, 0, 1);
            }
            else
            {
                columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, Design.AnalysisInputPercent)); columns.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Design.Px(this, Design.Gutter))); columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100 - Design.AnalysisInputPercent));
                columns.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); columns.Controls.Add(left, 0, 0); columns.Controls.Add(right, 2, 0);
            }
            Thumbnail.Visible = !value; sideHeader.Visible = value; root.RowStyles[0].Height = value ? Design.Px(this, Design.ButtonHeight + Design.Gap) : 0;
            input.RowStyles[0].Height = value ? 0 : Design.Px(this, Design.ThumbnailHeight);
            input.RowStyles[6].Height = value ? 0 : Design.Px(this, Design.TaskHeight / 2);
            output.RowStyles[0].Height = Design.Px(this, value ? Design.MetadataHeight * 2 : Design.TaskHeight);
            output.RowStyles[1].Height = Design.Px(this, value ? Design.LabelHeight : Design.LabelHeight * 2);
            columns.ResumeLayout(true);
        }
        protected override void RefreshLanguage()
        {
            base.RefreshLanguage(); Binding = true;
            Presets.BeginUpdate(); Presets.Items.Clear(); foreach (PromptPreset preset in PromptCatalog.Items) Presets.Items.Add(T(preset.TitleKey));
            Presets.EndUpdate(); Presets.AccessibleName = T("Presets"); Binding = false;
        }
        protected override void RefreshState(StateChange changes)
        {
            Binding = true;
            if (PromptEditor.Editor.Text != State.Prompt) PromptEditor.Editor.Text = State.Prompt;
            for (int i = 0; i < PromptCatalog.Items.Length; i++) if (PromptCatalog.Items[i].Id == State.PresetId && Presets.SelectedIndex != i) Presets.SelectedIndex = i;
            string result = State.Result.Length == 0 ? T("ResultEmpty") : State.Result;
            if (ResultEditor.Editor.Text != result) ResultEditor.Editor.Text = result;
            Binding = false;
            imageInfo.Text = State.Image == null ? T("NoImage") : T("CurrentImage", State.ImageVersion, State.Image.Width, State.Image.Height);
            resultInfo.Text = State.Result.Length == 0 ? T("Result") : T("ResultVersion", State.ResultImageVersion, State.ImageVersion);
            WorkspaceJob job = State.AnalysisJob;
            jobInfo.Text = job == null ? T("Idle") : T(job.Phase.ToString()) + "\r\n" + T("JobImage", job.ImageVersion, job.ImageSize.Width, job.ImageSize.Height) +
                (job.ImageVersion != State.ImageVersion ? "\r\n" + T("ImageChanged", State.ImageVersion, job.ImageVersion) : "") +
                (String.IsNullOrEmpty(job.ErrorKey) ? "" : "\r\n" + T(job.ErrorKey));
            Buttons["analyze"].Enabled = State.Image != null && !State.IsWorking && !State.IsImageBusy && !State.IsClosing;
            Buttons["cancel"].Enabled = State.IsWorking && State.CurrentJob.Kind == JobKind.Analysis && !State.Cancellation.IsCancellationRequested;
            Buttons["copytext"].Enabled = Buttons["savetext"].Enabled = State.Result.Length > 0 && !State.IsClosing;
            Buttons["sideclose"].AccessibleName = T("HideAnalysis");
        }
    }

    internal sealed class PreferencesPage : WorkspacePage
    {
        internal readonly InputSurface Cli, Model, Auth;
        internal readonly ThemeChoice ThemeMode, Accent, Language;
        private readonly Label connection;
        private readonly TableLayoutPanel form;
        public PreferencesPage(WorkspaceState state, UiTheme theme, MotionHub motion) : base(state, theme, motion)
        {
            Name = "settingsPage"; AutoScroll = true;
            SurfacePanel surface = Surface(); surface.Dock = DockStyle.Top; surface.Height = Design.SettingsMinimumHeight; Controls.Add(surface);
            form = Table(1, 15); surface.Controls.Add(form);
            int[] heights = { Design.LabelHeight, Design.FieldHeight, Design.LabelHeight, Design.FieldHeight, 0, Design.LabelHeight * 2, Design.TaskHeight,
                Design.LabelHeight * 2, Design.PromptChoiceHeight + Design.Gap, Design.PromptChoiceHeight + Design.Gap, Design.PromptChoiceHeight + Design.Gap,
                Design.LabelHeight * 2, Design.LabelHeight, Design.TaskHeight, Design.TaskHeight / 2 };
            for (int i = 0; i < heights.Length; i++) form.RowStyles.Add(new RowStyle(i == 4 ? SizeType.AutoSize : SizeType.Absolute, heights[i]));
            form.Controls.Add(Label("CliLabel", false), 0, 0);
            Cli = new InputSurface(theme, motion, false) { Dock = DockStyle.Fill }; Cli.Editor.MaxLength = 32767; Cli.Editor.AccessibleName = "Codex executable"; form.Controls.Add(Cli, 0, 1);
            form.Controls.Add(Label("ModelLabel", false), 0, 2);
            Model = new InputSurface(theme, motion, false) { Dock = DockStyle.Fill }; Model.Editor.MaxLength = 160; Model.Editor.AccessibleName = "Codex model"; form.Controls.Add(Model, 0, 3);
            FlowLayoutPanel actions = Toolbar(); form.Controls.Add(actions, 0, 4);
            Button("browse", WorkspaceAction.Browse, actions, false); Button("save", WorkspaceAction.SaveConnection, actions, false);
            Button("login", WorkspaceAction.Login, actions, true); Button("cancel", WorkspaceAction.Cancel, actions, false);
            connection = Label(null, true); form.Controls.Add(connection, 0, 5);
            Auth = new InputSurface(theme, motion, true) { Dock = DockStyle.Fill }; Auth.Editor.ReadOnly = true; Auth.Editor.AccessibleName = "Temporary sign-in instructions"; form.Controls.Add(Auth, 0, 6);
            form.Controls.Add(Label("Appearance", false), 0, 7);
            ThemeMode = ChoiceRow("Theme", 8); Accent = ChoiceRow("Accent", 9); Language = ChoiceRow("Language", 10);
            form.Controls.Add(Label("Version", false), 0, 11);
            Label version = Label(null, false); version.Text = Product.Name; version.Font = theme.Section; form.Controls.Add(version, 0, 12);
            Label credits = Label(null, false); credits.Text = Product.Credits; form.Controls.Add(credits, 0, 13);
            form.Controls.Add(Label("PortableNote", true), 0, 14);
            Cli.Editor.TextChanged += (s, e) => { if (!Binding) State.EditConnection(Cli.Editor.Text, Model.Editor.Text); };
            Model.Editor.TextChanged += (s, e) => { if (!Binding) State.EditConnection(Cli.Editor.Text, Model.Editor.Text); };
            ThemeMode.SelectedIndexChanged += AppearanceChanged; Accent.SelectedIndexChanged += AppearanceChanged;
            Language.SelectedIndexChanged += (s, e) => { if (!Binding && Language.SelectedIndex >= 0) State.SetLanguage(Language.SelectedIndex == 1 ? "en" : "zh"); };
            ActivateBindings();
        }
        private ThemeChoice ChoiceRow(string key, int row)
        {
            TableLayoutPanel line = Table(2, 1); line.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, Design.SettingsLabelPercent)); line.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100 - Design.SettingsLabelPercent));
            line.Controls.Add(Label(key, false), 0, 0); ThemeChoice choice = new ThemeChoice(Theme) { Name = "choice" + key, AccessibleName = key }; line.Controls.Add(choice, 1, 0); form.Controls.Add(line, 0, row); return choice;
        }
        private void AppearanceChanged(object sender, EventArgs e)
        {
            if (!Binding && ThemeMode.SelectedIndex >= 0 && Accent.SelectedIndex >= 0)
                State.SetAppearance(new[] { "light", "dark", "system" }[ThemeMode.SelectedIndex], new[] { "ink", "blue", "green" }[Accent.SelectedIndex]);
        }
        protected override void RefreshLanguage()
        {
            base.RefreshLanguage(); Binding = true;
            ThemeMode.Items.Clear(); foreach (string key in new[] { "Light", "Dark", "System" }) ThemeMode.Items.Add(T(key));
            Accent.Items.Clear(); foreach (string key in new[] { "Ink", "Blue", "Green" }) Accent.Items.Add(T(key));
            Language.Items.Clear(); Language.Items.AddRange(new object[] { "简体中文", "English" }); Binding = false;
        }
        protected override void RefreshState(StateChange changes)
        {
            Binding = true;
            if (Cli.Editor.Text != State.CliDraft) Cli.Editor.Text = State.CliDraft;
            if (Model.Editor.Text != State.ModelDraft) Model.Editor.Text = State.ModelDraft;
            ThemeMode.SelectedIndex = State.ThemeMode == "system" ? 2 : State.ThemeMode == "dark" ? 1 : 0;
            Accent.SelectedIndex = State.Accent == "blue" ? 1 : State.Accent == "green" ? 2 : 0;
            Language.SelectedIndex = State.Language == "en" ? 1 : 0; Binding = false;
            bool login = State.IsWorking && State.CurrentJob.Kind == JobKind.Login;
            bool failed = State.CurrentJob != null && State.CurrentJob.Kind == JobKind.Login && (State.CurrentJob.Phase == JobPhase.Failed || State.CurrentJob.Phase == JobPhase.TimedOut);
            string text = login ? T(State.AuthReady ? "LoginNote" : "LoginWaiting") : T(State.Connection == ConnectionPhase.SignedIn ? "SignedIn" : State.Connection == ConnectionPhase.Missing ? "MissingCli" : State.Connection == ConnectionPhase.NeedsLogin ? "ErrorAuth" : "Configured");
            if (State.CurrentJob != null && State.CurrentJob.Kind == JobKind.Login && !State.IsWorking) text = T("LoginEnded") + " " + (State.CurrentJob.Phase == JobPhase.Completed ? T("SignedIn") : T(State.CurrentJob.ErrorKey ?? State.CurrentJob.Phase.ToString()));
            connection.Text = text;
            string instructions = login ? (State.AuthInstructions.Length == 0 ? T("LoginWaiting") : State.AuthInstructions) : failed ? T(State.CurrentJob.ErrorKey ?? "Failed") + Environment.NewLine + T("LoginTroubleshoot") : "";
            if (Auth.Editor.Text != instructions) Auth.Editor.Text = instructions;
            Auth.Visible = login || failed; form.RowStyles[6].Height = login || failed ? Design.Px(this, Design.TaskHeight * 2) : 0;
            Buttons["save"].Enabled = Buttons["browse"].Enabled = Buttons["login"].Enabled = !State.IsWorking && !State.IsClosing;
            Buttons["cancel"].Enabled = login && !State.Cancellation.IsCancellationRequested;
        }
    }
}
