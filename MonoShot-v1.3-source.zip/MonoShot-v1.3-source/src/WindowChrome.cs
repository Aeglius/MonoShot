using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MonoShot
{
    internal enum CaptionAction { Minimize, Maximize, Close }

    // Real focusable WinForms buttons keep keyboard/UIA behavior; their visuals are entirely GDI+.
    internal sealed class CaptionButton : Button
    {
        private readonly UiTheme theme;
        private readonly MotionHub motion;
        private readonly SolidBrush fill = new SolidBrush(Color.Black);
        private readonly Pen line = new Pen(Color.White);
        private double hover, press;
        internal readonly CaptionAction Action;
        internal bool Active = true, Restored;
        public CaptionButton(CaptionAction action, UiTheme theme, MotionHub motion)
        {
            Action = action; this.theme = theme; this.motion = motion;
            FlatStyle = FlatStyle.Flat; FlatAppearance.BorderSize = 0; AccessibleRole = AccessibleRole.PushButton;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            theme.Changed += Changed;
        }
        private void Changed(object sender, EventArgs e) { Invalidate(); }
        internal void Feedback(bool over, bool down)
        {
            motion.Animate(this, "chrome-hover", hover, over ? 1 : 0, Design.HoverMs, Ease.OutCubic, v => { hover = v; Invalidate(); }, null);
            motion.Animate(this, "chrome-press", press, down ? 1 : 0, Design.PressMs, Ease.OutCubic, v => { press = v; Invalidate(); }, null);
        }
        protected override void OnMouseEnter(EventArgs e) { Feedback(true, false); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { Feedback(false, false); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { if (e.Button == MouseButtons.Left) Feedback(true, true); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { Feedback(ClientRectangle.Contains(e.Location), false); base.OnMouseUp(e); }
        protected override void OnKeyDown(KeyEventArgs e) { if (e.KeyCode == Keys.Space || e.KeyCode == Keys.Enter) Feedback(true, true); base.OnKeyDown(e); }
        protected override void OnKeyUp(KeyEventArgs e) { Feedback(Focused, false); base.OnKeyUp(e); }
        protected override void OnLostFocus(EventArgs e) { Feedback(false, false); base.OnLostFocus(e); }
        protected override void OnPaintBackground(PaintEventArgs e) { }
        protected override void OnPaint(PaintEventArgs e)
        {
            Palette p = theme.Colors; Color background = Design.Mix(p.Chrome, Action == CaptionAction.Close ? p.CloseHover : p.Hover, hover);
            background = Design.Mix(background, Action == CaptionAction.Close ? p.ClosePressed : p.Pressed, press);
            fill.Color = background; e.Graphics.FillRectangle(fill, ClientRectangle);
            Color foreground = Active ? p.Text : p.Muted;
            if (Action == CaptionAction.Close) foreground = Design.Mix(foreground, p.CloseText, Math.Max(hover, press));
            line.Color = Enabled ? foreground : p.Disabled; line.Width = Math.Max(1, DeviceDpi / 96F);
            int size = Design.Px(this, Design.CaptionIconSize), x = (Width - size) / 2, y = (Height - size) / 2;
            e.Graphics.SmoothingMode = SmoothingMode.None;
            if (Action == CaptionAction.Minimize) e.Graphics.DrawLine(line, x, y + size / 2, x + size, y + size / 2);
            else if (Action == CaptionAction.Close)
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.DrawLine(line, x, y, x + size, y + size); e.Graphics.DrawLine(line, x + size, y, x, y + size);
            }
            else if (!Restored) e.Graphics.DrawRectangle(line, x, y, size, size);
            else
            {
                int offset = Math.Max(2, Design.Px(this, 2));
                e.Graphics.DrawRectangle(line, x + offset, y, size - offset, size - offset);
                e.Graphics.FillRectangle(fill, x, y + offset, size - offset, size - offset);
                e.Graphics.DrawRectangle(line, x, y + offset, size - offset, size - offset);
            }
            if (Focused && ShowFocusCues) ControlPaint.DrawFocusRectangle(e.Graphics, Rectangle.Inflate(ClientRectangle, -4, -4), foreground, background);
        }
        protected override void WndProc(ref Message message)
        {
            // Route the custom maximize region to the top-level NC hit test for Windows 11 Snap.
            if (Action == CaptionAction.Maximize && message.Msg == Native.WmNcHitTest) { message.Result = new IntPtr(-1); return; }
            base.WndProc(ref message);
        }
        protected override void Dispose(bool disposing)
        { if (disposing) { theme.Changed -= Changed; motion.Cancel(this, null); fill.Dispose(); line.Dispose(); } base.Dispose(disposing); }
    }

    // Paints directly in the form's client title area: no child container intercepts HTCAPTION.
    internal sealed class CustomTitleBar : IDisposable
    {
        private readonly Form owner;
        private readonly UiTheme theme;
        private readonly WorkspaceState state;
        private readonly SolidBrush fill = new SolidBrush(Color.Black);
        private readonly Pen line = new Pen(Color.Gray);
        internal readonly CaptionButton Minimize, Maximize, Close;
        private bool active = true, capturedMax, disposed;
        public CustomTitleBar(Form owner, UiTheme theme, MotionHub motion, WorkspaceState state)
        {
            this.owner = owner; this.theme = theme; this.state = state;
            Minimize = new CaptionButton(CaptionAction.Minimize, theme, motion) { Name = "windowMinimize", TabIndex = 90 };
            Maximize = new CaptionButton(CaptionAction.Maximize, theme, motion) { Name = "windowMaximize", TabIndex = 91 };
            Close = new CaptionButton(CaptionAction.Close, theme, motion) { Name = "windowClose", TabIndex = 92 };
            owner.Controls.AddRange(new Control[] { Minimize, Maximize, Close });
            Minimize.Click += MinimizeClick; Maximize.Click += MaximizeClick; Close.Click += CloseClick;
            owner.Paint += Paint; owner.Resize += Resize; owner.Activated += Activate; owner.Deactivate += Deactivate;
            theme.Changed += Changed; state.Changed += StateChanged; Layout();
        }
        internal Rectangle TitleBounds { get { return new Rectangle(0, 0, owner.ClientSize.Width, Design.Px(owner, Design.TitleBarHeight)); } }
        internal int HitTest(Point point)
        {
            int edge = Native.ResizeHit(point, owner.ClientSize, Design.Px(owner, Design.ResizeBorder), owner.WindowState == FormWindowState.Maximized);
            if (edge != Native.HtClient) return edge;
            if (Maximize.Bounds.Contains(point)) return Native.HtMaxButton;
            if (Minimize.Bounds.Contains(point) || Close.Bounds.Contains(point)) return Native.HtClient;
            return TitleBounds.Contains(point) ? Native.HtCaption : Native.HtClient;
        }
        internal void Layout()
        {
            if (disposed) return;
            int width = Design.Px(owner, Design.CaptionButtonWidth), top = Design.Px(owner, Design.ResizeBorder), height = Design.Px(owner, Design.TitleBarHeight) - top;
            Close.SetBounds(owner.ClientSize.Width - width - 1, top, width, height);
            Maximize.SetBounds(Close.Left - width, top, width, height); Minimize.SetBounds(Maximize.Left - width, top, width, height);
            Maximize.Restored = owner.WindowState == FormWindowState.Maximized;
            Minimize.AccessibleName = Strings.Get(state.Language, "WindowMinimize");
            Maximize.AccessibleName = Strings.Get(state.Language, Maximize.Restored ? "WindowRestore" : "WindowMaximize");
            Close.AccessibleName = Strings.Get(state.Language, "WindowClose");
            Minimize.Active = Maximize.Active = Close.Active = active;
            Minimize.Invalidate(); Maximize.Invalidate(); Close.Invalidate(); owner.Invalidate(TitleBounds);
        }
        private void Resize(object sender, EventArgs e) { Layout(); }
        private void Changed(object sender, EventArgs e) { owner.Invalidate(TitleBounds); }
        private void StateChanged(object sender, StateChangedEventArgs e) { if ((e.Changes & StateChange.Language) != 0) Layout(); }
        private void Activate(object sender, EventArgs e) { active = true; Layout(); }
        private void Deactivate(object sender, EventArgs e) { active = false; Maximize.Feedback(false, false); Layout(); }
        private void MinimizeClick(object sender, EventArgs e) { Native.SendMessage(owner.Handle, Native.WmSysCommand, new IntPtr(0xF020), IntPtr.Zero); }
        private void MaximizeClick(object sender, EventArgs e) { ToggleMaximize(); }
        private void CloseClick(object sender, EventArgs e) { owner.Close(); }
        internal void ToggleMaximize() { Native.SendMessage(owner.Handle, Native.WmSysCommand, new IntPtr(owner.WindowState == FormWindowState.Maximized ? 0xF120 : 0xF030), IntPtr.Zero); }
        private void Paint(object sender, PaintEventArgs e)
        {
            Rectangle area = TitleBounds; Palette p = theme.Colors;
            fill.Color = p.Chrome; e.Graphics.FillRectangle(fill, area);
            line.Color = active ? p.Text : p.Muted; line.Width = Math.Max(1, owner.DeviceDpi / 96F);
            int x = Design.Px(owner, 22), y = Design.Px(owner, 18), s = Design.Px(owner, 12), corner = Design.Px(owner, 4);
            e.Graphics.DrawLine(line, x, y, x + corner, y); e.Graphics.DrawLine(line, x, y, x, y + corner);
            e.Graphics.DrawLine(line, x + s, y, x + s - corner, y); e.Graphics.DrawLine(line, x + s, y, x + s, y + corner);
            e.Graphics.DrawLine(line, x, y + s, x + corner, y + s); e.Graphics.DrawLine(line, x, y + s, x, y + s - corner);
            e.Graphics.DrawLine(line, x + s, y + s, x + s - corner, y + s); e.Graphics.DrawLine(line, x + s, y + s, x + s, y + s - corner);
            TextRenderer.DrawText(e.Graphics, state.Language == "en" ? "MonoShot / 墨截" : "墨截 / MonoShot", theme.Body,
                new Rectangle(Design.Px(owner, 46), 0, Math.Max(1, Minimize.Left - Design.Px(owner, 60)), area.Height), active ? p.Text : p.Muted,
                TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis);
            line.Color = p.Border; e.Graphics.DrawLine(line, 0, area.Bottom - 1, area.Right, area.Bottom - 1);
            e.Graphics.DrawRectangle(line, 0, 0, owner.ClientSize.Width - 1, owner.ClientSize.Height - 1);
        }
        internal bool HandleNonClient(ref Message message)
        {
            if (message.Msg == 0xA0)
            { Maximize.Feedback(message.WParam.ToInt32() == Native.HtMaxButton, false); Native.TrackNonClientLeave(owner.Handle); }
            if (message.Msg == 0x2A2) Maximize.Feedback(false, false);
            if (message.Msg == 0xA1 && message.WParam.ToInt32() == Native.HtMaxButton)
            { capturedMax = true; Native.SetCapture(owner.Handle); Maximize.Feedback(true, true); message.Result = IntPtr.Zero; return true; }
            if (capturedMax && message.Msg == 0x200)
                Maximize.Feedback(Maximize.Bounds.Contains(owner.PointToClient(Control.MousePosition)), true);
            if (capturedMax && (message.Msg == 0x202 || message.Msg == 0xA2))
            {
                bool inside = Maximize.Bounds.Contains(owner.PointToClient(Control.MousePosition)); capturedMax = false; Native.ReleaseCapture(); Maximize.Feedback(inside, false);
                if (inside) ToggleMaximize(); message.Result = IntPtr.Zero; return true;
            }
            if (message.Msg == 0x215 && capturedMax) { capturedMax = false; Maximize.Feedback(false, false); }
            if (message.Msg == 0xA5 && message.WParam.ToInt32() == Native.HtCaption)
            { Native.ShowSystemMenu(owner, Native.ScreenPoint(message.LParam)); message.Result = IntPtr.Zero; return true; }
            return false;
        }
        public void Dispose()
        {
            if (disposed) return; disposed = true;
            owner.Paint -= Paint; owner.Resize -= Resize; owner.Activated -= Activate; owner.Deactivate -= Deactivate;
            theme.Changed -= Changed; state.Changed -= StateChanged;
            Minimize.Click -= MinimizeClick; Maximize.Click -= MaximizeClick; Close.Click -= CloseClick;
            if (capturedMax) Native.ReleaseCapture(); fill.Dispose(); line.Dispose();
        }
    }
}
