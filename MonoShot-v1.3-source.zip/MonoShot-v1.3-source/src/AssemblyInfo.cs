﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("MonoShot · 墨截")]
[assembly: AssemblyDescription("Lightweight native screenshot and Codex companion")]
[assembly: AssemblyCompany("Aeglius")]
[assembly: AssemblyProduct("MonoShot")]
[assembly: AssemblyCopyright("Copyright © 2026 Aeglius")]
[assembly: AssemblyVersion("1.3.0.0")]
[assembly: AssemblyFileVersion("1.3.0.0")]
[assembly: AssemblyInformationalVersion("1.3+ea01.20261018")]
[assembly: ComVisible(false)]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
