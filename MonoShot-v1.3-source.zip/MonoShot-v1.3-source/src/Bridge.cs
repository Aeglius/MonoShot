﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace MonoShot
{
    internal enum CliFailure { Launch, Authentication, Network, Rejected, EmptyAnswer, Termination, UnsupportedCommand, PolicyUnsupported, PolicyViolation, PolicyContext }
    internal sealed class LoginStartTimeoutException : TimeoutException { }
    internal sealed class CliException : Exception
    {
        public CliFailure Kind { get; private set; }
        public CliException(CliFailure kind) : base("Codex operation could not complete.") { Kind = kind; }
    }

    internal static class Secrets
    {
        private static readonly Regex Ansi = new Regex(@"\x1B\[[0-?]*[ -/]*[@-~]", RegexOptions.Compiled);
        private static readonly Regex Credentials = new Regex(@"(?i)\b(sk-[A-Za-z0-9_-]{8,}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)|((?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|authorization|client[_ -]?secret)\s*[:=]\s*(?:Bearer\s+)?)[^\s,}]+", RegexOptions.Compiled);
        public static string ForDisplay(string text)
        {
            return Credentials.Replace(Ansi.Replace(text ?? "", ""), match =>
                match.Groups[2].Success ? match.Groups[2].Value + "[redacted]" : "[redacted]");
        }
        internal static bool HasDeviceInstructions(string text)
        {
            return Regex.IsMatch(text, Uri.UriSchemeHttps + @"://(?:auth\.openai\.com|chatgpt\.com)/[^\s]+", RegexOptions.IgnoreCase) &&
                Regex.IsMatch(text, @"\b[A-Z0-9]{4,6}-[A-Z0-9]{4,6}\b");
        }
    }

    internal static class Bridge
    {
        public static string Quote(string value)
        {
            StringBuilder result = new StringBuilder("\""); int slashes = 0;
            foreach (char character in value)
            {
                if (character == '\\') { slashes++; continue; }
                result.Append('\\', character == '"' ? slashes * 2 + 1 : slashes);
                result.Append(character); slashes = 0;
            }
            result.Append('\\', slashes * 2); return result.Append('"').ToString();
        }

        internal static ProcessStartInfo StartInfo(string executable, string arguments, string workingDirectory = null)
        {
            ProcessStartInfo info = new ProcessStartInfo(executable, arguments) {
                UseShellExecute = false, CreateNoWindow = true, WorkingDirectory = workingDirectory ?? Store.CodexHome,
                RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8
            };
            info.EnvironmentVariables["CODEX_HOME"] = Store.CodexHome;
            info.EnvironmentVariables["TEMP"] = Store.Temp; info.EnvironmentVariables["TMP"] = Store.Temp;
            info.EnvironmentVariables["NO_COLOR"] = "1";
            return info;
        }

        public static Task<string> Run(string executable, string arguments, string input,
            Action<string> progress, CancellationToken token, int seconds)
        { return Run(executable, arguments, input, progress, token, seconds, null, null, null); }

        private static Task<string> Run(string executable, string arguments, string input,
            Action<string> progress, CancellationToken token, int seconds, string workingDirectory, Action<string> observeOutput, Action<string> observeError)
        {
            // Spawn, stdin writes, and bounded native waits all remain off the UI thread.
            return Task.Run(async () =>
            {
                token.ThrowIfCancellationRequested();
                using (CancellationTokenSource deadline = CancellationTokenSource.CreateLinkedTokenSource(token))
                using (Process process = new Process())
                {
                    deadline.CancelAfter(TimeSpan.FromSeconds(seconds));
                    process.StartInfo = StartInfo(executable, arguments, workingDirectory);
                    StringBuilder output = new StringBuilder(); object gate = new object(); int displayed = 0; bool callbacksClosed = false; Exception observationFailure = null;
                    TaskCompletionSource<int> stdoutEnded = new TaskCompletionSource<int>(TaskCreationOptions.RunContinuationsAsynchronously);
                    TaskCompletionSource<int> stderrEnded = new TaskCompletionSource<int>(TaskCreationOptions.RunContinuationsAsynchronously);
                    DataReceivedEventHandler receive = (sender, e) =>
                    {
                        if (e.Data == null) return;
                        lock (gate)
                        {
                            if (callbacksClosed) return;
                            if (output.Length < 65536) output.AppendLine(e.Data.Substring(0, Math.Min(e.Data.Length, 4096)));
                            if (progress != null && displayed < 32768)
                            {
                                displayed += e.Data.Length;
                                progress(Secrets.ForDisplay(e.Data.Substring(0, Math.Min(e.Data.Length, 4096))));
                            }
                        }
                    };
                    Action<string, Action<string>> observe = (line, observer) => {
                        if (observer == null || line == null) return;
                        lock (gate)
                        {
                            if (callbacksClosed || observationFailure != null) return;
                            try { observer(line); }
                            catch (CliException error) { observationFailure = error; }
                        }
                    };
                    DataReceivedEventHandler stdout = (sender, e) => { if (e.Data == null) stdoutEnded.TrySetResult(0); else { observe(e.Data, observeOutput); receive(sender, e); } };
                    DataReceivedEventHandler stderr = (sender, e) => { if (e.Data == null) stderrEnded.TrySetResult(0); else { observe(e.Data, observeError); receive(sender, e); } };
                    process.OutputDataReceived += stdout; process.ErrorDataReceived += stderr;
                    try { process.Start(); }
                    catch (System.ComponentModel.Win32Exception) { throw new CliException(CliFailure.Launch); }
                    catch (InvalidOperationException) { throw new CliException(CliFailure.Launch); }
                    using (ProcessJob job = new ProcessJob(process))
                    {
                        Task write = null;
                        try
                        {
                            process.BeginOutputReadLine(); process.BeginErrorReadLine();
                            Task canceled = Task.Delay(Timeout.Infinite, deadline.Token);
                            write = Task.Run(() =>
                            {
                                try
                                {
                                    if (input != null)
                                    {
                                        byte[] bytes = new UTF8Encoding(false).GetBytes(input);
                                        process.StandardInput.BaseStream.Write(bytes, 0, bytes.Length);
                                        process.StandardInput.BaseStream.Flush();
                                    }
                                    process.StandardInput.Close();
                                }
                                catch (IOException) { if (!deadline.IsCancellationRequested && !HasExited(process)) throw new CliException(CliFailure.Rejected); }
                            });
                            if (await Task.WhenAny(write, canceled).ConfigureAwait(false) == canceled)
                                throw new OperationCanceledException();
                            await write.ConfigureAwait(false);
                            // Finite waits also avoid hanging on inherited stdout pipe handles.
                            while (!process.WaitForExit(40))
                            {
                                deadline.Token.ThrowIfCancellationRequested();
                                lock (gate) if (observationFailure != null) throw observationFailure;
                            }
                            job.Dispose();
                            // Process exit alone does not mean redirected callbacks have drained.
                            // Keep this bounded in case another process inherited a pipe handle.
                            Task drained = Task.WhenAll(stdoutEnded.Task, stderrEnded.Task);
                            await Task.WhenAny(drained, Task.Delay(500)).ConfigureAwait(false);
                            if (observeOutput != null && !drained.IsCompleted) throw new CliException(CliFailure.PolicyViolation);
                            deadline.Token.ThrowIfCancellationRequested();
                            string log; lock (gate) { if (observationFailure != null) throw observationFailure; log = output.ToString(); }
                            if (process.ExitCode != 0)
                            {
                                string lower = log.ToLowerInvariant();
                                throw new CliException(lower.Contains("unexpected argument") || lower.Contains("unrecognized") ? CliFailure.UnsupportedCommand :
                                    lower.Contains("network") || lower.Contains("connect") || lower.Contains("resolve") || lower.Contains("sending request") || lower.Contains("timed out") ? CliFailure.Network :
                                    lower.Contains("auth") || lower.Contains("401") || lower.Contains("log in") ? CliFailure.Authentication : CliFailure.Rejected);
                            }
                            return progress == null ? log : "";
                        }
                        catch (OperationCanceledException)
                        {
                            Terminate(process, job);
                            if (token.IsCancellationRequested) throw new OperationCanceledException(token);
                            throw new TimeoutException("Codex timed out.");
                        }
                        finally
                        {
                            // Serialize teardown with callbacks before their captured sources are disposed.
                            lock (gate) callbacksClosed = true;
                            deadline.Cancel();
                            if (!HasExited(process)) Terminate(process, job);
                            if (write != null)
                            {
                                // Observe failures even when cancellation won the race with stdin.
                                ObserveFailure(write);
                            }
                            process.OutputDataReceived -= stdout; process.ErrorDataReceived -= stderr;
                        }
                    }
                }
            });
        }

        private static void ObserveFailure(Task task)
        {
            task.ContinueWith(failed => { Exception ignored = failed.Exception; }, TaskContinuationOptions.OnlyOnFaulted);
        }

        private static bool HasExited(Process process)
        {
            try { return process.HasExited; } catch (InvalidOperationException) { return true; }
        }

        private static void Terminate(Process process, ProcessJob job)
        {
            bool contained = job.Assigned;
            job.Dispose();
            if (HasExited(process)) return;
            if (!contained)
            {
                try
                {
                    using (Process killer = Process.Start(new ProcessStartInfo("taskkill.exe", "/PID " + process.Id + " /T /F") {
                        UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true }))
                        killer.WaitForExit(500);
                }
                catch (System.ComponentModel.Win32Exception) { }
                catch (InvalidOperationException) { }
            }
            try { if (!HasExited(process)) process.Kill(); process.WaitForExit(1500); }
            catch (InvalidOperationException) { }
            catch (System.ComponentModel.Win32Exception) { }
        }

        public static async Task<string> Analyze(string cli, string image, string prompt, string model, CancellationToken token)
        {
            string directory = Path.Combine(Store.Temp, "analysis-" + Guid.NewGuid().ToString("N"));
            string output = Path.Combine(directory, "answer.md");
            AnalysisPolicy.VerifyHome(Store.CodexHome);
            Directory.CreateDirectory(directory);
            string result = null; Exception failure = null;
            // C# 5 cannot await in finally. Preserve the original exception across async cleanup.
            try { result = await AnalyzeCore(cli, image, prompt, model, token, directory, output).ConfigureAwait(false); }
            catch (Exception error) { failure = error; }
            Store.TryDelete(output);
            // Delete only our empty, uniquely owned directory; never recurse through CLI-created files.
            for (int attempt = 0; attempt < 4; attempt++)
            {
                try { Directory.Delete(directory); break; }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { break; }
                if (attempt < 3) await Task.Delay(50).ConfigureAwait(false);
            }
            if (failure != null) System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(failure).Throw();
            return result;
        }

        private static async Task<string> AnalyzeCore(string cli, string image, string prompt, string model,
            CancellationToken token, string directory, string output)
        {
            string version = await Run(cli, "--version", null, null, token, 10, directory, null, null).ConfigureAwait(false);
            AnalysisPolicy.VerifyVersion(version);
            AnalysisPolicy policy = new AnalysisPolicy();
            await Run(cli, AnalysisPolicy.Arguments(image, output, model), prompt, null, token, 180,
                directory, policy.OutputLine, policy.ErrorLine).ConfigureAwait(false);
            policy.Complete();
            return await Task.Run(() =>
            {
                token.ThrowIfCancellationRequested();
                if (!File.Exists(output) || new FileInfo(output).Length > 4 * 1024 * 1024) throw new CliException(CliFailure.EmptyAnswer);
                string answer = File.ReadAllText(output, Encoding.UTF8);
                if (String.IsNullOrWhiteSpace(answer)) throw new CliException(CliFailure.EmptyAnswer);
                return Secrets.ForDisplay(answer);
            }).ConfigureAwait(false);
        }
    }
}
