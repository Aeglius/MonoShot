using System;
using System.IO;
using System.Text;

namespace MonoShot
{
    internal static class Store
    {
        public static string Root { get; private set; }
        public static string Data { get { return Path.Combine(Root, "data"); } }
        public static string Temp { get { return Path.Combine(Root, ".cache", "tmp"); } }
        public static string Exports { get { return Path.Combine(Root, "exports"); } }
        public static string CodexHome { get { return Path.Combine(Data, "codex"); } }

        public static void Initialize(string root)
        {
            Root = Path.GetFullPath(root);
            foreach (string directory in new[] { Data, Temp, Exports, CodexHome })
                Directory.CreateDirectory(directory);
            // Some launchers supply both PATH and Path. Normalize only this process.
            string path = Environment.GetEnvironmentVariable("PATH");
            Environment.SetEnvironmentVariable("PATH", null);
            Environment.SetEnvironmentVariable("Path", null);
            Environment.SetEnvironmentVariable("Path", path);
            Environment.SetEnvironmentVariable("TEMP", Temp);
            Environment.SetEnvironmentVariable("TMP", Temp);
        }

        public static string Read(string key, string fallback)
        {
            try
            {
                string path = Path.Combine(Data, key + ".txt");
                if (!File.Exists(path) || new FileInfo(path).Length > 128 * 1024) return fallback;
                return File.ReadAllText(path, Encoding.UTF8).Trim();
            }
            catch (IOException) { return fallback; }
            catch (UnauthorizedAccessException) { return fallback; }
        }

        public static void Write(string key, string value)
        {
            string path = Path.Combine(Data, key + ".txt");
            string temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                File.WriteAllText(temporary, value, new UTF8Encoding(false));
                Native.CommitFile(temporary, path);
            }
            finally { TryDelete(temporary); }
        }

        public static void TryDelete(string path)
        {
            try { if (File.Exists(path)) File.Delete(path); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }

        public static string FindCli()
        {
            string saved = Read("cli", "");
            if (IsExecutable(saved)) return saved;
            string local = Path.Combine(Root, "tools", "codex.exe");
            if (File.Exists(local)) return local;
            string npm = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "npm", "node_modules", "@openai", "codex", "node_modules", "@openai", "codex-win32-x64",
                "vendor", "x86_64-pc-windows-msvc", "bin", "codex.exe");
            if (File.Exists(npm)) return npm;
            foreach (string directory in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(';'))
            {
                try
                {
                    string candidate = Path.Combine(directory.Trim('"'), "codex.exe");
                    if (File.Exists(candidate)) return candidate;
                }
                catch (ArgumentException) { }
                catch (NotSupportedException) { }
            }
            return "";
        }

        public static bool IsExecutable(string path)
        {
            return !String.IsNullOrWhiteSpace(path) && File.Exists(path) &&
                String.Equals(Path.GetExtension(path), ".exe", StringComparison.OrdinalIgnoreCase);
        }
    }
}
