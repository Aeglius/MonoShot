using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace MonoShot
{
    internal class SurfacePanel : Panel
    {
        protected readonly UiTheme Theme;
        protected readonly MotionHub Motion;
        protected GraphicsPath Shape;
        protected readonly SolidBrush Fill = new SolidBrush(Color.White);
        protected readonly Pen Outline = new Pen(Color.Black);
        private readonly SolidBrush outside = new SolidBrush(Color.White);
        protected double FocusAmount;
        public bool InputStyle { get; set; }
        public bool CanvasStyle { get; set; }
        public bool DrawBorder { get; set; }

        public SurfacePanel(UiTheme theme, MotionHub motion)
        {
            Theme = theme; Motion = motion; DoubleBuffered = true;
            SetStyle(ControlStyles.ResizeRedraw, true);
            Margin = Padding.Empty;
            Theme.Changed += ThemeChanged;
            UpdateColors();
        }

        protected virtual void UpdateColors()
        {
            Palette p = Theme.Colors;
            BackColor = CanvasStyle ? p.Canvas : InputStyle ? p.Input : p.Surface;
            ForeColor = p.Text;
            Invalidate();
        }
        private void ThemeChanged(object sender, EventArgs e) { UpdateColors(); }
        protected override void OnPaintBackground(PaintEventArgs e) { }
        protected override void OnSizeChanged(EventArgs e) { RebuildShape(); base.OnSizeChanged(e); }
        protected override void OnDpiChangedAfterParent(EventArgs e) { RebuildShape(); base.OnDpiChangedAfterParent(e); }
        protected void RebuildShape()
        {
            if (Shape != null) Shape.Dispose();
            Shape = Width > 2 && Height > 2 ? Design.Rounded(new RectangleF(.5F, .5F, Width - 1F, Height - 1F), Design.Px(this, Design.Radius)) : null;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (Shape == null) RebuildShape();
            outside.Color = Parent == null ? Theme.Colors.Background : Parent.BackColor;
            e.Graphics.FillRectangle(outside, ClientRectangle);
            if (Shape == null) return;
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Fill.Color = BackColor; e.Graphics.FillPath(Fill, Shape);
            if (DrawBorder)
            {
                Outline.Color = Design.Mix(Theme.Colors.Border, Theme.Colors.Accent, FocusAmount);
                Outline.Width = Math.Max(1, DeviceDpi / 96F);
                e.Graphics.DrawPath(Outline, Shape);
            }
            base.OnPaint(e);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                Theme.Changed -= ThemeChanged; Motion.Cancel(this, null);
                if (Shape != null) Shape.Dispose();
                Fill.Dispose(); Outline.Dispose(); outside.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    internal sealed class InputSurface : SurfacePanel
    {
        public TextBox Editor { get; private set; }
        public InputSurface(UiTheme theme, MotionHub motion, bool multiline) : base(theme, motion)
        {
            InputStyle = true; DrawBorder = true;
            Padding = new Padding(10);
            Editor = new TextBox { BorderStyle = BorderStyle.None, Multiline = multiline,
                Dock = DockStyle.Fill, Font = theme.Body, ScrollBars = multiline ? ScrollBars.Vertical : ScrollBars.None,
                MaxLength = 16000, AcceptsReturn = multiline };
            Editor.Enter += FocusChanged; Editor.Leave += FocusChanged;
            Controls.Add(Editor); UpdateColors();
        }

        private void FocusChanged(object sender, EventArgs e)
        {
            double target = Editor.Focused ? 1 : 0;
            Motion.Animate(this, "focus", FocusAmount, target, Design.FocusMs, Ease.OutCubic,
                value => { if (!IsDisposed) { FocusAmount = value; Invalidate(); } }, null);
        }
        protected override void UpdateColors()
        {
            base.UpdateColors();
            if (Editor == null) return;
            Editor.BackColor = Theme.Colors.Input; Editor.ForeColor = Theme.Colors.Text;
        }
    }

    internal sealed class MonoButton : Button
    {
        private readonly UiTheme theme;
        private readonly MotionHub motion;
        private readonly SolidBrush fill = new SolidBrush(Color.Black), outside = new SolidBrush(Color.White);
        private readonly Pen outline = new Pen(Color.Gray);
        private GraphicsPath shape;
        private double hover, pressed, focus;
        public bool Primary { get; set; }
        public bool Selected { get; set; }

        public MonoButton(UiTheme theme, MotionHub motion)
        {
            this.theme = theme; this.motion = motion;
            Font = theme.Body; Height = Design.ButtonHeight; Cursor = Cursors.Hand;
            FlatStyle = FlatStyle.Flat; FlatAppearance.BorderSize = 0;
            AccessibleRole = AccessibleRole.PushButton;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            theme.Changed += ThemeChanged;
        }

        private void ThemeChanged(object sender, EventArgs e) { Invalidate(); }
        private void Transition(string channel, double current, double target, int duration, Action<double> set)
        {
            motion.Animate(this, channel, current, target, duration, Ease.OutCubic,
                value => { if (!IsDisposed) { set(value); Invalidate(); } }, null);
        }
        protected override void OnMouseEnter(EventArgs e) { Transition("hover", hover, Enabled ? 1 : 0, Design.HoverMs, v => hover = v); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { Transition("hover", hover, 0, Design.HoverMs, v => hover = v); Transition("press", pressed, 0, Design.PressMs, v => pressed = v); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { if (e.Button == MouseButtons.Left) Transition("press", pressed, 1, Design.PressMs, v => pressed = v); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { Transition("press", pressed, 0, Design.PressMs, v => pressed = v); base.OnMouseUp(e); }
        protected override void OnKeyDown(KeyEventArgs e) { if (e.KeyCode == Keys.Space || e.KeyCode == Keys.Enter) Transition("press", pressed, 1, Design.PressMs, v => pressed = v); base.OnKeyDown(e); }
        protected override void OnKeyUp(KeyEventArgs e) { Transition("press", pressed, 0, Design.PressMs, v => pressed = v); base.OnKeyUp(e); }
        protected override void OnGotFocus(EventArgs e) { Transition("focus", focus, 1, Design.FocusMs, v => focus = v); base.OnGotFocus(e); }
        protected override void OnLostFocus(EventArgs e) { Transition("focus", focus, 0, Design.FocusMs, v => focus = v); Transition("press", pressed, 0, Design.PressMs, v => pressed = v); base.OnLostFocus(e); }
        protected override void OnEnabledChanged(EventArgs e) { if (!Enabled) { motion.Cancel(this, null); hover = pressed = focus = 0; } Invalidate(); base.OnEnabledChanged(e); }
        protected override void OnSizeChanged(EventArgs e) { ResetShape(); base.OnSizeChanged(e); }
        protected override void OnDpiChangedAfterParent(EventArgs e) { ResetShape(); base.OnDpiChangedAfterParent(e); }
        private void ResetShape() { if (shape != null) shape.Dispose(); shape = null; Invalidate(); }
        protected override void OnPaintBackground(PaintEventArgs e) { }
        protected override void OnPaint(PaintEventArgs e)
        {
            if (Width < 3 || Height < 3) return;
            if (shape == null) shape = Design.Rounded(new RectangleF(1, 1, Width - 2F, Height - 2F), Design.Px(this, Design.Radius));
            Palette p = theme.Colors;
            outside.Color = Parent == null ? p.Background : Parent.BackColor;
            e.Graphics.FillRectangle(outside, ClientRectangle);
            Color background = Primary ? p.Accent : Selected ? p.Selected : p.Surface;
            Color foreground = Primary ? p.OnAccent : Selected ? p.SelectedText : p.Text;
            if (Enabled)
            {
                background = Design.Mix(background, Primary ? Design.Mix(p.Accent, p.OnAccent, .14) : p.Hover, hover);
                background = Design.Mix(background, Primary ? Design.Mix(p.Accent, p.OnAccent, .24) : p.Pressed, pressed);
            }
            else { background = p.Input; foreground = p.Disabled; }
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            fill.Color = background; e.Graphics.FillPath(fill, shape);
            outline.Color = Design.Mix(Primary && Enabled ? background : p.Border, p.Accent, focus);
            outline.Width = Math.Max(1, DeviceDpi / 96F); e.Graphics.DrawPath(outline, shape);
            Rectangle textBounds = ClientRectangle; textBounds.Inflate(-Design.Px(this, 8), 0);
            TextRenderer.DrawText(e.Graphics, Text, Font, textBounds, foreground,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
            if (Focused && ShowFocusCues) ControlPaint.DrawFocusRectangle(e.Graphics, Rectangle.Inflate(ClientRectangle, -5, -5), foreground, background);
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing) { theme.Changed -= ThemeChanged; motion.Cancel(this, null); if (shape != null) shape.Dispose(); fill.Dispose(); outside.Dispose(); outline.Dispose(); }
            base.Dispose(disposing);
        }
    }

    internal sealed class ImageCanvas : SurfacePanel
    {
        private readonly WorkspaceState state;
        private readonly SolidBrush ink = new SolidBrush(Color.White);
        private readonly Pen mark = new Pen(Color.Gray, 2);
        private readonly Bitmap tile = new Bitmap(24, 24, PixelFormat.Format32bppArgb);
        private readonly TextureBrush dots;
        public Bitmap Picture { get { return state.Image; } }
        public bool English { get; set; }
        public bool Compact { get; set; }
        private PointF pan;
        private Point dragOrigin;
        private PointF dragPan;
        private bool dragging;
        public event EventHandler ScaleChanged;
        internal double FitScale
        {
            get
            {
                if (Picture == null) return 1;
                int padding = Design.Px(this, Design.PreviewPadding);
                return Math.Max(.00001, Math.Min(1, Math.Min(Math.Max(1, Width - padding * 2.0) / Picture.Width, Math.Max(1, Height - padding * 2.0) / Picture.Height)));
            }
        }
        internal double ActualScale { get { return Picture == null ? 1 : Compact || state.FitImage ? FitScale : state.Zoom; } }
        internal RectangleF ImageRectangle
        {
            get
            {
                if (Picture == null) return RectangleF.Empty;
                double scale = ActualScale; float width = (float)(Picture.Width * scale), height = (float)(Picture.Height * scale);
                return new RectangleF((Width - width) / 2 + pan.X, (Height - height) / 2 + pan.Y, width, height);
            }
        }

        public ImageCanvas(UiTheme theme, MotionHub motion, WorkspaceState state) : base(theme, motion)
        {
            this.state = state; state.Changed += StateChanged; English = state.Language == "en";
            TabStop = true; SetStyle(ControlStyles.Selectable, true); AccessibleRole = AccessibleRole.Graphic; AccessibleName = "Image preview";
            CanvasStyle = true; UpdateColors();
            tile.SetPixel(12, 12, Color.FromArgb(22, Color.White)); dots = new TextureBrush(tile);
        }

        private void StateChanged(object sender, StateChangedEventArgs e)
        {
            if ((e.Changes & (StateChange.Image | StateChange.Language | StateChange.View)) != 0)
            {
                English = state.Language == "en";
                if ((e.Changes & StateChange.Image) != 0 || state.FitImage || Compact) pan = PointF.Empty;
                ClampPan(); Invalidate(); NotifyScale();
            }
        }
        private void NotifyScale() { EventHandler handler = ScaleChanged; if (handler != null) handler(this, EventArgs.Empty); }
        private void ClampPan()
        {
            if (state == null || Picture == null || state.FitImage || Compact) { pan = PointF.Empty; return; }
            float x = (float)Math.Max(0, (Picture.Width * ActualScale - Width + Design.Px(this, Design.PreviewPadding) * 2) / 2);
            float y = (float)Math.Max(0, (Picture.Height * ActualScale - Height + Design.Px(this, Design.PreviewPadding) * 2) / 2);
            pan = new PointF(Math.Max(-x, Math.Min(x, pan.X)), Math.Max(-y, Math.Min(y, pan.Y)));
        }
        protected override void OnSizeChanged(EventArgs e) { base.OnSizeChanged(e); if (state != null) { ClampPan(); NotifyScale(); } }
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e); Focus();
            if (!Compact && Picture != null && !state.FitImage && e.Button == MouseButtons.Left)
            { dragging = true; dragOrigin = e.Location; dragPan = pan; Capture = true; Cursor = Cursors.SizeAll; }
        }
        protected override void OnMouseMove(MouseEventArgs e)
        { base.OnMouseMove(e); if (dragging) { pan = new PointF(dragPan.X + e.X - dragOrigin.X, dragPan.Y + e.Y - dragOrigin.Y); ClampPan(); Invalidate(); } }
        protected override void OnMouseUp(MouseEventArgs e) { base.OnMouseUp(e); if (e.Button == MouseButtons.Left) { dragging = false; Capture = false; Cursor = Cursors.Default; } }
        protected override void OnMouseCaptureChanged(EventArgs e) { base.OnMouseCaptureChanged(e); if (!Capture) { dragging = false; Cursor = Cursors.Default; } }
        protected override void OnMouseWheel(MouseEventArgs e)
        { if (!Compact && Picture != null && (ModifierKeys & Keys.Control) != 0) state.SetZoom(ActualScale * (e.Delta > 0 ? Design.ZoomStep : 1 / Design.ZoomStep)); else base.OnMouseWheel(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Shape == null) return;
            GraphicsState renderState = e.Graphics.Save(); e.Graphics.SetClip(Shape, CombineMode.Intersect);
            if (!SystemInformation.HighContrast) e.Graphics.FillRectangle(dots, ClientRectangle);
            int padding = Design.Px(this, Design.PreviewPadding);
            if (Picture != null)
            {
                double scale = ActualScale;
                if (scale > 0)
                {
                    RectangleF destination = ImageRectangle;
                    ink.Color = Color.White; e.Graphics.FillRectangle(ink, destination);
                    e.Graphics.InterpolationMode = scale < 1 ? InterpolationMode.HighQualityBicubic : InterpolationMode.NearestNeighbor;
                    e.Graphics.PixelOffsetMode = PixelOffsetMode.Half;
                    e.Graphics.DrawImage(Picture, destination, new RectangleF(0, 0, Picture.Width, Picture.Height), GraphicsUnit.Pixel);
                }
            }
            else
            {
                if (Compact)
                {
                    TextRenderer.DrawText(e.Graphics, Strings.Get(state.Language, "NoImage"), Theme.Body, ClientRectangle,
                        Theme.Colors.CanvasText, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                    e.Graphics.Restore(renderState);
                    return;
                }
                int centerX = Width / 2, centerY = Height / 2 - Design.Px(this, 50), radius = Design.Px(this, 22), corner = Design.Px(this, 10);
                mark.Color = Theme.Colors.CanvasMuted; mark.Width = Math.Max(1, DeviceDpi / 96F * 1.5F);
                e.Graphics.DrawLine(mark, centerX - radius, centerY - radius, centerX - radius + corner, centerY - radius);
                e.Graphics.DrawLine(mark, centerX - radius, centerY - radius, centerX - radius, centerY - radius + corner);
                e.Graphics.DrawLine(mark, centerX + radius, centerY - radius, centerX + radius - corner, centerY - radius);
                e.Graphics.DrawLine(mark, centerX + radius, centerY - radius, centerX + radius, centerY - radius + corner);
                e.Graphics.DrawLine(mark, centerX - radius, centerY + radius, centerX - radius + corner, centerY + radius);
                e.Graphics.DrawLine(mark, centerX - radius, centerY + radius, centerX - radius, centerY + radius - corner);
                e.Graphics.DrawLine(mark, centerX + radius, centerY + radius, centerX + radius - corner, centerY + radius);
                e.Graphics.DrawLine(mark, centerX + radius, centerY + radius, centerX + radius, centerY + radius - corner);
                e.Graphics.DrawLine(mark, centerX - corner / 2, centerY, centerX + corner / 2, centerY);
                e.Graphics.DrawLine(mark, centerX, centerY - corner / 2, centerX, centerY + corner / 2);
                TextRenderer.DrawText(e.Graphics, Strings.Get(state.Language, "CanvasTitle"), Theme.Hero,
                    new Rectangle(padding, centerY + Design.Px(this, 46), Width - padding * 2, Design.Px(this, 48)), Theme.Colors.CanvasText,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordBreak);
                TextRenderer.DrawText(e.Graphics, Strings.Get(state.Language, "CanvasHint"), Theme.Body,
                    new Rectangle(padding, centerY + Design.Px(this, 103), Width - padding * 2, Design.Px(this, 40)), Theme.Colors.CanvasMuted,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.WordBreak);
            }
            e.Graphics.Restore(renderState);
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing) { state.Changed -= StateChanged; ScaleChanged = null; dots.Dispose(); tile.Dispose(); ink.Dispose(); mark.Dispose(); }
            base.Dispose(disposing);
        }
    }

    internal sealed class StatusNote : Control
    {
        private readonly UiTheme theme; private readonly MotionHub motion;
        private string message = "", idle = ""; private double strength = 1;
        public StatusNote(UiTheme theme, MotionHub motion) { this.theme = theme; this.motion = motion; Font = theme.Body; DoubleBuffered = true; theme.Changed += Changed; }
        public void ShowMessage(string text, bool transient)
        {
            motion.Cancel(this, "hold");
            if (!transient) idle = text;
            if (transient && message != text) strength = 0;
            message = text; Text = text; AccessibleName = text;
            motion.Animate(this, "toast", strength, 1, Design.ToastMs, Ease.OutCubic, v => { strength = v; Invalidate(); },
                transient ? (Action)(() => motion.Delay(this, "hold", 2200,
                    () => motion.Animate(this, "toast", strength, 0, Design.ToastMs, Ease.OutCubic, v => { strength = v; Invalidate(); },
                        () => { message = idle; Text = idle; AccessibleName = idle; strength = 1; Invalidate(); }))) : null);
        }
        private void Changed(object sender, EventArgs e) { Invalidate(); }
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.Clear(Parent == null ? theme.Colors.Background : Parent.BackColor);
            TextRenderer.DrawText(e.Graphics, message, Font, ClientRectangle, Design.Mix(theme.Colors.Background, theme.Colors.Text, strength * .75),
                TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
        }
        protected override void Dispose(bool disposing) { if (disposing) { theme.Changed -= Changed; motion.Cancel(this, null); } base.Dispose(disposing); }
    }
}
