using System;
using System.Windows.Forms;

namespace MonoShot
{
    internal static class Program
    {
        [STAThread]
        private static int Main()
        {
            try
            {
                Store.Initialize(AppDomain.CurrentDomain.BaseDirectory);
                Native.InitializeDpi(); Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
                // Do not persist raw exception text: CLI output or local paths can contain private information.
                Application.ThreadException += (sender, e) => MessageBox.Show("The operation could not complete. Please retry.\n操作未完成，请重试。", "MonoShot", MessageBoxButtons.OK, MessageBoxIcon.Information);
                using (MainForm window = new MainForm()) Application.Run(window);
                return 0;
            }
            catch (Exception)
            {
                MessageBox.Show("Could not start MonoShot. Check that its portable folder is writable and .NET Framework 4.8 is available.\n无法启动，请检查便携目录写入权限及 .NET Framework 4.8。", "MonoShot", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return 1;
            }
            finally { Design.DisposeFonts(); }
        }
    }
}
