﻿param([string]$Destination = 'releases/v1.3', [switch]$SkipBuild)
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$env:TEMP = Join-Path $projectRoot '.cache\tmp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Force -Path $env:TEMP | Out-Null
if ([IO.Path]::IsPathRooted($Destination)) { throw 'Choose a relative destination inside this project.' }
$outputRoot = [IO.Path]::GetFullPath((Join-Path $projectRoot $Destination))
$projectPrefix = [IO.Path]::GetFullPath($projectRoot).TrimEnd('\') + '\'
if (!$outputRoot.StartsWith($projectPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Destination must stay inside the project.' }
if (Test-Path -LiteralPath $outputRoot) { throw 'Destination exists. Choose a new relative folder; existing releases are never overwritten.' }
# Do not follow directory links out of the portable workspace.
$ancestor = [IO.DirectoryInfo]$outputRoot
while ($ancestor -and $ancestor.FullName.StartsWith($projectPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    if ($ancestor.Exists -and (($ancestor.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0)) { throw 'Destination cannot contain directory links.' }
    $ancestor = $ancestor.Parent
}
if (!$SkipBuild) { & (Join-Path $projectRoot 'build.ps1') -Test }
$marker = Join-Path $projectRoot '.cache\verified-v1.3.json'
if (!(Test-Path -LiteralPath $marker)) { throw 'Run build.ps1 -Test successfully before packaging.' }
$verified = Get-Content -LiteralPath $marker -Raw | ConvertFrom-Json
$app = Join-Path $projectRoot 'MonoShot-1.3.exe'
if ((Get-FileHash -LiteralPath $app -Algorithm SHA256).Hash -ne $verified.Binary -or
    (Get-FileHash -LiteralPath "$app.config" -Algorithm SHA256).Hash -ne $verified.Configuration) { throw 'Binary/configuration changed since verification. Re-run build.ps1 -Test.' }
$currentInputs = @('build.ps1','MonoShot.csproj','tests/FakeCodex.cs','tests/TestRunner.cs','tests/WorkspaceTests.cs','tests/ShellTests.cs','tests/security/PolicyArguments.cs','tests/security/run-security.ps1','tests/security/verify-policy.py') + @(
    Get-ChildItem -LiteralPath (Join-Path $projectRoot 'src') -File | Sort-Object Name | ForEach-Object { 'src/' + $_.Name })
if (@(Compare-Object $currentInputs @($verified.Inputs | ForEach-Object { $_.Path })).Count) { throw 'Verification inputs changed. Re-run build.ps1 -Test.' }
foreach ($inputHash in $verified.Inputs) {
    if ((Get-FileHash -LiteralPath (Join-Path $projectRoot $inputHash.Path) -Algorithm SHA256).Hash -ne $inputHash.SHA256) { throw 'Source changed since verification. Re-run build.ps1 -Test.' }
}
$stagingRoot = Join-Path $projectRoot ('.cache\package-' + [Guid]::NewGuid().ToString('N'))
$portable = Join-Path $stagingRoot 'MonoShot-v1.3-portable'
$source = Join-Path $stagingRoot 'MonoShot-v1.3-source'
New-Item -ItemType Directory -Path $portable,$source | Out-Null
Copy-Item -LiteralPath $app -Destination (Join-Path $portable 'MonoShot.exe')
Copy-Item -LiteralPath "$app.config" -Destination (Join-Path $portable 'MonoShot.exe.config')
foreach ($name in @('readme.md','LICENSE','THIRD-PARTY-NOTICES.md','CHANGELOG.md')) {
    Copy-Item -LiteralPath (Join-Path $projectRoot $name) -Destination (Join-Path $portable $name)
}
$sourceList = @('.editorconfig','.gitattributes','.gitignore','MonoShot.sln','MonoShot.csproj','build.ps1','package.ps1','check-public.ps1',
    'readme.md','LICENSE','THIRD-PARTY-NOTICES.md','CHANGELOG.md','CONTRIBUTING.md','SECURITY.md',
    'docs/ENGINEERING.md','docs/DESIGN.md','docs/VERIFICATION.md','docs/EA01_FIX.md','docs/EA01_SECURITY_TESTS.json','tests/FakeCodex.cs','tests/TestRunner.cs','tests/WorkspaceTests.cs','tests/ShellTests.cs','tests/security/PolicyArguments.cs','tests/security/run-security.ps1','tests/security/verify-policy.py')
$sourceList += @('AssemblyInfo.cs','AnalysisPolicy.cs','Bridge.cs','CaptureOverlay.cs','Controls.cs','Design.cs','MainForm.cs',
    'Motion.cs','Native.cs','Pictures.cs','Program.cs','Store.cs','Strings.cs','WorkspaceState.cs','AnalysisCoordinator.cs','WorkspaceNavigation.cs','Pages.cs','WindowChrome.cs','MonoShot.ico','app.config','app.manifest' | ForEach-Object { 'src/' + $_ })
foreach ($relative in $sourceList) {
    $target = Join-Path $source $relative
    New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($target)) | Out-Null
    Copy-Item -LiteralPath (Join-Path $projectRoot $relative) -Destination $target
}
& (Join-Path $projectRoot 'check-public.ps1') -Root $portable -Kind portable
& (Join-Path $projectRoot 'check-public.ps1') -Root $source -Kind source
Add-Type -AssemblyName System.IO.Compression.FileSystem
foreach ($folder in @($portable,$source)) {
    [IO.Compression.ZipFile]::CreateFromDirectory($folder, "$folder.zip", [IO.Compression.CompressionLevel]::Optimal, $true)
}
$checksums = @("$portable.zip", "$source.zip", (Join-Path $portable 'MonoShot.exe')) | ForEach-Object {
    (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLowerInvariant() + '  ' + $_.Substring($stagingRoot.Length + 1).Replace('\','/')
}
[IO.File]::WriteAllLines((Join-Path $stagingRoot 'SHA256SUMS.txt'), $checksums, (New-Object Text.UTF8Encoding($false)))
New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($outputRoot)) | Out-Null
[IO.Directory]::Move($stagingRoot, $outputRoot)
Get-ChildItem -LiteralPath $outputRoot | Select-Object Name,Length
