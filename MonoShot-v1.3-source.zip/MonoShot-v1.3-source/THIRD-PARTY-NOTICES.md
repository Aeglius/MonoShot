# External components / 外部组件

MonoShot's application code and drawn icon are original and covered by the accompanying MIT license, Copyright © 2026 Aeglius. No third-party screenshot project, fonts, UI framework, NuGet package or runtime binary is redistributed.

MonoShot 使用 Windows 原生 API 与系统已有的 Microsoft .NET Framework 4.8。它们适用 Microsoft 的条款，不包含在发布包中。字体来自用户的 Windows 系统。

The optional Codex CLI is supplied by the user or discovered from an existing installation; it is not part of either package. Its source and license are maintained at [openai/codex](https://github.com/openai/codex). MonoShot's license does not grant rights over Codex or Microsoft components. MonoShot is not an official OpenAI product.

可选 Codex CLI 由用户自行提供或从已有安装中发现。源码及许可证以官方仓库为准，本项目许可证不覆盖外部组件。
