# Contributing / 参与开发

Build with `./build.ps1 -Test` on Windows x64 with .NET Framework 4.8. Visual Studio users need the Framework 4.8 targeting pack. Keep C# 5 compatibility, the existing target framework, native WinForms/GDI+ and zero third-party NuGet dependencies unless a change is explicitly agreed.

Use `package.ps1` to prepare public artifacts. Never commit runtime data, authentication files, personal screenshots, prompt drafts or local paths. Run `check-public.ps1` against the staged source/portable folders. That scan is a guardrail and cannot prove arbitrary text contains no sensitive information; review changed files before publishing.

Keep changes focused. Explain the user-visible issue and validation in your contribution. UI changes should be checked in both languages and themes; resource changes should include ownership/disposal checks. Do not require live account access for automated tests.

在 Windows x64 / Framework 4.8 环境运行 `build.ps1 -Test`。保持现有框架、原生技术栈与轻量依赖。界面修改检查中英文、深浅主题及键盘操作；资源修改验证释放路径。发布前使用允许列表打包并审查隐私扫描结果，不提交运行数据或真实账号信息。
