﻿# MonoShot · 墨截

**v1.3 · Aeglius**

EA-01 security fix / 安全边界修复 · 2026-10-18 · File version 1.3.0.0

Refined in appearance. Lightweight by nature. Intuitive in use. Timeless by design.

C# / Windows Forms / GDI+ · .NET Framework 4.8 · x64 · No third-party NuGet packages.

## 中文

### 定位与运行

这是验证分页交互、共享状态与换肤结构的 Demo，保持黑白极简风格。正式视觉由开发者后续提供 PSD；本版本不解析 PSD。

解压纯净便携包，运行 `MonoShot.exe`。需要 Windows 10/11 x64 与 .NET Framework 4.8，运行目录必须可写，无需安装。

| 页面 | 功能 |
| --- | --- |
| 截图 | 区域 / 全屏截图、打开或拖入图像、复制、粘贴、PNG / JPEG / BMP 导出、大幅等比预览 |
| AI 分析 | 共用图像缩略图、Prompt 预设与编辑、分析 / 取消、结果复制 / 保存、任务图像版本提示 |
| 设置 | 原生 Codex CLI 连接、设备码登录、Light / Dark / System、墨 / 蓝 / 绿强调色、中英文、版本与贡献者 |

快捷键：`Ctrl+1/2/3` 切页，导航焦点下左 / 右箭头及 Home / End 切页，Tab 移动焦点，Enter / Space 激活按钮。`Ctrl+Alt+A` 全局区域截图，`Ctrl+O` 打开，`Ctrl+S` 导出，`Ctrl+C/V` 图片复制 / 粘贴；文本框保留原生文本复制 / 粘贴。全局快捷键被占用时可使用截图按钮。

区域截图拖动后松开完成，Esc / 右键取消。预览保留宽高比，导出保留原始尺寸；PNG 保留透明度，JPEG 使用白色背景，GIF 仅导入静态帧。

### 自定义窗口与图像工作台

本次 Shell Demo 以 P1 的图像优先布局和 P2 的分析并排布局为参考：紧凑自绘标题栏、左侧页面导航与右侧设置、分组工具栏、文件名与分辨率、独立底部缩放栏。登录 Codex、连接设置和开发者/贡献者信息均位于设置页，主工作台不展示开发者页面。

标题栏支持拖动、双击最大化/还原、最小化、关闭；窗口支持四边与四角命中测试，最大化客户区按显示器工作区域约束。Alt+Space 或标题空白处右键调用原生系统菜单。自绘按钮使用同一主题和 MotionHub，失焦、Hover、Pressed、Light/Dark/System 均有对应状态，不附带图标字体或外部图片包。

上方导航是唯一的 AI 分析入口，点击展开/收起右侧面板，工具栏不再重复提供 AI 按钮。点击“截图”返回图像优先模式；面板中的“独立视图”或 Ctrl+2 可进入完整分析页。侧栏与独立页面复用同一套控件和任务状态：关闭面板不取消任务，不清空 Prompt 或结果，不复制图像。短窗口的侧栏可纵向滚动，设置入口不变。

侧栏展开/收起采用约 210 ms 的 EaseOutCubic 过渡，快速反向按剩余距离缩短到至少 80 ms。动画复用唯一的 MotionHub 和实际时间插值；输入区域保持固定宽度并通过容器裁切滑入，不在每帧重新排版。重复点击从当前进度反向，收起结束后才移出控件。系统减少动画设置生效时立即切换；动画结束不维持刷新循环。

缩放支持减号/加号、100%、适应窗口与预览中的 Ctrl+滚轮。100% 表示一个源图像像素对应一个预览设备像素；手动放大后可按住左键拖动查看。适应模式不放大小图片，百分比来自实际绘制比例，窗口或侧栏尺寸变化时同步刷新。缩放、平移和面板开关为会话状态，不改变原图或导出尺寸。

Windows 11 Snap 所需的最大化命中代码已接入，但当前环境未验证实际 Snap Layouts 浮层。940 × 660 逻辑像素的最小窗口可能限制较窄的分屏区域。实体拖动、八方向缩放手感、Alt+F4/Alt+Space、任务栏操作、自动隐藏任务栏、多屏混合 DPI 移动仍需人工验证。详见验证文档，不应将消息级测试视为全部系统环境均已通过。

### 页面、任务与数据

三个页面常驻，共享一个当前图像对象；切页不重新读取、解码或复制图像。Prompt、编辑选择位置、结果和任务保留在当前会话。结果区与任务区标明对应图像版本；分析期间更换图像不会悄悄改变正在分析的对象。

任务启动时固定任务 ID、图像版本、尺寸、Prompt、语言及连接参数。重复提交被拦截。切页不取消任务；主动取消后丢弃迟到结果。失败、超时或取消保留之前的有效结果，并恢复按钮状态。关闭窗口先取消并清理任务。正在运行的旧构建不会被构建脚本强制关闭，重新启动应用后使用新构建。

取消会终止本地 CLI 进程并隔离后续结果，**不保证远端服务已停止计算**。分析超时 180 秒。登录首次等待网址和设备码的上限为 30 秒；收到说明后继续等待浏览器授权，整个登录流程上限为 10 分钟。

设置、Prompt 草稿与最后选择的预设保存在便携目录；图像和分析结果不自动持久化，需手动导出。页面选择与任务记录为本次会话状态。

### v1.3 安全分析边界

本版优先修复审计 EA-01，保留当前黑白工作台和登录流程。安全分析限定为已验证的原生 **Codex CLI 0.160.1**；不支持的版本或被忽略的安全配置会停止分析并显示原因，不会退回旧的不受限分析方式。CLI 不随包分发。

显式关闭命令执行、浏览器、本地图像读取、联网搜索、Apps、插件、多代理等能力；禁止自动加入项目说明、技能目录和环境上下文。若 `data/codex` 存在 `AGENTS.md` 或 `AGENTS.override.md`，分析会拒绝启动，且不读取、修改这些说明文件。请自行移走它们后重试。登录不受此检查影响。

每次分析使用独立工作目录，仍由 CLI 使用原有便携账户进行认证。JSON 任务轨迹必须完整、不得出现受限工具事件，取消、失败和未知事件不接受结果。此机制不是操作系统级的任意文件隔离：CLI 二进制、机器策略和模型服务仍须受信任。本机已验证模型的工具列表为空；其他模型元数据可能仍暴露无文件/网络能力的提问工具。内置补丁处理器的调用由只读沙箱和禁止批准阻止。详见 [修复范围与实测](docs/EA01_FIX.md)。

升级可在退出旧程序后，将新版 `MonoShot.exe` 与 `.config` 替换到原便携目录并保留 `data/`。全新目录使用独立配置和账户，需要重新登录；请勿把含账户数据的旧目录作为纯净包分享。

### Codex

1. 在设置页选择原生 `codex.exe`；模型可留空。可以单独保存连接，点击登录也会先校验并保存当前填写的路径。应用也会寻找已有安装或 `tools/codex.exe`，不支持脚本启动器。
2. 点击登录，设置页立即显示正在请求网址与设备码。取得说明后，自行打开显示的网址，在浏览器完成登录并输入设备码；不需要在 MonoShot 填写 API Key。说明只在设置页临时显示；登录完成、取消或失败后清理，不作为分析结果导出或日志保存。
3. 导入图像，在 AI 分析页填写问题并点击分析。只有此时才将图像与问题交给 Codex。

如果一直未收到设备码，30 秒后会结束本地等待并恢复登录按钮。网络失败、CLI 不支持参数及超时会显示对应说明，失败后保留安全的排查文字。请确认 CLI 能访问官方登录服务；浏览器代理不一定被 CLI 继承。设备码登录需在 ChatGPT 的安全设置或工作区权限中启用，参见文末官方认证文档。本修正版未用真实账号完成端到端登录；离线模拟成功不代表当前网络或账号一定可用。

沿用原有 `login --device-auth`、独立 `data/codex`、UTF-8 stdin、图片附件、只读沙箱与临时会话。不读取或迁移其他应用的凭证。连接状态仅显示已配置或本次登录状态，不通过检查认证文件推断账号有效性。

截图、剪贴板和导出离线可用；登录和分析需要网络与相应账号额度。正常结束会清理中转图像和结果；崩溃、强制终止或断电可能留下缓存，退出所有实例后可手动清理。

### Portable 与升级

```text
MonoShot.exe
MonoShot.exe.config
readme.md
LICENSE
THIRD-PARTY-NOTICES.md
CHANGELOG.md
data/                 本地设置与 Prompt 草稿
  codex/              官方 CLI 管理的账号与缓存
.cache/tmp/           中转文件
exports/              默认导出位置
tools/                可选 CLI
```

应用管理的缓存、设置与默认导出相对于 EXE 存放。不会修改系统级环境变量；系统和浏览器自身的缓存由相应组件管理。

从 v1.1 升级时退出旧程序，将新 EXE 与配置放入原便携目录即可沿用 `language.txt`、`theme.txt`、`accent.txt`、`cli.txt`、`model.txt`、`prompt.txt` 与 `data/codex`；新增 `preset.txt`。独立解压纯净包会使用自己的空白数据目录。分享时仅使用纯净包，勿打包运行目录。

### 构建、测试与发布

```powershell
.\build.ps1
.\build.ps1 -Test
# Separate development-only security probe (Python 3 + verified native CLI):
.\tests\security\run-security.ps1 -Cli '.\tools\codex.exe'
.\package.ps1 -Destination releases/v1.3
```

使用 Windows 现有 Framework 编译器和 C# 5 语法，不下载依赖。输出 `MonoShot-1.3.exe` 与 `.config`。解决方案明确声明 Framework 4.8 / x64；Visual Studio 构建需对应目标开发包。

`build.ps1 -ShellOnly` 仅用于窗口/预览/面板专项调试，不生成发布验证标记；打包仍要求完整 `-Test` 通过。

测试使用真实 WinForms 消息循环、隔离数据目录和离线 CLI 模拟器，不读取真实账号，不改动系统剪贴板。报告及渲染图位于 `.cache/v1.3/test-run-*/`。测试异常记录为失败并返回非零退出码，不以通过报告掩盖错误。

打包前核对测试哈希和源码输入，按允许列表生成纯净便携目录、独立源码目录、两个 ZIP 与 SHA-256 校验值，默认输出 `releases/v1.3/`。已有目录不覆盖，可指定新的相对 `-Destination`；`-SkipBuild` 只接受已验证且未修改的代码与二进制。源码可直接用于 `git init`。

验证范围、测量和人工检查项见 `docs/VERIFICATION.md`；架构和 PSD 接入点见 `docs/ENGINEERING.md` 与 `docs/DESIGN.md`。

## English

### Start and workflow

This is a functional and skin-architecture demo, not the final visual design. The future PSD from Aeglius will guide a controlled visual replacement. No PSD parser or large UI framework is included.

Extract the portable archive and run `MonoShot.exe` on Windows 10/11 x64 with .NET Framework 4.8. The directory must be writable.

Capture contains full/region capture, open/drop, copy/paste and original-size PNG/JPEG/BMP export. AI Analysis contains a shared-image thumbnail, extensible prompt presets, editable prompts, background analysis, cancel, result copy/save and image-version labels. Settings contains the existing CLI connection/sign-in flow, Light/Dark/System, three accents, Chinese/English and credits.

Use Ctrl+1/2/3 to switch pages, arrow/Home/End keys on navigation tabs, and native Tab/Enter/Space behavior. Ctrl+Alt+A captures a region globally; Ctrl+O opens, Ctrl+S exports and Ctrl+C/V use the image clipboard outside text editors. Esc or right-click cancels region capture. Images keep their aspect ratio and export resolution; JPEG flattens transparency onto white.

### Custom shell and image workspace

The Shell Demo follows P1's image-first workspace and P2's adjacent analysis mode: a compact GDI+ title bar, separate navigation/settings, grouped tools, filename/resolution and a dedicated zoom row. Codex sign-in, connection settings and developer/contributor information stay in Settings. This is a reference-driven demo, not the final PSD skin.

The custom shell retains native resize/system/minimize/maximize styles, handles non-client hit testing and monitor work areas, and draws its own caption icons and theme states. Drag or double-click the title area; right-click it or use Alt+Space for the native system menu. The maximize region exposes HTMAXBUTTON for Windows 11 integration. Actual Snap Layouts, physical edge resizing, keyboard/taskbar operation, auto-hide taskbars and mixed-DPI monitor moves remain manual checks; a 940 x 660 logical minimum can restrict narrow snap zones.

The top AI Analysis navigation item is the single AI entry: click to open/close the adjacent panel. The capture toolbar no longer repeats that action. Capture returns to image-first mode; Full view inside the panel or Ctrl+2 opens the full analysis page. Prompt text, selection, results, job identity and image ownership survive this move. Closing the sidebar does not cancel work. Short windows use sidebar scrolling rather than losing editors.

The panel uses a roughly 210 ms EaseOutCubic transition on the existing elapsed-time MotionHub. Reversal starts at the current progress and scales duration by remaining distance, with an 80 ms minimum. A fixed-width content host slides within a clipped viewport, avoiding per-frame editor reflow. Controls detach only after closing, independently of task lifetime. Reduced motion settles immediately, and no timer remains running for static content.

Use minus/plus, 100%, Fit window or Ctrl+wheel over the preview. Actual size maps one source pixel to one device pixel; drag the enlarged preview to pan. Fit avoids upscaling a small image and reports its actual percentage after resizing or opening the sidebar. View transforms never change original image/export dimensions or create another full-size bitmap.

### State and cancellation

All three pages stay alive and borrow one current image. Switching pages does not decode or clone it. Prompt text, editor selection, results and task status survive navigation. A task freezes its ID, image version/size, prompt, language and connection inputs before its first await. Replacing the current image does not replace the task's image; labels identify both versions.

Only one CLI request runs at a time. Tasks continue while navigating. Canceled/late output cannot overwrite a valid result. Failure, cancellation and timeout restore controls and preserve the previous result. Closing cancels local work before releasing resources. Local CLI termination and stale-output isolation do not guarantee that remote computation has stopped. Analysis times out at 180 seconds. Sign-in allows 30 seconds for the initial link and device code; once both arrive, browser authorization can continue within the ten-minute total deadline.

### v1.3 secure analysis boundary

EA-01 is addressed with a versioned capability policy, keeping the workspace and device-code sign-in. Analysis requires verified native **Codex CLI 0.160.1**. Other versions or ignored security settings fail closed; no permissive fallback is used. The CLI is not bundled.

Command execution, browsers, local-image tools, web search, Apps, plugins, delegation and related capabilities are disabled. Project instructions, skill catalogs and environment context are excluded. Account-level `AGENTS.md` or `AGENTS.override.md` in `data/codex` cause analysis to stop without reading or altering their contents; move these files yourself to proceed. Sign-in remains available.

Each analysis has a separate working directory and a validated JSON task trace. The existing CLI account handles authentication. This is a capability restriction for a trusted CLI, not OS-level isolation of all file reads. The tested model advertised no tools; other model metadata may still expose an inert question tool. Attempted built-in patch operations are blocked by the read-only sandbox and approval policy. See [scope and verification](docs/EA01_FIX.md).

To retain portable settings/account state, exit the old app and replace its EXE/config in the same directory, keeping `data/`. A fresh directory has a separate account and needs sign-in. Never redistribute the used account directory.

### Codex and local files

Select a native codex.exe under Settings; a model override is optional. Sign in validates and saves the currently edited connection before launching. A waiting message appears immediately, followed by the CLI's temporary link and code. Open the displayed link, sign in and enter the code in your browser; this flow needs no API key in MonoShot. Device-code authentication remains unchanged. Temporary instructions stay separate from analysis results and are cleared after the flow.

If no code arrives within 30 seconds, local waiting ends and Sign in becomes available again. Network failures, unsupported CLI arguments and timeouts have distinct safe messages that remain visible after failure. Check CLI connectivity and proxy settings, which may differ from the browser. Device-code login must be enabled in ChatGPT security settings or workspace permissions; see the official authentication documentation below. This fix was tested offline, without completing a real account login or establishing current account/network access.

The CLI keeps its existing app-specific `data/codex` home, UTF-8 stdin, image attachment, read-only sandbox and ephemeral sessions. The app does not inspect or migrate another app's credentials. An image is sent only when Analyze is requested. No raw CLI failure log is persisted.

Settings and prompt drafts live beside the executable. Existing v1.1 setting files are reused; preset.txt is optional. Images, analysis results, current page and task history are session-only unless explicitly exported. Use the clean archive for distribution; runtime directories contain private local data. A crash or forced termination can leave temporary files.

### Build and skinning

Run build.ps1, build.ps1 -Test, or package.ps1. The target remains Framework 4.8/x64, with C# 5 and no third-party NuGet packages. The solution supports Visual Studio with the Framework 4.8 targeting pack. Builds use the installed system compiler and keep app-managed temporary files under the project. A running previous build is preserved in the cache rather than forcibly terminated.

Offline tests use an actual WinForms message loop and synthetic process/image fixtures, never a real account or the user's clipboard. Reports/renders are under `.cache/v1.3/test-run-*/`. Packaging verifies tested inputs, copies allowlists, scans public text and creates separate portable/source folders and ZIPs under `releases/v1.3/`. Existing destinations are never overwritten.

`Design.cs` owns visual tokens and palette rules; `WindowChrome.cs` owns custom caption drawing/controls; `Native.cs` owns native window behavior; `WorkspaceNavigation.cs` owns navigation and themed choices; `Pages.cs` owns local layout; `Strings.cs` owns localization and presets. `WorkspaceState.cs` owns shared data, view settings and image lifetime; `AnalysisCoordinator.cs` owns CLI lifetime and explicit UI dispatch. Existing capture, export, store, bridge and motion code is reused. `build.ps1 -ShellOnly` is a focused diagnostic and cannot authorize packaging; full `-Test` remains required.

See the design document for PSD-to-component mappings and the verification document for executed checks and manual boundaries. Physical mixed-DPI monitors, system-theme changes, live account/cloud behavior and protected/HDR capture need on-device confirmation. Native combo/scrollbar chrome follows Windows. No installer, updater, bundled runtime or code signature is included.

## Credits

Created by Aeglius

Built with the assistance of GPT-6.1 Sol & GPT-6 Astra

Tested by Stellar & enterprise

MIT · Copyright © 2026 Aeglius. See LICENSE and THIRD-PARTY-NOTICES.md. MonoShot is independent and is not an official OpenAI product. The optional Codex executable is not redistributed.

- [Official CLI reference](https://learn.chatgpt.com/docs/cli/reference)
- [Official authentication documentation](https://learn.chatgpt.com/docs/auth)
- [Codex source and license](https://github.com/openai/codex)
