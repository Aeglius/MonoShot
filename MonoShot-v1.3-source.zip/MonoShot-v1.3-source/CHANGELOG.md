﻿# MonoShot v1.3

## EA-01 / 2026-10-18 / 文件版本 1.3.0.0

- 安全分析固定到已验证 CLI 0.160.1，集中关闭具有代码、文件或网络访问能力的工具与自动上下文来源；不再仅依赖提示词。
- 独立单任务工作目录；忽略用户配置和规则；账户说明文件存在时拒绝分析，保留文件和原有登录流程。
- 校验 JSON 任务轨迹；受限工具、未知/无效事件、未完成任务、被忽略的配置均拒绝结果。保留超时、取消和图像版本绑定。
- 208 项离线回归及真实 CLI + 本地模拟模型的 14 场景检查通过；未使用真实账号、截图或付费 API。
- 依旧 Framework 4.8 / C# 5 / x64，无 NuGet；为安全解析轨迹增加框架自带 System.Runtime.Serialization 和 System.Xml 引用，不分发新 DLL。
- 独立 v1.3 EXE、纯净便携包及源码包；旧 v1.2 发布物保留。

Security analysis now uses a tested, versioned capability policy, isolated task working directories and JSON trace validation. Unsupported versions/settings fail closed. Sign-in remains unchanged. Independent loopback probes use synthetic data and verify actual CLI tool rejection. This is not a replacement for trusting the CLI executable and machine policy; see docs/EA01_FIX.md for remaining limits.

## Historical v1.2-skindemo releases


## UI Motion / 2026-10-17 / 文件版本 1.2.0.3

- 移除截图工具栏的重复 AI 按钮，统一上方导航为 AI 侧栏入口；“独立视图”和 Ctrl+2 保留完整分析页。
- 新增约 210 ms 的 EaseOutCubic 滑入/滑出，复用现有 MotionHub；支持从当前位置反向，尊重系统减少动画设置。
- 固定侧栏内容宽度，通过视口裁切过渡，避免动画中挤压输入框；关闭完成才移出控件，切页和销毁时清理动画。
- 保留图像、Prompt、结果、后台任务与原有登录修复；196 项离线检查通过，无新增依赖、计时器或整图动画缓存。

### English

- Removed the duplicate toolbar AI action. Top navigation is the single adjacent-AI entry; Full view and Ctrl+2 retain the full analysis page.
- Added roughly 210 ms EaseOutCubic open/close motion on MotionHub, continuous reversal and reduced-motion support.
- Animated a clipped viewport around fixed-width content, retaining editors through closing and cleaning up motion on page changes/disposal.
- Preserved image/prompt/result/task state and login fixes. All 196 offline checks passed with no new dependency, timer or full-image transition cache.

## Shell Demo / 2026-10-17 / 文件版本 1.2.0.2

- 参考 P1/P2 整理紧凑标题、分离导航/设置、分组工具栏、文件名与分辨率、大幅预览和独立缩放栏；保留三页面。
- 新增 GDI+ 标题栏和原生可访问窗口按钮，复用主题与 MotionHub；补齐原生窗口样式、八方向命中测试、工作区约束、双击与系统菜单路径。
- 修复原生非客户区打印、工具栏裁切、最大化越界及还原尺寸累积增长；图标跟随窗口状态、主题、语言和激活状态。
- 新增实际比例缩放、100%、适应窗口与平移；切换侧栏不解码或复制图像。
- AI 侧栏与完整页面复用同一控件，短窗口可滚动；收起不取消后台分析，保留编辑位置及结果版本。
- Codex 登录、开发者及贡献者信息保持在设置页；保留全部登录失败、取消与销毁后回调回归。
- 181 项离线检查通过；实机多屏混合 DPI、物理系统快捷键、Snap 浮层与真实云端授权仍需人工测试。无新增依赖。

### English

- Added a reference-driven image workspace, grouped tools, filename/resolution, zoom row and adjacent analysis while preserving all three pages.
- Added GDI+ caption controls with native resize/system styles, hit testing, work-area bounds, double-click and system-menu routes; reused the theme and shared motion scheduler.
- Fixed native caption printing, toolbar clipping, maximized client overflow and restore-size drift.
- Added real-percentage zoom, actual pixels, fit and pan without another full-size bitmap.
- Reparented the same analysis controls for sidebar/page modes, preserving editors, selection, background jobs and result provenance; short windows scroll.
- Kept sign-in/developer information in Settings and all prior login regressions. All 181 offline checks passed; physical mixed-DPI/Snap/keyboard/cloud checks remain explicit manual items. No dependencies added.

## Login fix / 2026-10-17 / 文件版本 1.2.0.1

- 点击登录先校验并保存当前连接，不再悄悄沿用旧路径；立即显示等待说明。
- 首次网址与设备码等待上限 30 秒；收到说明后保留原有 10 分钟总期限，切页不取消登录。
- 网络失败、参数不支持及启动超时分别提示；恢复按钮并保留安全的双语排查文字，清理临时设备码。
- 等待子进程重定向输出收尾，并串行化输出与资源释放，避免遗漏末尾信息或迟到回调。
- 保持现有认证方式与依赖；143 项离线检查通过，真实浏览器授权需人工验证。

### English

- Sign in validates/saves the current connection and immediately shows a waiting message.
- Added a 30-second initial-instruction deadline; receiving a link and code preserves the existing ten-minute total authorization window across page changes.
- Distinguished network, unsupported-argument and startup-timeout failures, restored controls and retained safe bilingual guidance while clearing temporary codes.
- Drained final redirected output and serialized callback teardown with resource disposal.
- Preserved authentication and dependencies. All 143 offline checks passed; live browser authorization remains a manual check.

## v1.2-skindemo / 中文

- 新增截图、AI 分析、设置三页常驻工作台，支持鼠标、键盘及 150 ms 导航指示器。
- 引入轻量共享状态与图像所有权，预览和缩略图共用图像，切页保留 Prompt、选择位置、结果和任务。
- 任务启动前固定图像版本、Prompt 与连接参数，取消后隔离迟到结果，保留已有有效结果。
- 沿用现有 Codex CLI、设备码登录、只读请求、导出格式及便携配置。
- 新增 System 主题、集中双语资源及可扩展预设目录；集中皮肤参数与页面布局入口，为后续 PSD 接入准备。
- 修复首次显示页面尺寸、短窗口编辑空间、无 UI 同步上下文时的登录回调及销毁后回调处理。
- 测试使用真实消息循环；提供更新的独立源码与纯净便携包。

## v1.2-skindemo / English

- Added persistent Capture, AI Analysis and Settings pages with keyboard navigation and a shared 150 ms indicator.
- Shared one current image; retained prompt/selection/results/tasks across navigation.
- Froze request identity/image version/prompt/connection inputs; isolated late canceled output and preserved earlier results.
- Reused existing CLI authentication, request/export behavior, portable settings and native framework dependencies.
- Added System mode, centralized bilingual strings/preset IDs and skin tokens for future PSD-driven replacement.
- Fixed first-visible page bounds, small-window editing, null-context login callbacks and disposal-aware dispatch.
- Added real-message-loop regression checks and updated clean source/portable packages.

## v1.1

## 中文

- 新增浅色 / 深色主题与三种强调色，统一圆角、间距、字体、禁用和焦点状态。
- 新增单计时器 UI 动效：Hover、Pressed、输入焦点、主题、侧栏与状态提示。遵循系统减少动画设置。
- 新增 Prompt 预设与本地草稿；中英文界面即时切换。
- 改进窄窗口侧栏滚动和按钮布局，保留原生标题栏、键盘与无障碍控件。
- 优化截图 Bitmap 所有权、选区增量重绘、文件编码、剪贴板重试、取消和关闭清理。
- 保留原有设备码登录与配置；认证说明不再进入分析导出或持久错误日志。
- 开发者署名统一为 Aeglius，提供独立源码与允许列表生成的纯净便携包。
- 添加 Framework 4.8 / x64 工程文件及离线回归、渲染、资源和隐私检查。无新增第三方依赖。

## English

- Unified Light/Dark themes, three accents, geometry, typography and accessible interaction states.
- Added shared elapsed-time motion for hover, press, focus, themes, sidebar and status messages, respecting reduced animation.
- Added prompt presets and a portable draft; retained instant Chinese/English switching.
- Improved narrow-window scrolling, image ownership, capture dirty regions, off-thread encoding, clipboard retries and bounded cancellation.
- Preserved device-code sign-in and legacy configuration. Authentication instructions cannot be exported as analysis or written to persistent error logs.
- Unified public attribution as Aeglius, with explicit Framework 4.8/x64 projects, offline verification and clean allowlisted portable/source packages.
- No new third-party dependencies or bundled runtimes.
