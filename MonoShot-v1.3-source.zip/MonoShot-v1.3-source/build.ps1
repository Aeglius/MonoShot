﻿param([switch]$Test, [switch]$ShellOnly)
if ($ShellOnly) { $Test = $true }
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$env:TEMP = Join-Path $projectRoot '.cache\tmp'
$env:TMP = $env:TEMP
$testBin = Join-Path $projectRoot '.cache\v1.3\test-bin'
$testRoot = Join-Path $projectRoot ('.cache\v1.3\test-run-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $env:TEMP,$testBin,$testRoot | Out-Null
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (!(Test-Path -LiteralPath $compiler)) { throw 'The Windows .NET Framework compiler is required.' }
$sources = @(Get-ChildItem -LiteralPath (Join-Path $projectRoot 'src') -Filter '*.cs' | Sort-Object Name | ForEach-Object { $_.FullName })
$common = @('/nologo','/platform:x64','/optimize+','/langversion:5','/warn:4','/utf8output','/codepage:65001',
    '/r:System.dll','/r:System.Core.dll','/r:System.Runtime.Serialization.dll','/r:System.Xml.dll','/r:System.Drawing.dll','/r:System.Windows.Forms.dll',
    "/win32icon:$projectRoot\src\MonoShot.ico", "/win32manifest:$projectRoot\src\app.manifest")
$app = Join-Path $projectRoot 'MonoShot-1.3.exe'
$verification = Join-Path $projectRoot '.cache\verified-v1.3.json'
if (Test-Path -LiteralPath $verification) { Remove-Item -LiteralPath $verification }
$buildStagingDirectory = Join-Path $env:TEMP ('build-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $buildStagingDirectory | Out-Null
$stagedApp = Join-Path $buildStagingDirectory 'MonoShot.exe'
& $compiler @common /target:winexe /main:MonoShot.Program "/out:$stagedApp" @sources
if ($LASTEXITCODE -ne 0) { throw 'Application build failed.' }
try {
    try { [IO.File]::Copy($stagedApp, $app, $true) }
    catch [IO.IOException] {
        if (!(Test-Path -LiteralPath $app -PathType Leaf)) { throw }
        # Windows allows renaming an executing image. Preserve it instead of terminating a user's session.
        $previous = Join-Path $env:TEMP ('previous-build-' + [Guid]::NewGuid().ToString('N') + '.exe')
        Move-Item -LiteralPath $app -Destination $previous
        [IO.File]::Copy($stagedApp, $app, $false)
        Write-Output 'The running previous build was preserved in the project cache. Restart the app to use this build.'
    }
}
finally {
    if (Test-Path -LiteralPath $stagedApp) { Remove-Item -LiteralPath $stagedApp }
    if (Test-Path -LiteralPath $buildStagingDirectory) { Remove-Item -LiteralPath $buildStagingDirectory }
}
Copy-Item -LiteralPath (Join-Path $projectRoot 'src\app.config') -Destination "$app.config" -Force
if ($Test) {
    $fixture = Join-Path $testBin 'FakeCodex.exe'
    & $compiler /nologo /target:exe /platform:x64 /optimize+ /langversion:5 /codepage:65001 "/out:$fixture" "$projectRoot\tests\FakeCodex.cs"
    if ($LASTEXITCODE -ne 0) { throw 'CLI fixture build failed.' }
    $runner = Join-Path $testBin 'MonoShot.Tests.exe'
    $testSources = @("$projectRoot\tests\TestRunner.cs", "$projectRoot\tests\WorkspaceTests.cs", "$projectRoot\tests\ShellTests.cs")
    & $compiler @common /target:exe /main:MonoShot.Tests.TestRunner "/out:$runner" @sources @testSources
    if ($LASTEXITCODE -ne 0) { throw 'Regression runner build failed.' }
    Copy-Item -LiteralPath (Join-Path $projectRoot 'src\app.config') -Destination "$runner.config" -Force
    $testArguments = '"' + $testRoot + '" "' + $fixture + '"'
    if ($ShellOnly) { $testArguments += ' --shell-only' }
    $testProcess = Start-Process -FilePath $runner -ArgumentList $testArguments -WindowStyle Hidden -PassThru
    if (!$testProcess.WaitForExit(90000)) { $testProcess.Kill(); throw 'Regression runner exceeded 90 seconds.' }
    Get-Content -LiteralPath (Join-Path $testRoot 'verification.txt')
    if ($testProcess.ExitCode -ne 0) { throw 'Regression checks failed.' }
    if ($ShellOnly) { Write-Output 'Focused shell checks only; a full -Test run is required before packaging.'; return }
    $inputFiles = @('build.ps1','MonoShot.csproj','tests/FakeCodex.cs','tests/TestRunner.cs','tests/WorkspaceTests.cs','tests/ShellTests.cs','tests/security/PolicyArguments.cs','tests/security/run-security.ps1','tests/security/verify-policy.py') + @(
        Get-ChildItem -LiteralPath (Join-Path $projectRoot 'src') -File | Sort-Object Name | ForEach-Object { 'src/' + $_.Name })
    $inputHashes = @($inputFiles | ForEach-Object {
        [ordered]@{ Path = $_; SHA256 = (Get-FileHash -LiteralPath (Join-Path $projectRoot $_) -Algorithm SHA256).Hash }
    })
    [ordered]@{
        Binary = (Get-FileHash -LiteralPath $app -Algorithm SHA256).Hash
        Configuration = (Get-FileHash -LiteralPath "$app.config" -Algorithm SHA256).Hash
        Inputs = $inputHashes
    } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $verification -Encoding UTF8
}
Get-Item -LiteralPath $app | Select-Object Name,Length
